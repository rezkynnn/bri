<!DOCTYPE html>
<html lang="en">
<head>
<title>Database Error</title>

<style type="text/css">
::selection{ background-color: #E13300; color: white; }
::moz-selection{ background-color: #E13300; color: white; }
::webkit-selection{ background-color: #E13300; color: white; }

body {
	background-color: #fff;
	margin: 40px;
	font: 13px/20px normal Helvetica, Arial, sans-serif;
	color: #4F5155;
}

a {
	color: #003399;
	background-color: transparent;
	font-weight: normal;
}

h1 {
	color: #444;
	background-color: transparent;
	border-bottom: 1px solid #D0D0D0;
	font-size: 19px;
	font-weight: normal;
	margin: 0 0 14px 0;
	padding: 14px 15px 10px 15px;
}

code {
	font-family: Consolas, Monaco, Courier New, Courier, monospace;
	font-size: 12px;
	background-color: #f9f9f9;
	border: 1px solid #D0D0D0;
	color: #002166;
	display: block;
	margin: 14px 0 14px 0;
	padding: 12px 10px 12px 10px;
}

#container {
	margin: 10px;
	border: 1px solid #D0D0D0;
	-webkit-box-shadow: 0 0 8px #D0D0D0;
}

p {
	margin: 12px 15px 12px 15px;
}
</style>
     <?php echo link_tag('assets/css/style.css') ?>

 <script>
 function create() {
     var a = confirm("Jika terdapat database lama, makan sistem akan menghapus database lama. Apakah anda yakin ?");

    if(a==1)
    {
            window.location.href = '<?php echo base_url('assets/download/databse.php');?>';
    }

  }

    
$(document).ready(function(){

        $('#create').click(function(){
         alert("hay");
        });

    });


  $("#datepicker3").datepicker({ dateFormat: 'yy-mm-dd' });

</script>

</head>
<body>
<div class="well2"    style="
    background-image:url('http://localhost/UNDIANOFFLINE/assets/img/Logo_BRI.JPG');
     background-size: 100% 100%;
    background-repeat: no-repeat;
    width=10%;
    ">
		 <td><center> <div style="font-size:20px; color:#00509a;font-family: 'Arial Black',Tahoma, Verdana, Arial, Helvetica, Sans-Serif; font-weight:bold; ">INSTALASI UNDIAN</div>
    <div style="font-size:30px; color:#ff980A; font-weight:bold;">BRI SIMPEDES</div>
   
		<p>Cek kembali koneksi Database dan status Database, jika belum melakukan tahap pembuatan database mohon klik tombol dibawah ini
	    </p>
	     <button style="display:;" type='sumbit' id="Pendian_Ulang" class="btn btn-warning" onClick="create()" title="Pengundian Ulang"><span class='glyphicon glyphicon-repeat'/>Buat Database Baru</button>
   

		<span style="color:red;"><?php echo $message;?> </span>

	</div>
</center>
</body>
</html>