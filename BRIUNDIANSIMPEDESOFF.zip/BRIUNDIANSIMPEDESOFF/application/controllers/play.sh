#!/bin/bash
# My first script

echo "Hello World!"
#echo 02132 | sudo -S /opt/lampp/bin/mysqldump --login-path=local -e  db_kc_s206 > ~/mysql100.sql

