<?php
if (!defined('BASEPATH'))
	exit('No Direct Access Allowed !');
	
	class ctrl_excel extends CI_Controller {
		public function __construct()
		{
			parent::__construct();

			$this->load->database();
			$this->load->helper('url');
			$this->load->model('brisimpedes/model_exel');
			$this->load->model('brisimpedes/model_mstperiodehadiah');
			$this->load->model('model_mstperiode');

			$this->load->model('brisimpedes/model_kupon');
			$this->load->library('session');
#        	$this->load->library("excel");
        	$this->load->library('Excel');

		}

		//export to csv
		function csv($array) {
		    $csv = implode(',', $array);
		    $newline = "\n";
		    return $csv.$newline;
		}
		
		public function indonesian_date ($hari) {
		 // $hari = '';
		  if($hari=='Sunday'){$hari ="Minggu, ";}
		  if($hari=='Monday'){$hari ="Senin, ";}
		  if($hari=='Tuesday'){$hari ="Selasa, ";}
		  if($hari=='Wednesday'){$hari ="Rabu, ";}
		  if($hari=='Thursday'){$hari ="Kamis, ";}
		  if($hari=='Friday'){$hari ="Jumat, ";}
		  if($hari=='Saturday'){$hari ="Sabtu, ";}
		  return $hari;
		} 

		public function laporanhadiahtiapkanca()
		{

			
			$tanngalMulai ="";
			$tanngalSelesai=""; 

			if($_GET['id']==0)
			{

				//	$this->load->helper('php-excel');
					if(isset($_GET['idk']))
					{
					 	$idkanca = $_GET['idk'];

					}
					else
					{
					 	$idkanca = $this->session->userdata('kode_kanca');
					}
	
					$data = $this->model_exel->data_exel_hadiahPerPeriodeKancaAll($idkanca);
	


		            


			}
			else{
				 	//if for cektak laporan kanwil
				 	if(isset($_GET['idk']))
					{
					 	$idkanca = $_GET['idk'];

					}
					else
					{
					 	$idkanca = $this->session->userdata('kode_kanca');
					}



					$data = $this->model_exel->data_exel_hadiahPerPeriodeKanca($_GET['id'],$idkanca);
					
					if(isset($data))
		            {
						
					 	$periodeRange = $this->model_mstperiodehadiah->data_periode_kanca($idkanca,$_GET['id']);
						$periodetamp = explode("=",$periodeRange);
						for($i=0 ; $i<2; $i++)
						{
							 $tanggalLengkap = explode("-",$periodetamp[$i]);
							 $tahun = $tanggalLengkap[0];
							 $tanggal = $tanggalLengkap[2];
							 $bulan = $tanggalLengkap[1];
							 if($bulan == '01'){$bulan = "Januari";}
							 else if($bulan == '02'){$bulan = "Februari";}
							 else if($bulan == '03'){$bulan = "Maret";}
							 else if($bulan == '04'){$bulan = "April";}
							 else if($bulan == '05'){$bulan = "Mei";}
							 else if($bulan == '06'){$bulan = "Juni";}
							 else if($bulan == '07'){$bulan = "Juli";}
							 else if($bulan == '08'){$bulan = "Agustus";}
							 else if($bulan == '09'){$bulan = "September";}
							 else if($bulan == '10'){$bulan = "Oktober";}
							 else if($bulan == '11'){$bulan = "November";}
							 else if($bulan == '12'){$bulan = "Desember";}

							 if($i==0){$tanngalMulai = $tanggal." ".$bulan." ".$tahun." s/d ";}
							 if($i==1){$tanngalSelesai= $tanggal." ".$bulan." ".$tahun;}
							  

						}

					 	}
					
				}



			//batasssss librari baru

				// Create new PHPExcel object
				$objPHPExcel = new PHPExcel();
				//PROPERTIS
				$objPHPExcel->getProperties()->setCreator("Admin kantorcabang");
				$objPHPExcel->getProperties()->setTitle("Report hadiah Kantor Cabang");
				$objPHPExcel->getProperties()->setSubject("Report Hasil undian");
				$objPHPExcel->getProperties()->setDescription("laporan hadiah kantor cabang untuk pengundian simpedes");

				//STYLE 
				$styleArrayBorder = array(
				'borders' => array(
					'allborders' => array(
						'style' => PHPExcel_Style_Border::BORDER_THIN					)
				),
				'font' => array(
					'bold' => true,
					'name' => 'Tahoma',
					'size' => 10
				),
				'alignment' => array(
					'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER,
					'vertical' => PHPExcel_Style_Alignment::VERTICAL_CENTER
				)
			   );

				//SET STYLE SUBDATA
				$styleArrayBorderData = array(
					'font' => array(
					'name' => 'Tahoma',
					'size' => 10
				),


				'alignment' => array(
					'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER,
					'vertical' => PHPExcel_Style_Alignment::VERTICAL_CENTER
				),

			   );

				$styleArrayBorderAllData = array(
					'font' => array(
					'name' => 'Tahoma',
					'size' => 10
				),
				'borders' => array(
					  'left' => array(
						      'style' => PHPExcel_Style_Border::BORDER_HAIR,
						    ),
				    'right' => array(
				      'style' => PHPExcel_Style_Border::BORDER_HAIR,
				    )
						  
					)
				
			   );

				$styleArrayjudul = array(
				'font' => array(
					'bold' => true,
					'name' => 'Tahoma',
					'size' => 10
				),
				'alignment' => array(
					'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER,
					'vertical' => PHPExcel_Style_Alignment::VERTICAL_CENTER
				)
			   );


			$styleArraySubJudul = array(
				'font' => array(
					'bold' => true,
					'name' => 'Tahoma',
					'size' => 10
				),
						'borders' => array(
					'allborders' => array(
						'style' => PHPExcel_Style_Border::BORDER_HAIR					)
				),
				'alignment' => array(
					'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER,
					'vertical' => PHPExcel_Style_Alignment::VERTICAL_CENTER
				)
			   );


				$styleArraySumarry = array(
				'font' => array(
					'bold' => true,
					'name' => 'Tahoma',
					'size' => 10
				),
				'alignment' => array(
					'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_RIGHT,
					'vertical' => PHPExcel_Style_Alignment::VERTICAL_CENTER
				),
				'borders' => array(
					'allborders' => array(
						'style' => PHPExcel_Style_Border::BORDER_HAIR					)
				)
			   );

				$styleArraySumarryTanggal = array(
				'font' => array(
					'bold' => true,
					'name' => 'Tahoma',
					'size' => 10
				),
				'alignment' => array(
					'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_LEFT,
					'vertical' => PHPExcel_Style_Alignment::VERTICAL_CENTER
				),
			   );

				// Set document properties
			/*
			$objPHPExcel->getProperties()->setCreator("mohamadikhwan.com")
										 ->setLastModifiedBy("mohamadikhwan.com")
										 ->setTitle("Office 2007 XLSX Test Document")
										 ->setSubject("Office 2007 XLSX Test Document")
										 ->setDescription("Test document for Office 2007 XLSX, generated by PHP classes.")
										 ->setKeywords("office 2007 openxml php")
										 ->setCategory("Test result file");
										 */

			//magre cell judul
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('A1', 'PT.BANK RAKYAT INDONESIA (PERSERO), Tbk')->mergeCells('A1:L1')->getStyle('A1')->applyFromArray($styleArrayjudul);
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('A2', "Daftar Hadiah Undian Simpedes - Kode Branch ".$idkanca."")->mergeCells('A2:L2')->getStyle('A2')->applyFromArray($styleArrayjudul);
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('A3', "Periode ".$tanngalMulai."".$tanngalSelesai."")->mergeCells('A3:L3')->getStyle('A3')->applyFromArray($styleArrayjudul);
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('A4', "Hari / Tanggal Cetak : ".$this->indonesian_date(date("l")) . date("d-m-Y"))->mergeCells('A4:D4')->getStyle('A4')->applyFromArray($styleArraySumarryTanggal);


			//STYLE DIMENSION
			$objPHPExcel->setActiveSheetIndex(0)->getColumnDimension('A')->setAutoSize(true);
			$objPHPExcel->setActiveSheetIndex(0)->getColumnDimension('B')->setAutoSize(true);
			$objPHPExcel->setActiveSheetIndex(0)->getColumnDimension('C')->setAutoSize(true);
			$objPHPExcel->setActiveSheetIndex(0)->getColumnDimension('D')->setAutoSize(true);
			$objPHPExcel->setActiveSheetIndex(0)->getColumnDimension('E')->setAutoSize(true);
			$objPHPExcel->setActiveSheetIndex(0)->getColumnDimension('F')->setAutoSize(true);
			$objPHPExcel->setActiveSheetIndex(0)->getColumnDimension('G')->setAutoSize(true);
			$objPHPExcel->setActiveSheetIndex(0)->getColumnDimension('H')->setAutoSize(true);
			$objPHPExcel->setActiveSheetIndex(0)->getColumnDimension('I')->setAutoSize(true);
			$objPHPExcel->setActiveSheetIndex(0)->getColumnDimension('J')->setAutoSize(true);
			$objPHPExcel->setActiveSheetIndex(0)->getColumnDimension('K')->setAutoSize(true);
			$objPHPExcel->setActiveSheetIndex(0)->getColumnDimension('L')->setAutoSize(true);
			$objPHPExcel->setActiveSheetIndex(0)->getColumnDimension('M')->setAutoSize(true);
		
	
	//$data_array[] = array( $no,$row->kanwil,$row->kanca, $row->jenishadiah, $row->varJenisHadiah , $row->varMerkHadiah, $row->varTypeHadiah, $row->tahunPembuatan, $row->varKondisiPembuatan, $row->hargaSatuan, $row->jumlah, $row->potonganHarga, $hargasatuantotalakhir);
						
			//SET STYLE
			$objPHPExcel->setActiveSheetIndex(0)->getStyle('A5:K5')->applyFromArray($styleArraySubJudul);
			///get fill
			 $objPHPExcel->getActiveSheet(0)->getStyle('A5:K5')->getFill()->setFillType(PHPExcel_Style_Fill::FILL_SOLID);
             $objPHPExcel->getActiveSheet(0)->getStyle('A5:K5')->getFill()->getStartColor()->setARGB('ffe4ba');





			// Add data FOR JUDUL FIELD
     		$objPHPExcel->setActiveSheetIndex(0)
		        ->setCellValue('A5', 'NO')
		        ->setCellValue('B5', 'KATEGORI')
		        ->setCellValue('C5', 'JENIS')
		        ->setCellValue('D5', 'MERK')
		       	->setCellValue('E5', 'TYPE HADIAH')
		       ->setCellValue('F5', 'TAHUN PEMBUATAN')
		       	->setCellValue('G5', 'KONDISI PEMBUATAN')

		        ->setCellValue('H5', 'HARGA SATUAN')
				->setCellValue('I5', 'JUMLAH')
		       	->setCellValue('J5', 'POTONGAN HARGA')
		       ->setCellValue('K5', 'TOTAL HARGA');


		       $no=0;
		       $counter = 6;
		       $jumlahtot = 0;
		       $hargatotal = 0;
		       $hargasatuantotal=0;
		       $hargasatuantotalakhir=0;
		       $hargatotaladiah = 0;
		       $totpotongan = 0;

				foreach ($data  as $row) {
					///DRAW COLOR STYLE PER ROW
					if($counter%2==0)
					{
						$objPHPExcel->getActiveSheet(0)->getStyle('A'.$counter.':K'.$counter)->getFill()->setFillType(PHPExcel_Style_Fill::FILL_SOLID);
		            	$objPHPExcel->getActiveSheet(0)->getStyle('A'.$counter.':K'.$counter)->getFill()->getStartColor()->setARGB('DADADA');


					}


					//style data
	  					$objPHPExcel->setActiveSheetIndex(0)->getStyle('A'.$counter.':H'.$counter.'')->applyFromArray($styleArrayBorderData);
						//$objPHPExcel->setActiveSheetIndex(0)->getStyle('A'.$counter.':M'.$counter.'')->applyFromArray($styleArrayBorderAllData);

						$objPHPExcel->setActiveSheetIndex(0)->getStyle('A'.$counter)->applyFromArray($styleArrayBorderAllData);
						$objPHPExcel->setActiveSheetIndex(0)->getStyle('B'.$counter)->applyFromArray($styleArrayBorderAllData);
						$objPHPExcel->setActiveSheetIndex(0)->getStyle('C'.$counter)->applyFromArray($styleArrayBorderAllData);
						$objPHPExcel->setActiveSheetIndex(0)->getStyle('D'.$counter)->applyFromArray($styleArrayBorderAllData);
						$objPHPExcel->setActiveSheetIndex(0)->getStyle('E'.$counter)->applyFromArray($styleArrayBorderAllData);
						$objPHPExcel->setActiveSheetIndex(0)->getStyle('F'.$counter)->applyFromArray($styleArrayBorderAllData);
						$objPHPExcel->setActiveSheetIndex(0)->getStyle('G'.$counter)->applyFromArray($styleArrayBorderAllData);
						$objPHPExcel->setActiveSheetIndex(0)->getStyle('H'.$counter)->applyFromArray($styleArrayBorderAllData);
						$objPHPExcel->setActiveSheetIndex(0)->getStyle('I'.$counter)->applyFromArray($styleArrayBorderAllData);
						$objPHPExcel->setActiveSheetIndex(0)->getStyle('J'.$counter)->applyFromArray($styleArrayBorderAllData);
						$objPHPExcel->setActiveSheetIndex(0)->getStyle('K'.$counter)->applyFromArray($styleArrayBorderAllData);
					









						$no++;
						$hargasatuantotalakhir = ($row->hargaSatuan *$row->jumlah) - $row->potonganHarga;
					    $hargasatuantotal = $row->hargaSatuan +$hargasatuantotal;
	//				    $potonganharga = 
						$totpotongan = $row->potonganHarga + $totpotongan;
		                $hargasatuantotal = $row->hargaSatuan +$hargasatuantotal;
		                $jumlahtot = $row->jumlah + $jumlahtot;
		                $hargatotaladiah = $hargasatuantotalakhir +  $hargatotaladiah;

		          		$objPHPExcel->setActiveSheetIndex(0)->setCellValue('A'.$counter, $no)
															->setCellValue('B'.$counter, $row->jenishadiah)
															->setCellValue('C'.$counter, $row->varJenisHadiah)
															->setCellValue('D'.$counter, $row->varMerkHadiah)
															->setCellValue('E'.$counter, $row->varTypeHadiah)
															->setCellValue('F'.$counter, $row->tahunPembuatan)
															->setCellValue('G'.$counter, $row->varKondisiPembuatan)
															->setCellValue('H'.$counter, $row->hargaSatuan)
															->setCellValue('I'.$counter, $row->jumlah)
															->setCellValue('J'.$counter, $row->potonganHarga)
															->setCellValue('K'.$counter, "=(H".$counter."*I".$counter.")-J".$counter );
					

   						//$data_array[] = array( $no,$row->kanwil,$row->kanca, $row->jenishadiah, $row->varJenisHadiah , $row->varMerkHadiah, $row->varTypeHadiah, $row->tahunPembuatan, $row->varKondisiPembuatan, $row->hargaSatuan, $row->jumlah, $row->potonganHarga, $hargasatuantotalakhir);

   						$counter = $counter+1;
   						$indeksumtotal = $counter-1;

				}
				if($no!=0){
				//SET SUMARRY DATA
          		$objPHPExcel->setActiveSheetIndex(0)->setCellValue('A'.$counter, 'JUMLAH TOTAL ')->mergeCells('A'.$counter.':G'.$counter.'');
          		$objPHPExcel->setActiveSheetIndex(0)->setCellValue('H'.$counter, "=SUM(H6:H".$indeksumtotal.")")->getStyle('H'.$counter)->applyFromArray($styleArraySumarry);
         		$objPHPExcel->setActiveSheetIndex(0)->setCellValue('I'.$counter, "=SUM(I6:I".$indeksumtotal.")")->getStyle('I'.$counter)->applyFromArray($styleArraySumarry);
         		$objPHPExcel->setActiveSheetIndex(0)->setCellValue('J'.$counter, "=SUM(J6:J".$indeksumtotal.")")->getStyle('J'.$counter)->applyFromArray($styleArraySumarry);
          		$objPHPExcel->setActiveSheetIndex(0)->setCellValue('K'.$counter, "=SUM(K6:K".$indeksumtotal.")")->getStyle('K'.$counter)->applyFromArray($styleArraySumarry);

   				$objPHPExcel->setActiveSheetIndex(0)->getStyle('A'.$counter)->applyFromArray($styleArraySumarry);
   				$objPHPExcel->getActiveSheet(0)->getStyle('A'.$counter.':K'.$counter)->getFill()->setFillType(PHPExcel_Style_Fill::FILL_SOLID);
	            $objPHPExcel->getActiveSheet(0)->getStyle('A'.$counter.':K'.$counter)->getFill()->getStartColor()->setARGB('ffe4ba');

   				}

          	


        


          		$objPHPExcel->getActiveSheet()->setTitle('DAFTAR HADIAH');


				// Set active sheet index to the first sheet, so Excel opens this as the first sheet
				$objPHPExcel->setActiveSheetIndex(0);

				// Redirect output to a client’s web browser (Excel2007)
				//clean the output buffer
				ob_end_clean();

			

				//this is the header given from PHPExcel examples. but the output seems somewhat corrupted in some cases.
				//header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
				//so, we use this header instead.
				header('Content-type: application/vnd.ms-excel');
				header('Content-Disposition: attachment;filename="laporan_hadiah_kanca_'.$idkanca.'_periode_'.$_GET['id'].'.xlsx"');
				header('Cache-Control: max-age=0');

				$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
				$objWriter->save('php://output');
		}


		public function laporandistribusiKupontiapuker()
		{
		//	$this->load->helper('php-excel');
			$tanngalMulai ="";
			$tanngalSelesai=""; 
  			$idkanca= $this->session->userdata('kode_kanca');


			if(isset($_GET['id']))
			{	//get tanggal
					$periodeRange = $this->model_mstperiodehadiah->data_periode_kanca($idkanca,$_GET['id']);
					$periodetamp = explode("=",$periodeRange);
					for($i=0 ; $i<2; $i++)
					{
						 $tanggalLengkap = explode("-",$periodetamp[$i]);
						 $tahun = $tanggalLengkap[0];
						 $tanggal = $tanggalLengkap[2];
						 $bulan = $tanggalLengkap[1];
						 if($bulan == '01'){$bulan = "Januari";}
						 else if($bulan == '02'){$bulan = "Februari";}
						 else if($bulan == '03'){$bulan = "Maret";}
						 else if($bulan == '04'){$bulan = "April";}
						 else if($bulan == '05'){$bulan = "Mei";}
						 else if($bulan == '06'){$bulan = "Juni";}
						 else if($bulan == '07'){$bulan = "Juli";}
						 else if($bulan == '08'){$bulan = "Agustus";}
						 else if($bulan == '09'){$bulan = "September";}
						 else if($bulan == '10'){$bulan = "Oktober";}
						 else if($bulan == '11'){$bulan = "November";}
						 else if($bulan == '12'){$bulan = "Desember";}

						 if($i==0){$tanngalMulai = $tanggal." ".$bulan." ".$tahun." s/d ";}
						 if($i==1){$tanngalSelesai= $tanggal." ".$bulan." ".$tahun;}
						  

					}

				// Create new PHPExcel object
				$objPHPExcel = new PHPExcel();
				//PROPERTIS
				$objPHPExcel->getProperties()->setCreator("Admin kantorcabang");
				$objPHPExcel->getProperties()->setTitle("Report Distribusi kupon di tiap unit");
				$objPHPExcel->getProperties()->setSubject("Report Distribusi undian");
				$objPHPExcel->getProperties()->setDescription("laporan distribusi di tiap unit kantor cabang untuk pengundian simpedes");

				//STYLE 
				$styleArrayBorder = array(
				'borders' => array(
					'allborders' => array(
						'style' => PHPExcel_Style_Border::BORDER_THIN					)
				),
				'font' => array(
					'bold' => true,
					'name' => 'Tahoma',
					'size' => 10
				),
				'alignment' => array(
					'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER,
					'vertical' => PHPExcel_Style_Alignment::VERTICAL_CENTER
				)
			   );

				//SET STYLE SUBDATA
				$styleArrayBorderData = array(
					'font' => array(
					'name' => 'Tahoma',
					'size' => 10
				)
		

			   );

				$styleArrayjudul = array(
				'font' => array(
					'bold' => true,
					'name' => 'Tahoma',
					'size' => 10
				),
				'alignment' => array(
					'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER,
					'vertical' => PHPExcel_Style_Alignment::VERTICAL_CENTER
				)
			   );


			$styleArraySubJudul = array(
				'font' => array(
					'bold' => true,
					'name' => 'Tahoma',
					'size' => 10
				),
				'alignment' => array(
					'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER,
					'vertical' => PHPExcel_Style_Alignment::VERTICAL_CENTER
				),
				'borders' => array(
					  'allborders' => array(
						      'style' => PHPExcel_Style_Border::BORDER_HAIR,
						    )
				    )
	
			   );


				$styleArraySumarry = array(
				'font' => array(
					'bold' => true,
					'name' => 'Tahoma',
					'size' => 10
				),
				'alignment' => array(
					'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_RIGHT,
					'vertical' => PHPExcel_Style_Alignment::VERTICAL_CENTER
				),
				'borders' => array(
					  'allborders' => array(
						      'style' => PHPExcel_Style_Border::BORDER_HAIR,
						    )
				    )
			   );

			$styleArraySumarryTanggal = array(
				'font' => array(
					'bold' => true,
					'name' => 'Tahoma',
					'size' => 10
				),
				'alignment' => array(
					'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_LEFT,
					'vertical' => PHPExcel_Style_Alignment::VERTICAL_CENTER
				)
			   );

			$styleArrayBorderAllData = array(
					'font' => array(
					'name' => 'Tahoma',
					'size' => 10
				),
				'borders' => array(
					  'left' => array(
						      'style' => PHPExcel_Style_Border::BORDER_HAIR,
						    ),
				    'right' => array(
				      'style' => PHPExcel_Style_Border::BORDER_HAIR,
				    )
						  
					)
				
			   );

			//magre cell judul
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('A1', 'PT.BANK RAKYAT INDONESIA (PERSERO), Tbk')->mergeCells('A1:E1')->getStyle('A1')->applyFromArray($styleArrayjudul);
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('A2', "Daftar Distribusi Kupon Undian Simpedes - Kode Branch ".$idkanca."")->mergeCells('A2:E2')->getStyle('A2')->applyFromArray($styleArrayjudul);
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('A3', "Periode ".$tanngalMulai."".$tanngalSelesai."")->mergeCells('A3:E3')->getStyle('A3')->applyFromArray($styleArrayjudul);
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('A5', "Hari / Tanggal Cetak : ".$this->indonesian_date(date("l")) . date("d-m-Y"))->mergeCells('A5:D5')->getStyle('A5')->applyFromArray($styleArraySumarryTanggal);



			$objPHPExcel->setActiveSheetIndex(0)->getColumnDimension('A')->setAutoSize(true);
			$objPHPExcel->setActiveSheetIndex(0)->getColumnDimension('B')->setAutoSize(true);
			$objPHPExcel->setActiveSheetIndex(0)->getColumnDimension('C')->setAutoSize(true);
			$objPHPExcel->setActiveSheetIndex(0)->getColumnDimension('D')->setAutoSize(true);
			$objPHPExcel->setActiveSheetIndex(0)->getColumnDimension('E')->setAutoSize(true);
		
			//style dokumen
			$objPHPExcel->setActiveSheetIndex(0)->getStyle('A6:E6')->applyFromArray($styleArraySubJudul);

				///get fill
			 $objPHPExcel->getActiveSheet(0)->getStyle('A6:E6')->getFill()->setFillType(PHPExcel_Style_Fill::FILL_SOLID);
             $objPHPExcel->getActiveSheet(0)->getStyle('A6:E6')->getFill()->getStartColor()->setARGB('ffe4ba');



			// Add data FOR JUDUL FIELD
     		$objPHPExcel->setActiveSheetIndex(0)
		        ->setCellValue('A6', 'NO')
		        ->setCellValue('B6', 'KODE UNIT')
   		        ->setCellValue('C6', 'NAMA UNIT')
		        ->setCellValue('D6', 'KODE BULAN')
		        ->setCellValue('E6', 'JUMLAH KUPON');

			
					
				 	




				$periode = $_GET['id'];
				$no=0;
				$jumlah = 0;
				$counter =7;
	 			$datakupon= $this->model_kupon->data_cariKuponkanca($idkanca,$periode,$_GET['bulan']);
 				if(isset($datakupon))
		        {
	        	 	foreach ($datakupon as $row)
		            	{
		            		if($counter%2==0)
								{
									$objPHPExcel->getActiveSheet(0)->getStyle('A'.$counter.':E'.$counter)->getFill()->setFillType(PHPExcel_Style_Fill::FILL_SOLID);
					            	$objPHPExcel->getActiveSheet(0)->getStyle('A'.$counter.':E'.$counter)->getFill()->getStartColor()->setARGB('DADADA');


								}
		           			$objPHPExcel->setActiveSheetIndex(0)->getStyle('A'.$counter.':E'.$counter.'')->applyFromArray($styleArrayBorderData);
		            		$objPHPExcel->setActiveSheetIndex(0)->getStyle('A'.$counter)->applyFromArray($styleArrayBorderAllData);
							$objPHPExcel->setActiveSheetIndex(0)->getStyle('B'.$counter)->applyFromArray($styleArrayBorderAllData);
							$objPHPExcel->setActiveSheetIndex(0)->getStyle('C'.$counter)->applyFromArray($styleArrayBorderAllData);
							$objPHPExcel->setActiveSheetIndex(0)->getStyle('D'.$counter)->applyFromArray($styleArrayBorderAllData);
							$objPHPExcel->setActiveSheetIndex(0)->getStyle('E'.$counter)->applyFromArray($styleArrayBorderAllData);
							
		            		$no++;
	            			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('A'.$counter, $no)
																->setCellValue('B'.$counter, $row->kodeUker)
																->setCellValue('C'.$counter, $row->vcrNmUnit)
																->setCellValue('D'.$counter, $row->kodeBulan)
																->setCellValue('E'.$counter, $row->jumlahmax);
							$counter = $counter+1;
   							$indeksumtotal = $counter-1;
		            	}
		            	if($no!=0)
		            	{
		            		$objPHPExcel->setActiveSheetIndex(0)->setCellValue('A'.$counter, 'JUMLAH TOTAL KUPON ')->mergeCells('A'.$counter.':D'.$counter.'')->getStyle('A'.$counter)->applyFromArray($styleArraySumarry);
          					$objPHPExcel->setActiveSheetIndex(0)->setCellValue('E'.$counter, "=SUM(E7:E".$indeksumtotal.")")->getStyle('E'.$counter)->applyFromArray($styleArraySumarry);
        					$objPHPExcel->getActiveSheet(0)->getStyle('A'.$counter.':E'.$counter)->getFill()->setFillType(PHPExcel_Style_Fill::FILL_SOLID);
			            	$objPHPExcel->getActiveSheet(0)->getStyle('A'.$counter.':E'.$counter)->getFill()->getStartColor()->setARGB('ffe4ba');

         		
		            	}

		            

		        }

	
				//get data rekening
				//$datakupon= $this->model_kupon->data_cariKuponkanca($idkanca,$periode);
				
			}

			$objPHPExcel->getActiveSheet()->setTitle('DAFTAR HADIAH');


				// Set active sheet index to the first sheet, so Excel opens this as the first sheet
				$objPHPExcel->setActiveSheetIndex(0);

				// Redirect output to a client’s web browser (Excel2007)
				//clean the output buffer
				ob_end_clean();

			

				//this is the header given from PHPExcel examples. but the output seems somewhat corrupted in some cases.
				//header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
				//so, we use this header instead.
				header('Content-type: application/vnd.ms-excel');
				header('Content-Disposition: attachment;filename="distribusi_kupon_kanca_'.$idkanca.'_periode_'.$_GET['id'].'.xlsx"');
				header('Cache-Control: max-age=0');

				$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
				$objWriter->save('php://output');

			//$xls->generateXML ( "output_name" );
		}	


		
		public function laporanUploadPemenang()
		{
			define("ENCRYPTION_KEY", "SUPERKEY");

			$tanngalMulai ="";
			$tanngalSelesai=""; 
			$no=0;
			$a=0;
	        $data_array = array();
	        $kodeperiode = $_GET['id'];

			if($_GET['id']==0)
			{


			}
			else{
				 	$this->load->helper('php-excel');
				 	$idkanca = $this->session->userdata('kode_kanca');

			

			 $pemenang = $this->model_mstperiodehadiah->pemenang($kodeperiode,$idkanca);

			 if (isset($pemenang)) 
              {
                foreach ($pemenang as $row) 
                {          
    
	             	    $no++;
               		   	$data_array[]= array($row->chrNoUndian, $row->chrNoRek,$row->vcrNmNsbh,$row->vcrNamaHadiah,$row->dtmTglAdd,$row->chrKdPeriode,$row->namaUker,$row->kodeUker,$row->chrJnsHadiah,$row->chrUserAdd);



                }



					header('Content-disposition: attachment; filename='.$idkanca .'_upload_pemenang.up');
					header('Content-type: text/plain');
					$angka  = rand(0,999);  
					$acak 	= json_encode($data_array);
					$data 	= preg_replace('/\s+/', '', $acak);
					
					$number = preg_replace('/[^0-9]/', '', $acak);
					$char 	=preg_replace('/\d/', '', $data );

					echo $angka."/";
					echo $number."/";
					$jumlah 	= strlen ($acak);
					$jumlahchar = strlen ($char);
					echo $jumlah."/";
					echo $jumlahchar."/";
					//echo $jumlah.'undiansimpedes';
					//echo $jumlah.'undiansimpedes';
					echo $acak;
					echo "/".$idkanca;

				//	echo $acak;

					//echo $encrypted = $this->encrypt($acak, ENCRYPTION_KEY);
					//echo $decrypted = $this->decrypt($encrypted, ENCRYPTION_KEY);

					//echo $acak;
					//echo "this is the file\n";
					//echo " you could generate content here, instead.";
						
				}

		}


	}


		public function EXPORT_CSV_REKENING()
		{
			$this->load->model('brisimpedes/model_undian');
			ini_set('max_execution_time', 0);
		
			$no=0;
			$a=0;
	        $data_array = array();
	        $kodeperiode = $_GET['id'];

			if($_GET['id']==0)
			{
				//noting to do
			}
			else{
			$idkanca 			= $this->session->userdata('kode_kanca');	
			$datarekening_show	= $this->model_kupon->data_show_all_Kupon($idkanca,$_GET['id']);
 		    $jumlah_kupon 		=$this->model_undian->get_maxundiandaridtlnomorundianPeriode($idkanca,$_GET['id']);

			$no=1;
	
		    header("Pragma: no-cache");
		    header("Expires: 0");
		    header('Content-Type: application/csv');
			header('Content-disposition: attachment; filename=KODE_'.$idkanca .'_TOTALKUPON_'.$jumlah_kupon.'.csv');
			$data_array = array("NO","NO REKENING","NAMA NASABAH","KODE UKER","KODE BULAN","KUPON AWAL","KUPON AKHIR","JUMLAH KUPON");
			 echo $this->csv($data_array);
	      	
			foreach ($datarekening_show as $row)
			     {
  		     	         $data_array = array($no,$row->NoRek,str_replace(',','',$row->namaNasabah),$row->kodeUker,$row->kodeBulan,$row->KuponAwal,$row->KuponAkhir,$row->KuponAkhir-$row->KuponAwal +1);
	      				 $no++;
	       				 echo $this->csv($data_array);


				 }				
			}
			$data_array = array("","","","","","","TOTAL",$jumlah_kupon);
 		    echo $this->csv($data_array);

	

		}

		public function laporanePemenangUndian()
		{
		 	$tanngalMulai ="";
			$tanngalSelesai=""; 
			$no=0;
			$a=0;
	        $data_array = array();
	        $kodeperiode = $_GET['id'];

			if($_GET['id']==0)
			{


			}
			else{
				 	$this->load->helper('php-excel');
				 	$idkanca = $this->session->userdata('kode_kanca');

				 	$hadiaharrayjumlah=array();
					$data['tanngalMulai'] = "";
					$data['tanngalSelesai'] ="";
					$data['kode_user']=$this->session->userdata('kode_user');
					$data['nama_user'] = $this->session->userdata('nama_user');
					$data['kode_kanca'] = $this->session->userdata('kode_kanca');
					$data['group_area'] = $this->session->userdata('group_area');
					$data['otoritas'] = $this->session->userdata('otoritas');
					$data['kodekanwil'] = $this->session->userdata('kanwil');
					$idkanca = $this->session->userdata('kode_kanca');
					$data['penangungjawab']=''; 

					//penyelenggara undian
					$PenyelenggaraUndian = $this->model_mstperiodehadiah->penanggungjawabPemenang($kodeperiode,$idkanca);

				
				 	$periodeRange = $this->model_mstperiodehadiah->data_periode_kanca($idkanca,$_GET['id']);
					$periodetamp = explode("=",$periodeRange);
					for($i=0 ; $i<2; $i++)
					{
						 $tanggalLengkap = explode("-",$periodetamp[$i]);
						 $tahun = $tanggalLengkap[0];
						 $tanggal = $tanggalLengkap[2];
						 $bulan = $tanggalLengkap[1];
						 if($bulan == '01'){$bulan = "Januari";}
						 else if($bulan == '02'){$bulan = "Februari";}
						 else if($bulan == '03'){$bulan = "Maret";}
						 else if($bulan == '04'){$bulan = "April";}
						 else if($bulan == '05'){$bulan = "Mei";}
						 else if($bulan == '06'){$bulan = "Juni";}
						 else if($bulan == '07'){$bulan = "Juli";}
						 else if($bulan == '08'){$bulan = "Agustus";}
						 else if($bulan == '09'){$bulan = "September";}
						 else if($bulan == '10'){$bulan = "Oktober";}
						 else if($bulan == '11'){$bulan = "November";}
						 else if($bulan == '12'){$bulan = "Desember";}

						 if($i==0){$tanngalMulai = $tanggal." ".$bulan." ".$tahun." s/d ";}
						 if($i==1){$tanngalSelesai= $tanggal." ".$bulan." ".$tahun;}
						  
					}
					//generate 

				// Create new PHPExcel object
				$objPHPExcel = new PHPExcel();
				//PROPERTIS
				$objPHPExcel->getProperties()->setCreator("Admin kantorcabang");
				$objPHPExcel->getProperties()->setTitle("Report pemenang kupon di tiap unit");
				$objPHPExcel->getProperties()->setSubject("Pemenang Distribusi undian");
				$objPHPExcel->getProperties()->setDescription("laporan pememanang unit kantor cabang untuk pengundian simpedes");

				//STYLE 
				$styleArraySumarryTanggal = array(
				'font' => array(
					'bold' => true,
					'name' => 'Tahoma',
					'size' => 10
				),
				'alignment' => array(
					'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_LEFT,
					'vertical' => PHPExcel_Style_Alignment::VERTICAL_CENTER
				)
			   );

				$styleArrayBorder = array(
				'borders' => array(
					'allborders' => array(
						'style' => PHPExcel_Style_Border::BORDER_THIN					)
				),
				'font' => array(
					'bold' => true,
					'name' => 'Tahoma',
					'size' => 10
				),
				'alignment' => array(
					'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER,
					'vertical' => PHPExcel_Style_Alignment::VERTICAL_CENTER
				)
			   );

				//SET STYLE SUBDATA
				$styleArrayBorderData = array(
					'font' => array(
					'name' => 'Tahoma',
					'size' => 10
				)

			   );

				$styleArrayjudul = array(
				'font' => array(
					'bold' => true,
					'name' => 'Tahoma',
					'size' => 10
				),
				'alignment' => array(
					'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER,
					'vertical' => PHPExcel_Style_Alignment::VERTICAL_CENTER
				)
			   );


			$styleArraySubJudul = array(
				'font' => array(
					'bold' => true,
					'name' => 'Tahoma',
					'size' => 10
				),
				'alignment' => array(
					'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER,
					'vertical' => PHPExcel_Style_Alignment::VERTICAL_CENTER
				),
				'borders' => array(
				  'allborders' => array(
					      'style' => PHPExcel_Style_Border::BORDER_HAIR,
					    )
				   )
	
			   );

				$styleArrayPenanggungjawab = array(
				'font' => array(
					'bold' => true,
					'name' => 'Tahoma',
					'size' => 10
				),
				'alignment' => array(
					'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER,

					'vertical' => PHPExcel_Style_Alignment::VERTICAL_CENTER
				)
	
			   );

				$styleArrayPenanggungjawabNama = array(
				'font' => array(
					'bold' => true,
					'name' => 'Tahoma',
					'size' => 10,
				    'underline' => PHPExcel_Style_Font::UNDERLINE_SINGLE
				),
				'alignment' => array(
					'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER,
					
					'vertical' => PHPExcel_Style_Alignment::VERTICAL_CENTER
				)
	
			   );



				$styleArraySumarry = array(
				'font' => array(
					'bold' => true,
					'name' => 'Tahoma',
					'size' => 10
				),
				'alignment' => array(
					'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_RIGHT,
					'vertical' => PHPExcel_Style_Alignment::VERTICAL_CENTER
				)
			   );

			    $styleArrayNamaHadiah = array(
				'font' => array(
					'bold' => true,
					'name' => 'Tahoma',
					'size' => 10
				),
				'alignment' => array(
					'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_LEFT,
					'vertical' => PHPExcel_Style_Alignment::VERTICAL_CENTER
				),
				'borders' => array(
					  'allborders' => array(
						      'style' => PHPExcel_Style_Border::BORDER_HAIR
						    ),
					  	'right' => array(
						      'style' => PHPExcel_Style_Border::BORDER_HAIR
						    )
				    )
	
			   );

			    $styleArrayBorderAllData = array(
					'font' => array(
					'name' => 'Tahoma',
					'size' => 10
				),
				'borders' => array(
					  'left' => array(
						      'style' => PHPExcel_Style_Border::BORDER_HAIR,
						    ),
				    'right' => array(
				      'style' => PHPExcel_Style_Border::BORDER_HAIR,
				    )
						  
					)
				
			   );

			//magre cell judul
			    // echo indonesian_date(date("l"));

			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('A1', 'PT.BANK RAKYAT INDONESIA (PERSERO), Tbk')->mergeCells('A1:F1')->getStyle('A1')->applyFromArray($styleArrayjudul);
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('A2', "Daftar Pemenang Undian Simpedes - Kode Branch ".$idkanca."")->mergeCells('A2:F2')->getStyle('A2')->applyFromArray($styleArrayjudul);
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('A3', "Periode ".$tanngalMulai."".$tanngalSelesai."")->mergeCells('A3:F3')->getStyle('A3')->applyFromArray($styleArrayjudul);
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('A5', "Hari / Tanggal Cetak : ".$this->indonesian_date(date("l")) . date("d-m-Y"))->mergeCells('A5:D5')->getStyle('A5')->applyFromArray($styleArraySumarryTanggal);



			$objPHPExcel->setActiveSheetIndex(0)->getColumnDimension('A')->setAutoSize(true);
			$objPHPExcel->setActiveSheetIndex(0)->getColumnDimension('B')->setWidth(14);
			$objPHPExcel->setActiveSheetIndex(0)->getColumnDimension('C')->setWidth(13);
			$objPHPExcel->setActiveSheetIndex(0)->getColumnDimension('D')->setAutoSize(true);
			$objPHPExcel->setActiveSheetIndex(0)->getColumnDimension('E')->setAutoSize(true);
			$objPHPExcel->setActiveSheetIndex(0)->getColumnDimension('F')->setWidth(15);
		
			//style dokumen
			$objPHPExcel->setActiveSheetIndex(0)->getStyle('A7:F7')->applyFromArray($styleArraySubJudul);

			//fill pemenang
			 $objPHPExcel->getActiveSheet(0)->getStyle('A7:F7')->getFill()->setFillType(PHPExcel_Style_Fill::FILL_SOLID);
             $objPHPExcel->getActiveSheet(0)->getStyle('A7:F7')->getFill()->getStartColor()->setARGB('ffe4ba');



			// Add data FOR JUDUL FIELD
	//$field_array[] = array ("No", "No Undian", "Nomor Rekening", "Nama Pemenang", "Unit Kerja", "Waktu Pengundian");
				     		
     		$objPHPExcel->setActiveSheetIndex(0)
		        ->setCellValue('A7', 'NO')
		        ->setCellValue('B7', 'No Kupon')
   		        ->setCellValue('C7', 'Nomor Rekening')
		        ->setCellValue('D7', 'Nama Pemenang')
		        ->setCellValue('E7', 'Unit Kerja')
		        ->setCellValue('F7', 'Waktu Pengundian');

			
			


			$Jumlahjenis = array();
			$Jumlahjenishadiah = $this->model_mstperiodehadiah->pemenangTiapHadiah($kodeperiode,$idkanca);
 			$penaggungjawab= $this->model_mstperiodehadiah->laporanAprovalPemenang($kodeperiode,$idkanca);

 			foreach ($Jumlahjenishadiah as $row) {
				$jumlah = $this->model_mstperiodehadiah->get_jumlahPemenangUndian($idkanca,$row->chrJnsHadiah,$_GET['id']);
				array_push($Jumlahjenis,$jumlah);
			}


			if (isset($_GET['idp']) && $_GET['idp'] !='0' )
		 	{
			 	 $pemenang  = $this->model_mstperiodehadiah->pemenanghadiah($kodeperiode,$_GET['idp'],$idkanca);
		    }
		    else
		    {
				 $pemenang = $this->model_mstperiodehadiah->pemenang($kodeperiode,$idkanca);
		    }


			 if (isset($pemenang)) 
              {
              	$a=0;
              	$counter = 8;
              	$no=0;
              	$jumlahpemenang = 0;
                foreach ($pemenang as $row) 
                {          
    
	             	    $no++;
      
                        if($no==1){

//                        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('A'.$counter, "Hadiah : ".$row->vcrNamaHadiah);
                        $objPHPExcel->setActiveSheetIndex(0)->setCellValue('A'.$counter, "Hadiah ".$row->varJenisHadiah." ".$row->varTypeHadiah." ".$row->varMerkHadiah)->mergeCells('A'.$counter.':F'.$counter)->getStyle('A'.$counter)->applyFromArray($styleArrayNamaHadiah);
						$objPHPExcel->getActiveSheet(0)->getStyle('A'.$counter.':F'.$counter)->getFill()->setFillType(PHPExcel_Style_Fill::FILL_SOLID);
		            	$objPHPExcel->getActiveSheet(0)->getStyle('A'.$counter.':F'.$counter)->getFill()->getStartColor()->setARGB('B9EDF0');
							

					    $data_array[] = array("Hadiah ".$row->vcrNamaHadiah);
				     	$counter = $counter+1;
						$indeksumtotal = $counter-1;

               		   	}

               		   		if($counter%2==1)
								{
									
									$objPHPExcel->getActiveSheet(0)->getStyle('A'.$counter.':F'.$counter)->getFill()->setFillType(PHPExcel_Style_Fill::FILL_SOLID);
					            	$objPHPExcel->getActiveSheet(0)->getStyle('A'.$counter.':F'.$counter)->getFill()->getStartColor()->setARGB('EAEAEA');


								}


           		   		$objPHPExcel->setActiveSheetIndex(0)->getStyle('A'.$counter.':F'.$counter.'')->applyFromArray($styleArrayBorderData);
	            		$objPHPExcel->setActiveSheetIndex(0)->getStyle('A'.$counter)->applyFromArray($styleArrayBorderAllData);
						$objPHPExcel->setActiveSheetIndex(0)->getStyle('B'.$counter)->applyFromArray($styleArrayBorderAllData);
						$objPHPExcel->setActiveSheetIndex(0)->getStyle('C'.$counter)->applyFromArray($styleArrayBorderAllData);
						$objPHPExcel->setActiveSheetIndex(0)->getStyle('D'.$counter)->applyFromArray($styleArrayBorderAllData);
						$objPHPExcel->setActiveSheetIndex(0)->getStyle('E'.$counter)->applyFromArray($styleArrayBorderAllData);
						

	            		$objPHPExcel->setActiveSheetIndex(0)->setCellValue('A'.$counter, $no)
															->setCellValueExplicit('B'.$counter, "".$row->chrNoUndian,PHPExcel_Cell_DataType::TYPE_STRING)
															->setCellValueExplicit('C'.$counter, "".$row->chrNoRek.'',PHPExcel_Cell_DataType::TYPE_STRING)
															->setCellValue('D'.$counter, $row->vcrNmNsbh)
															->setCellValue('E'.$counter, $row->namaUker)
															->setCellValue('F'.$counter, $row->dtmTglAdd);


           		   		$objPHPExcel->setActiveSheetIndex(0)->getStyle('B'.$counter)->getNumberFormat()->setFormatCode( PHPExcel_Style_NumberFormat::FORMAT_TEXT );

						$counter = $counter+1;
						$indeksumtotal = $counter-1;
		              	$jumlahpemenang ++;



               		   	$data_array[]= array($no, $row->chrNoUndian, $row->chrNoRek,$row->vcrNmNsbh,$row->vcrNamaHadiah,$row->dtmTglAdd);

	                    if($no==$Jumlahjenis[$a]){
     				 		$no=0;
                     	$a++;
                  		}

                }

                $objPHPExcel->setActiveSheetIndex(0)->setCellValue('A'.$counter, "TOTAL PEMENANG :  ". $jumlahpemenang)->mergeCells('A'.$counter.':F'.$counter)->getStyle('A'.$counter)->applyFromArray($styleArrayNamaHadiah);
  				$objPHPExcel->getActiveSheet(0)->getStyle('A'.$counter.':F'.$counter)->getFill()->setFillType(PHPExcel_Style_Fill::FILL_SOLID);
		        $objPHPExcel->getActiveSheet(0)->getStyle('A'.$counter.':F'.$counter)->getFill()->getStartColor()->setARGB('ffe4ba');
				

			 foreach ($PenyelenggaraUndian as $row) {
			     // echo $row->chrPngJwb1;
			      //echo $row->chrJbtPj1;
			      //echo $row->chrPngJwb2;
			      //echo $row->chrJbtPj2;
			      //echo $row->chrNotaris;
			      //echo $row->chrJbtN;
			      //echo $row->chrSaksi1;
			      //echo $row->chrJbtS1; 
			      //echo $row->chrSaksi2;
			      //echo $row->chrJbtS2;
			      //echo $row->chrSaksi3;
			      //echo $row->chrJbtS3;
  				//$objPHPExcel->setActiveSheetIndex(0)->setCellValue('D'.($counter+2),)->getStyle('D'.($counter+2))->applyFromArray($styleArrayPenanggungjawab);
			
				$objPHPExcel->setActiveSheetIndex(0)->setCellValue('C'.($counter+8), "")->getStyle('C'.($counter+4))->applyFromArray($styleArrayPenanggungjawab);
				$objPHPExcel->setActiveSheetIndex(0)->setCellValue('C'.($counter+9), $row->chrSaksi2)->getStyle('C'.($counter+9))->applyFromArray($styleArrayPenanggungjawabNama);
				$objPHPExcel->setActiveSheetIndex(0)->setCellValue('C'.($counter+10), $row->chrJbtS2)->getStyle('C'.($counter+10))->applyFromArray($styleArrayPenanggungjawab);
			
				if($row->chrJbtS3!=""){
				
				$objPHPExcel->setActiveSheetIndex(0)->setCellValue('D'.($counter+8), "")->getStyle('D'.($counter+4))->applyFromArray($styleArrayPenanggungjawab);
				$objPHPExcel->setActiveSheetIndex(0)->setCellValue('D'.($counter+9), $row->chrSaksi3)->getStyle('D'.($counter+9))->applyFromArray($styleArrayPenanggungjawabNama);
				$objPHPExcel->setActiveSheetIndex(0)->setCellValue('D'.($counter+10), $row->chrJbtS3)->getStyle('D'.($counter+10))->applyFromArray($styleArrayPenanggungjawab);
				}


				$objPHPExcel->setActiveSheetIndex(0)->setCellValue('C'.($counter+2), "Mengesahkan,")->mergeCells('C'.($counter+2).':D'.($counter+2))->getStyle('C'.($counter+2))->applyFromArray($styleArrayPenanggungjawab);
				$objPHPExcel->setActiveSheetIndex(0)->setCellValue('C'.($counter+5), $row->chrSaksi1)->getStyle('C'.($counter+5))->applyFromArray($styleArrayPenanggungjawabNama);
				$objPHPExcel->setActiveSheetIndex(0)->setCellValue('C'.($counter+6), $row->chrJbtS1)->getStyle('C'.($counter+6))->applyFromArray($styleArrayPenanggungjawab);
				

				$objPHPExcel->setActiveSheetIndex(0)->setCellValue('D'.($counter+4), "")->getStyle('F'.($counter+4))->applyFromArray($styleArrayPenanggungjawab);
				$objPHPExcel->setActiveSheetIndex(0)->setCellValue('D'.($counter+5), $row->chrNotaris)->getStyle('D'.($counter+5))->applyFromArray($styleArrayPenanggungjawabNama);
				$objPHPExcel->setActiveSheetIndex(0)->setCellValue('D'.($counter+6), $row->chrJbtN)->getStyle('D'.($counter+6))->applyFromArray($styleArrayPenanggungjawab);
				

  				$objPHPExcel->setActiveSheetIndex(0)->setCellValue('E'.($counter+2), "PT Bank Rakyat Indonesia (Persero), Tbk ")->getStyle('E'.($counter+2))->applyFromArray($styleArrayPenanggungjawab);
				$objPHPExcel->setActiveSheetIndex(0)->setCellValue('E'.($counter+4), "")->getStyle('F'.($counter+4))->applyFromArray($styleArrayPenanggungjawab);
				$objPHPExcel->setActiveSheetIndex(0)->setCellValue('E'.($counter+5), $row->chrPngJwb1)->getStyle('E'.($counter+5))->applyFromArray($styleArrayPenanggungjawabNama);
				$objPHPExcel->setActiveSheetIndex(0)->setCellValue('E'.($counter+6), $row->chrJbtPj1)->getStyle('E'.($counter+6))->applyFromArray($styleArrayPenanggungjawab);
											

			 	}

  				//$objPHPExcel->setActiveSheetIndex(0)->setCellValue('E'.($counter+1), "Mengesahkan")->mergeCells('E'.($counter+1).':F'.($counter+1))->getStyle('E'.($counter+1))->applyFromArray($styleArrayPenanggungjawab);
				//$objPHPExcel->setActiveSheetIndex(0)->setCellValue('E'.($counter+2), "-ttd-")->mergeCells('E'.($counter+2).':F'.($counter+2))->getStyle('E'.($counter+2))->applyFromArray($styleArrayPenanggungjawab);
				//$objPHPExcel->setActiveSheetIndex(0)->setCellValue('E'.($counter+3), $penaggungjawab)->mergeCells('E'.($counter+3).':F'.($counter+3))->getStyle('E'.($counter+3))->applyFromArray($styleArrayPenanggungjawab);
							


					//generate
			 	//	$judul_array[] = array("PT.BANK RAKYAT INDONESIA (PERSERO), Tbk");
			 	//	$subjudul_array[] = array("Daftar Pemenang Undian Simpedes - Kode Branch ".$idkanca );
			 	//	$periodejudul_array[] = array("Periode ".$tanngalMulai."".$tanngalSelesai."");
			 	//	$periodejudul_array[] = array(" ");
		//
				//	$penanggungjawab[] = array("","","","","","Penaggung Jawab");		
				//	$penanggungjawab[] = array(" ");
 				//	$penanggungjawab[] = array("","","","","",$penaggungjawab);						

			 	//	$xls = new Excel_XML;

				//	$xls->addArray ($judul_array);
				//	$xls->addArray ($subjudul_array);
				//	$xls->addArray ($periodejudul_array);

				//	$xls->addArray ($field_array);
				//	$xls->addArray ($data_array);
				//	$xls->addArray($penanggungjawab);

					//print_r($data_array);
						
						
					//$xls->generateXML ( "laporan_Pemenang_kanca_".$idkanca."_periode_".$_GET['id'] );
						
				}

				$objPHPExcel->getActiveSheet()->setTitle('DAFTAR PEMENANG');


				// Set active sheet index to the first sheet, so Excel opens this as the first sheet
				$objPHPExcel->setActiveSheetIndex(0);

				// Redirect output to a client’s web browser (Excel2007)
				//clean the output buffer
				ob_end_clean();

			

				//this is the header given from PHPExcel examples. but the output seems somewhat corrupted in some cases.
				//header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
				//so, we use this header instead.
				header('Content-type: application/vnd.ms-excel');
				header('Content-Disposition: attachment;filename="Data_Pemenang_kanca_'.$idkanca.'_periode_'.$_GET['id'].'.xlsx"');
				header('Cache-Control: max-age=0');

				$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
				$objWriter->save('php://output');
			}

		}


	

}

/*
const BORDER_NONE = 'none';
const BORDER_DASHDOT = 'dashDot';
const BORDER_DASHDOTDOT = 'dashDotDot';
const BORDER_DASHED = 'dashed';
const BORDER_DOTTED = 'dotted';
const BORDER_DOUBLE = 'double';
const BORDER_HAIR = 'hair';
const BORDER_MEDIUM = 'medium';
const BORDER_MEDIUMDASHDOT = 'mediumDashDot';
const BORDER_MEDIUMDASHDOTDOT = 'mediumDashDotDot';
const BORDER_MEDIUMDASHED = 'mediumDashed';
const BORDER_SLANTDASHDOT = 'slantDashDot';
const BORDER_THICK = 'thick';
const BORDER_THIN = 'thin';
*/
?>
