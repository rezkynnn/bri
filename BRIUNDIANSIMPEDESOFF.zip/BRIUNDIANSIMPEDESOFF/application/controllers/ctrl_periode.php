<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class ctrl_periode extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -  
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in 
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see http://codeigniter.com/user_guide/general/urls.html
	 */

	public function __construct()
	{
		parent::__construct();
		$this->load->model('brisimpedes/model_mstuker');
		$this->load->model('brisimpedes/model_mstuser');
		$this->load->model('brisimpedes/model_mstperiodehadiah');
		
		//$this->load->model('model_mstperiode');
	}

	public function index()
	{
		$data['kode_user']=$this->session->userdata('kode_user');
		$data['nama_user'] = $this->session->userdata('nama_user');
		$data['kode_kanca'] = $this->session->userdata('kode_kanca');
		$data['group_area'] = $this->session->userdata('group_area');
		$data['otoritas'] = $this->session->userdata('otoritas');
		$data['kodekanwil'] = $this->session->userdata('kanwil');
		$otoritas = $this->session->userdata('otoritas');
		
		if(isset($otoritas) && $otoritas == "5")
		{

		 	if (isset($_GET['prov']))
		 	{

		// 	$data['provin'] = $_GET['prov'];
		 //	$ok=$this->model_mstuker->data_kab($_GET['prov']); 
		 	//$data['dataprovin'] = $ok;
		 	}

			$idkanca = '206';
			$data['page'] = 'data_periode/view_dataperiode';
			$data['menu'] = 'main_dashboard';
			$data['data'] = $this->model_mstperiodehadiah->data_periode();

		//	$data['id'] = "";
		//	$data['provinsi'] = $this->model_mstuker->data_provinsi();
			$data['kanwil'] = $this->model_mstuker->data_kanwil();
			$this->load->view("layouts/fix", $data);

		}
		else
		{
			//echo "hay".$this->session->userdata('otoritas');
			//echo $this->session->userdata('kode_user');
			//echo $this->session->userdata('nama_user');
			//echo $this->session->userdata('kode_kanca');
			//echo "hay";
		
		   redirect('menu/logout');
		}

	}

	public function tambahPeriodeKanca()
	{	$data['kode_user']=$this->session->userdata('kode_user');
		$data['nama_user'] = $this->session->userdata('nama_user');
		$data['kode_kanca'] = $this->session->userdata('kode_kanca');
		$data['group_area'] = $this->session->userdata('group_area');
		$data['otoritas'] = $this->session->userdata('otoritas');
		$data['kodekanwil'] = $this->session->userdata('kanwil');
		$otoritas = $this->session->userdata('otoritas');

		if(isset($otoritas) && $otoritas=="5")
		{
		$data['gropuarea'] =$this->model_mstuser->data_grouparea();
		$data['kanwil'] = $this->model_mstuker->data_kanwil();
		$data['kanca'] = $this->model_mstuser->data_kanca();
		$data['page'] = 'data_periode/view_tambahperiode';
		$data['menu'] = 'main_dashboard';
		$this->load->view("layouts/fix", $data);
		}
		else
		{
			echo $otoritas;
		//redirect('menu/logout');
		}
	}

	public function simpan_periode()
	{

		$periode = $this->input->post('periode');
		$periode1 = $this->input->post('lamaperiode');
		$tahun = $this->input->post('tahun');
		if($periode < 10)
		{
			$char = '0'.$periode.$tahun;
			
		}
		else
		{
			$char = $periode.$tahun;
		}
		$dateAhir = $this->input->post('dtmTglA');
		$jumlahG = $this->input->post('numJmlG');
		$jmlUtama = $this->input->post('numJmlU');
		$jmlBiasa = $this->input->post('numJmlBiasa');
	    $jmlHiburan = $this->input->post('numJmlHiburan');
				

	     $insert = array(
				'dtmTglAwal' => $this->input->post('dtmTglAwala'),
				'periodeJumlah' => $this->input->post('lamaperiode'),
				'dtmTglAkhir' => $this->input->post('dtmTglA'),
				'numSaldoMin' => $this->input->post('minimalsaldo'),
				'numKoef' => $this->input->post('numKoef'),
				'numJmlGrandprize' => $this->input->post('numJmlG'),
				'numJmlUtama' => $this->input->post('numJmlU'),
				'numJmlBiasa' => $this->input->post('numJmlBiasa'),
				'numJmlHiburan' => $this->input->post('numJmlHiburan'),
				'chrKdPeriode' => $char,
				'chrUserAdd' =>$this->session->userdata('kode_user')

			);

		$this->model_mstperiodehadiah->add_periode($insert,$char,$dateAhir,$jumlahG, $jmlUtama,$jmlBiasa,$jmlHiburan,$this->session->userdata('kode_user'));
		//echo $char;
		redirect('ctrl_periode');



	}

	public function simpanedit_periode()
	{
		$data['kode_user']=$this->session->userdata('kode_user');
		$data['nama_user'] = $this->session->userdata('nama_user');
		//$

//		$periode = $this->input->post('periode');
//		$periode1 = $this->input->post('lamaperiode');
//		$tahun = $this->input->post('tahun');
		$char = $this->input->post('kodeperiode');
		$dateAhir = $this->input->post('dtmTglA');
		$jumlahG = $this->input->post('numJmlG');
		$jmlUtama = $this->input->post('numJmlU');
		$jmlBiasa = $this->input->post('numJmlBiasa');
	    $jmlHiburan = $this->input->post('numJmlHiburan');
				

	     $insert = array(
				'dtmTglAwal' => $this->input->post('dtmTglAwala'),
				//'periodeJumlah' => $this->input->post('lamaperiode'),
				'dtmTglAkhir' => $this->input->post('dtmTglA'),
				'numSaldoMin' => $this->input->post('minimalsaldo'),
				'numKoef' => $this->input->post('numKoef'),
				'numJmlGrandprize' => $this->input->post('numJmlG'),
				'numJmlUtama' => $this->input->post('numJmlU'),
				'numJmlBiasa' => $this->input->post('numJmlBiasa'),
				'numJmlHiburan' => $this->input->post('numJmlHiburan'),
				//'chrKdPeriode' => $char,
				'chrUserEdit' =>$this->session->userdata('kode_user')

			);

	    //echo $char = $this->input->post('kodeperiode');
		$this->model_mstperiodehadiah->updateperiode($insert,$char,$dateAhir,$jumlahG, $jmlUtama,$jmlBiasa,$jmlHiburan,$this->session->userdata('kode_user'));

		redirect('ctrl_periode');



	}

	public function editUserKanca()
	{
		$kodekanca="206";
		if (isset($_GET['kodeUser']))
		 {

		 	$data['kodeUser'] = $_GET['kodeUser'];
		 	$ok=$this->model_mstuser->getdata_user($kodekanca,$_GET['kodeUser']); 
		 	$data['datauser'] = $ok;
		 }
		 
		$data['gropuarea'] =$this->model_mstuser->data_grouparea();
		$data['kanca'] = $this->model_mstuser->data_kanca();


		$data['page'] = 'data_user/view_edituser';
		$data['menu'] = 'main_dashboard';
		//$data['data'] = $this->model_mstuker->data_unit();
		//$data['data'] = $this->model_mstuker->data_unit();
		//$data['getdataunit'] = $this->model_mstuker->getdata_unit($_GET['idkode']);
		//$data['provinsi'] = $this->model_mstuker->data_provinsi();
		$data['kanwil'] = $this->model_mstuker->data_kanwil();
	//	$data['id'] =$_GET['idkode'];
		$this->load->view("layouts/fix", $data);
	}

	public function editperiode()
	{
		$data['kode_user']=$this->session->userdata('kode_user');
		$data['nama_user'] = $this->session->userdata('nama_user');
		$data['kode_kanca'] = $this->session->userdata('kode_kanca');
		$data['group_area'] = $this->session->userdata('group_area');
		$data['otoritas'] = $this->session->userdata('otoritas');
		$data['kodekanwil'] = $this->session->userdata('kanwil');
		$otoritas = $this->session->userdata('otoritas');
		
		if (isset($_GET['period']))
		 {
		 	$data['periode']= $this->model_mstperiodehadiah->data_periode_undian($_GET['period']);


		 }
		 
		$data['page'] = 'data_periode/view_editperiode';
		$data['menu'] = 'main_dashboard';
		//$data['data'] = $this->model_mstuker->data_unit();
		//$data['data'] = $this->model_mstuker->data_unit();
		//$data['getdataunit'] = $this->model_mstuker->getdata_unit($_GET['idkode']);
		//$data['provinsi'] = $this->model_mstuker->data_provinsi();
		$data['kanwil'] = $this->model_mstuker->data_kanwil();
	//	$data['id'] =$_GET['idkode'];
		$this->load->view("layouts/fix", $data);
	}


	public function list_user()
	{
		$data['page'] = 'v_list_user';
		$data['menu'] = 'main_dashboard';

		$data['list_a'] = $this->m_pingpong->list_a();
		$data['list_b'] = $this->m_pingpong->list_b();
		$data['list_c'] = $this->m_pingpong->list_c();

		$this->load->view("layouts/fix", $data);
	}

	public function add_member()
	{
		$insert = array(
				'nama_member' => $this->input->post('nama_member'),
				'bagian' => $this->input->post('bagian'),
				'email' => $this->input->post('email'),
				'no_telp' => $this->input->post('no_telp'),
				'group' => $this->input->post('group')
			);
		$this->m_pingpong->add_member($insert);

		redirect('c_pingpong/list_user');
	}

	public function delete_member($id_member)
	{
		$this->m_pingpong->delete_member($id_member);

		redirect('c_pingpong/list_user/');
	}


	public function delete_periode()
	{
		$this->model_mstperiodehadiah->delete_period($_GET['idkode']);
		redirect('ctrl_periode');
	}

	public function detail_periode()
	{
				

			$id = $_REQUEST['name'];
			$this->load->helper('url');
			//echo $id;
			$ok=$this->model_mstperiodehadiah->tmpbanyakperiode();

            if (isset($ok)) 
              {
                foreach ($ok as $row) 
                {
                	 echo "<option value='".$row->banyakBulan."'>".$row->banyakPeriode."</option>";
                    
                 
                }



             }

	}

	function ajax_call() {

			//$id = $_REQUEST['name'];
			//$this->load->helper('url');
			//echo $id;
		if(isset($_GET['banyak']))
		{
			$ok=$this->model_mstperiodehadiah->tmpbanyakperiode($_GET['banyak']);

            if (isset($ok) && $ok!=null) 
              {
                foreach ($ok as $row) 
                {
                	$pbo_slp[$row ->banyak] = "periode ke-".$row ->banyak;
                	 //echo "<option value='".$row->banyakBulan."'>".$row->banyakPeriode."</option>";
                    
                }

             }
             else{
             		$pbo_slp = array();
             	}
             	print form_dropdown('periode',$pbo_slp);


			}
		}

		



/*
		if(isset($_POST) && isset($_POST['slp_id'])) {
			$slp_id = $_POST['slp_id'];
			$pbo = $this -> m_nasabah -> get_pbo($slp_id);

			if($pbo != NULL) {
				foreach ($pbo as $row) {
					$pbo_slp[$row -> id] = $row -> id;
				}
			} else {
				$pbo_slp = array();
			}

			print form_dropdown('pba_id',$pbo_slp);
		} else {
			redirect('c_cari');
		}
		*/
	




	

	
}