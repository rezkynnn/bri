<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class downloadundianoffline extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -  
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in 
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see http://codeigniter.com/user_guide/general/urls.html
	 */

	public function __construct()
	{
		    parent::__construct();
			$this->load->model('brisimpedes/model_mstuser');
			$this->load->model('brisimpedes/model_mstperiodehadiah');
			$this->load->model('brisimpedes/model_kupon');
			

			

	}

	public function index()
	{	
		$idkanca 				= $this->session->userdata('kode_kanca');
        $commandMysql 			= 'sh cekdir.sh /opt/lampp/var/mysql/';
        $commandXamp 			= 'sh cekdir.sh /opt/lampp/';
        $commandWebsever 		= 'sh cekdir.sh /opt/lampp/htdocs/';

        $cobaMysql				= exec ($commandMysql);
        if($cobaMysql==1)
        {
        	$cobaMysql = '*mysql telah siap';
        }
        else
        {
			$cobaMysql = '*mysql belum terpasang';
        }

        $cobaXamp				= exec ($commandXamp);
        if($cobaXamp==1)
        {
        	$cobaXamp = '*xamp telah siap';
        }
        else
        {
			$cobaXamp = '*xamp belum terpasang';
        }
        

        $cobaWebserver			= exec ($commandWebsever);
        if($cobaWebserver==1)
        {
        	$cobaWebserver = '*webserver telah siap';
        }
        else
        {
			$cobaWebserver = '*webserver belum terpasang';
        }


		$data['cari'] 			= '';
		$data['pilihperiode'] 	= '0';
		$data["periode"]		= $this->	model_mstperiodehadiah	->data_mstperiode();	
		$data['datanokupon'] 	= ""; 
		$data['kode_user']		= $this->session->userdata('kode_user');
		$data['nama_user'] 		= $this->session->userdata('nama_user');
		$data['kode_kanca'] 	= $this->session->userdata('kode_kanca');
		$data['group_area'] 	= $this->session->userdata('group_area');
		$data['otoritas'] 		= $this->session->userdata('otoritas');
		$data['kodekanwil'] 	= $this->session->userdata('kanwil');
		$idkanca				= $this->session->userdata('kode_kanca');
		$data['id_kanca'] 		= md5($idkanca);
		
		$data['page'] 			= 'pengundian_offline/view_download_parameter';
		$data['menu'] 			= 'main_dashboard';
		$data['folderxamp'] 	=  $cobaXamp;
		$data['foldermysql'] 	=  $cobaMysql;
		$data['folderwebserver']=  $cobaWebserver;
		
		$this->load->view("layouts/fix", $data);	
	}

	public function createdatabase()
	{
		$idkanca 	= $this->session->userdata('kode_kanca');

		//drop database
		error_reporting(E_ALL ^ E_DEPRECATED);
		$link = mysql_connect('localhost', 'root', '');
		if (!$link) {
		    die('Could not connect: ' . mysql_error());
		}

		$sql1 = 'DROP DATABASE off_'.$idkanca;
		if (mysql_query($sql1, $link)) {
		    //echo "Database my_db created successfully\n";
		    //echo "2";

		} else {
		    echo 'Error drop database: ' . mysql_error() . "\n";
		}


		


		$sql = 'CREATE DATABASE IF NOT EXISTS off_'.$idkanca;
		if (mysql_query($sql, $link)) {
		    //echo "Database my_db created successfully\n";
		    echo "1";

		} else {
		    echo 'Error creating database: ' . mysql_error() . "\n";
		}

	}

	public function backupdatabase()
	{ 
		//echo 'backupdaa';
	      //ENTER THE RELEVANT INFO BELOW
        $mysqlDatabaseName 	='db_kc_s206';
        $mysqlUserName 		='root';
        $mysqlPassword 		='';
        $mysqlHostName 		='localhost';
        $mysqlExportPath 	='chooseFilenameForBackup.sql';
		$kanca= '206';
        $database = md5($kanca);

        //DO NOT EDIT BELOW THIS LINE
        //Export the database and output the status to the page
       // $command='mysqldump --opt -h' .$mysqlHostName .' -u' .$mysqlUserName .' -p' .$mysqlPassword .' ' .$mysqlDatabaseName .' > ~/'.$mysqlExportPath;
        $command 			= 'sh play.sh '. $database;
        //$command 			='echo 02132 | sudo -S /opt/lampp/bin/mysqldump --login-path=local -e  db_kc_s206 > /opt/lampp/htdocs/BRIUNDIANSIMPEDES/download/dumpmsql.sql';
        //$coba 				= exec ($command);
        passthru( $command  );

      //  echo 1;
   
	}	

	public function cekdatabase()
	{

//		SHOW DATABASES as LIKE 'off_206';
	}
	
	
}