<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Welcome extends CI_Controller {

	function __construct()
		{
			parent::__construct();
			$this->load->model('model_pekerja');
		}


	public function index()
	{
		//$data['pekerja']=$this->model_pekerja->all_pekerja();
		
		$this->load->view('teslock');
	}


	public function coba(){
		$this->load->view('testlock');
	}
}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */
