<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class instalasi extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -  
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in 
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see http://codeigniter.com/user_guide/general/urls.html
	 */

	public function __construct()
	{
		parent::__construct();
		$this->load->model('brisimpedes/model_checksum');
	}

	public function index()
	{
		$param['id']  = ($this->input->post('id')!='')  ? $this->input->post('id')  : ($this->uri->segment(3) ? $this->uri->segment(3) : 'true');

//		$data['id']=$param['id'];
//		$this->load->view("login",$data);
	}

	public function lanjuttahapcdatabase()
	{
		 $notif 	   = $this->session->flashdata('database');
		 $data['notif'] = $notif;
		 $data['page'] = 'instalasi/instalasi_a';
		 $data['menu'] = 'main_dashboard';
		 $this->load->view("layouts/fix_installasi", $data);
	}


	public function createdatabase()
	{

		//drop database
	    $notif = '';
		error_reporting(E_ALL ^ E_DEPRECATED);
		$link = mysql_connect('localhost', 'root', 'undiansimpedes');
		if (!$link) {
		    die('Could not connect: ' . mysql_error());
		    $notif = 'koneksi terputus : '. mysql_error();
		}

		$sql1 = 'DROP DATABASE IF EXISTS pengundianoffline';
		if (mysql_query($sql1, $link)) {
		 //   echo "Database my_db created successfully\n";
		    //echo "2";

		} else {
		   $notif =  'Error drop database: ' . mysql_error() . "\n";
		}

		$sql = 'CREATE DATABASE IF NOT EXISTS pengundianoffline';
		if (mysql_query($sql, $link)) {
			$this->session->set_flashdata('database', 'berhasil');
			$notif = 'Pembuatan database baru berhasil';
		 //   echo "Database my_db created successfully\n";
	//	    echo "1";

		} else {
			$this->session->set_flashdata('database', 'database gagal dibuat');
			$notif = 'database gagal dibuat';
		//   echo 'Error creating database: ' . mysql_error() . "\n";
		}

		$sql = 'CREATE DATABASE IF NOT EXISTS checksum_file';
		if (mysql_query($sql, $link)) {
			$this->session->set_flashdata('database2', 'berhasil');
			$notif2 = 'Pembuatan database baru berhasil';
	
		} else {
			$this->session->set_flashdata('database2', 'database gagal dibuat');
			$notif2 = 'database gagal dibuat';
		}
		//coneksi database cek sum
		$link2 = mysql_connect('localhost', 'root', 'undiansimpedes');
		if (!$link2) {
		    die('Could not connect: ' . mysql_error());
		    $notif = 'koneksi terputus : '. mysql_error();
		}


		$sqltable="CREATE TABLE IF NOT EXISTS checksum_file.checksum (
		  `indexCheck` int(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
		  `charAdd` varchar(20) DEFAULT NULL,
		  `dtmAdd` datetime DEFAULT NULL,
		  `checksumadd` varchar(255) DEFAULT NULL
		) ENGINE=InnoDB DEFAULT CHARSET=latin1;";
		if (mysql_query($sqltable, $link2)) {
			$this->session->set_flashdata('table', 'berhasil');
	
		} else {
			$this->session->set_flashdata('tables', 'database gagal dibuat');
		}





	 	$data['notif'] = $notif;
		$data['notif2'] = $notif2;

		// redirect('c_instalasi/lanjuttahapcdatabase?notif='.$notif);

		$data['page'] = 'instalasi/instalasi_a';
		$data['menu'] = 'main_dashboard';
		$this->load->view("layouts/fix_installasi", $data);

	}

	public function transferdata()
	{
		 $notif 	   	= $this->session->flashdata('database');
		 $data['notif'] = $notif;
		 $data['page'] 	= 'instalasi/instalasi_b';
		 $data['menu'] 	= 'main_dashboard';
		 $this->load->view("layouts/fix_installasi", $data);
	}

	public function backupdatabase()
	{ 
		$comandFolderKanca 	= 'sh folder.sh'; 
 	   	$var = exec($comandFolderKanca); 
 	   	//echo $var;

		//echo 'backupdaa';
       //ENTER THE RELEVANT INFO BELOW
        //DO NOT EDIT BELOW THIS LINE
        //Export the database and output the status to the page
       // $command='mysqldump --opt -h' .$mysqlHostName .' -u' .$mysqlUserName .' -p' .$mysqlPassword .' ' .$mysqlDatabaseName .' > ~/'.$mysqlExportPath;
        $command 			= 'sh play.sh '. $var;
        //$command 			='echo 02132 | sudo -S /opt/lampp/bin/mysqldump --login-path=local -e  db_kc_s206 > /opt/lampp/htdocs/BRIUNDIANSIMPEDES/download/dumpmsql.sql';
        //$coba 				= exec ($command);
        passthru( $command  );

      //  echo 1;
   
	}

	public function transferdatabase()
	{ 

        $command 			= 'sh transferdata.sh';
        passthru( $command  );
	$basepath = getcwd();
	$filename = $basepath."/assets/download/database.sql";
	$md5file  = md5_file($filename);
	//echo $md5file;
	$insert = array(
		'charAdd' =>$this->session->userdata('kode_user'),
		'checksumadd' => $md5file
	);

	echo $this->model_checksum->insert_checksum($insert);
	
	}


	public function intsalasitahap4()
	{
		 $data['page'] 	= 'instalasi/instalasi_c';
		 $data['menu'] 	= 'main_dashboard';
		 $this->load->view("layouts/fix_installasi", $data);
	}	

	public function upload()
	{
		//redirect("");
		//ini_set('max_execution_time', 300);
		$pemenang = array();
		$flag = 0;
		$data='';
		$idkanca = $this->session->userdata('kode_kanca');
		$target_dir = "assets/download/";
		$target_file = '';
 			$uploadOk = 0;

 				$target_file = $target_dir ."database.sql";
			    if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {
			        echo "The file ". basename( $_FILES["fileToUpload"]["name"]). " has been uploaded.";
			        $this->session->set_flashdata('upload', 'done');
			        redirect("instalasi/transferdata");
			    } else {
			        echo "import file gagal !";
			    }


		if(isset($_POST["submit"]) && $target_file != '' ) {

		    if ($_FILES["fileToUpload"]["size"] > 1000000000000) {
		    echo "maaf ukuran file yang anda masukan melibihi kapasitas ";
		    $uploadOk = 0;
			}


			// Check if $uploadOk is set to 0 by an error
			if ($uploadOk == 0) {
			    echo "import data gagal!.";
			// if everything is ok, try to upload file
			} else {
			
			}
		}
	}




}
