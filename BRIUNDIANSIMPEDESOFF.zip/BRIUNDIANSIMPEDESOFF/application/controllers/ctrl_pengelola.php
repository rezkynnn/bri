<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class ctrl_pengelola extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -  
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in 
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see http://codeigniter.com/user_guide/general/urls.html
	 */

	public function __construct()
	{
		parent::__construct();
		$this->load->model('brisimpedes/model_mstuker');
		$this->load->model('brisimpedes/model_mstuser');
		$this->load->model('brisimpedes/model_pengelola');
		$this->load->model('brisimpedes/model_mstperiodehadiah');
		$this->load->model('model_mstperiode');
	}

	public function index()
	{
		$data['kode_user']=$this->session->userdata('kode_user');
		$data['nama_user'] = $this->session->userdata('nama_user');
		$data['kode_kanca'] = $this->session->userdata('kode_kanca');
		$data['group_area'] = $this->session->userdata('group_area');
		$data['otoritas'] = $this->session->userdata('otoritas');
		$data['kodekanwil'] = $this->session->userdata('kanwil');
		$idkanca = $this->session->userdata('kode_kanca');
		

		 if (isset($_GET['id']) && $_GET['id']!=0)
		 {
		 	$data['data'] = $this->model_pengelola->data_pengelola_tampilkan_periode($idkanca,$_GET['id']);
		 }
		 else if (isset($_GET['id']) && $_GET['id']==0)
		 {
			$data['data'] = $this->model_pengelola->data_pengelola_tampilkan($idkanca);
		 }
		 else
		 {
			 $data['data'] = $this->model_pengelola->data_pengelola_tampilkan($idkanca);	
		 }
	 	$data["periode"] = $this->model_mstperiodehadiah->data_mstperiode();
		$data['page'] = 'data_pengelola/view_datapengelola';
		$data['menu'] = 'main_dashboard';
		//$data['data'] = $this->model_mstperiodehadiah->data_periodeHadiah();
		
	//	$data['id'] = "";
	//	$data['provinsi'] = $this->model_mstuker->data_provinsi();
		$data['kanwil'] = $this->model_mstuker->data_kanwil();
		$this->load->view("layouts/fix", $data);
	}

	public function Kab($id)
	{
	//	$kab= $this->model_mstuker->data_kab($id);
		$kab = "hay";
		return $kab;
	}

	public function tambahpengelola()
	{
		$data['kode_user']=$this->session->userdata('kode_user');
		$data['nama_user'] = $this->session->userdata('nama_user');
		$data['kode_kanca'] = $this->session->userdata('kode_kanca');
		$data['group_area'] = $this->session->userdata('group_area');
		$data['otoritas'] = $this->session->userdata('otoritas');
		$data['kodekanwil'] = $this->session->userdata('kanwil');
		$idkanca = $this->session->userdata('kode_kanca');
		

		$data['gropuarea'] =$this->model_mstuser->data_grouparea();
		$data['kanwil'] = $this->model_mstuker->data_kanwil();
		$data['kanca'] = $this->model_mstuser->data_kanca();
		$data["periode"] = $this->model_mstperiodehadiah->data_mstperiode();
		$data["Jenis_Hadiah"] = $this->model_mstperiodehadiah->data_JenisHadiah();


		 if (isset($_GET['id']) && $_GET['id']!=0)
		 {

		 	//$data['provin'] = $_GET['id'];
		 	$ok=$this->model_pengelola->data_pengelola_tampilkan_periode($idkanca,$_GET['id']); 
		 	$data['dataall'] = $ok;
		 }

		 if (isset($_GET['priode']))
		 {

		 	//$data['provin'] = $_GET['id'];
		 	$ok=$this->model_pengelola->data_pengelola_tampilkan_periode($idkanca,$_GET['priode']); 
		 	$data['dataall'] = $ok;
		 }


		 
		/*

		$data['gropuarea'] =$this->model_mstuser->data_grouparea();
		$data['kanca'] = $this->model_mstuser->data_kanca();



	
		$data['data'] = $this->model_mstuker->data_unit();
		$data['id'] = "";
		$data['provinsi'] = $this->model_mstuker->data_provinsi();
		
		*/
		$data['page'] = 'data_pengelola/view_tambahpengelola';
		$data['menu'] = 'main_dashboard';
		$this->load->view("layouts/fix", $data);
	}

	public function simpanbaru()
	{
		$idkanca = $this->session->userdata('kode_kanca');

// 	 	dtmUserEdit
 //	 	chrUserAdd 	dtmUserAdd 	chrUserEdit 	dtmUserEdit  
		$insert = array(
				 'chrKdPeriode' => $this->input->post('periode'),
				'chrPngJwb1' => $this->input->post('penanggungjawab'),
				'chrJbtPj1' => $this->input->post('jabatan1'),
				'chrPngJwb2' => $this->input->post('penanggungjawab2'),
				'chrJbtPj2' => $this->input->post('jabatan2'),
				'chrNotaris' => $this->input->post('Notaris'),
				'chrJbtN' => $this->input->post('notarisjabatan'),
				'chrSaksi1' => $this->input->post('saksi1'),
				'chrJbtS1' => $this->input->post('jabatansaksi1'),
				'chrSaksi2' => $this->input->post('saksi2'),
				'chrJbtS2' => $this->input->post('jabatansaksi2'),
				
				'chrSaksi3' => $this->input->post('saksi3'),
				'chrJbtS3' => $this->input->post('jabatansaksi3'),

				'chrUserAdd' => $this->session->userdata('kode_user')
	//			'chrUserEdit' => $this->input->post('email'),


			);
		$periode = $this->input->post('periode');


		$a=$this->model_pengelola->savedatapengelola($insert,$periode,$idkanca);
		redirect('ctrl_pengelola?sts='.$a);


	}



	public function add_member()
	{
		$insert = array(
				'nama_member' => $this->input->post('nama_member'),
				'bagian' => $this->input->post('bagian'),
				'email' => $this->input->post('email'),
				'no_telp' => $this->input->post('no_telp'),
				'group' => $this->input->post('group')
			);
		$this->m_pingpong->add_member($insert);

		redirect('c_pingpong/list_user');
	}

	public function delete_pengelola()
	{
		$idkanca = $this->session->userdata('kode_kanca');
		$a=$this->model_pengelola->hapus_pengelola($idkanca, $_GET['id']);
		redirect('ctrl_pengelola?sts='.$a);
	}



	

	
}