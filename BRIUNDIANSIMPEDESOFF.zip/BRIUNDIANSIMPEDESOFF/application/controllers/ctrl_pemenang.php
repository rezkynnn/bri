<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class ctrl_pemenang extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -  
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in 
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see http://codeigniter.com/user_guide/general/urls.html
	 */

	public function __construct()
	{
		parent::__construct();
		$this->load->model('brisimpedes/model_mstuker');
		$this->load->model('brisimpedes/model_mstuser');
		$this->load->model('brisimpedes/model_mstperiodehadiah');
		$this->load->model('model_mstperiode');
	}

	public function index()
	{

		$data['kode_user']=$this->session->userdata('kode_user');
		$data['nama_user'] = $this->session->userdata('nama_user');
		$data['kode_kanca'] = $this->session->userdata('kode_kanca');
		$data['group_area'] = $this->session->userdata('group_area');
		$data['otoritas'] = $this->session->userdata('otoritas');
		$data['kodekanwil'] = $this->session->userdata('kanwil');
		$idkanca = 'pengundianoffline';


		 if (isset($_GET['id']))
		 {
		 	$kodeperiode = $_GET['id'];
 			$data['hadiah'] = $this->model_mstperiodehadiah->pemenanghaidahuntukdropdown($kodeperiode,$idkanca);

 			if (isset($_GET['idp'])&&$_GET['idp']!='0')
		 	{
		 	$data['pemenang'] = $this->model_mstperiodehadiah->pemenanghadiah($kodeperiode,$_GET['idp'],$idkanca);		
			}
			else
			{
		 	$data['pemenang'] = $this->model_mstperiodehadiah->pemenang($kodeperiode,$idkanca);
		 	}

		
		 }

	
	 	$data["periode"] = $this->model_mstperiodehadiah->data_mstperiode();
		$idkanca = '206';
		
		$data['page'] = 'data_pemenang/view_daftarpemenang';
		$data['menu'] = 'main_dashboard';
	

		///$data['kanwil'] = $this->model_mstuker->data_kanwil();
		$this->load->view("layouts/fix", $data);
	}

	public function Kab($id)
	{
	//	$kab= $this->model_mstuker->data_kab($id);
		$kab = "hay";
		return $kab;
	}

	public function tambahhadiahKanca()
	{
		$data['gropuarea'] =$this->model_mstuser->data_grouparea();
		$data['kanwil'] = $this->model_mstuker->data_kanwil();
		$data['kanca'] = $this->model_mstuser->data_kanca();
		$data["periode"] = $this->model_mstperiodehadiah->data_mstperiode();
		$data["Jenis_Hadiah"] = $this->model_mstperiodehadiah->data_JenisHadiah();

	
	
	/*
		 if (isset($_GET['prov']))
		 {

		 	$data['provin'] = $_GET['prov'];
		 	$ok=$this->model_mstuker->data_kab($_GET['prov']); 
		 	$data['dataprovin'] = $ok;
		 }

		$data['gropuarea'] =$this->model_mstuser->data_grouparea();
		$data['kanca'] = $this->model_mstuser->data_kanca();



	
		$data['data'] = $this->model_mstuker->data_unit();
		$data['id'] = "";
		$data['provinsi'] = $this->model_mstuker->data_provinsi();
		
		*/
		$data['page'] = 'data_hadiah/view_tambahhadiah';
		$data['menu'] = 'main_dashboard';
		$this->load->view("layouts/fix", $data);
	}

	public function edithadiahKanca()
	{

		$kodekanca="206";
		if (isset($_GET['hadiah']))
		 {

		 	$ok=$this->model_mstperiodehadiah->get_periodeHadiah($_GET['hadiah']);
		 	$data['datahadiah'] = $ok;
		 }
		 
		$data['gropuarea'] =$this->model_mstuser->data_grouparea();
		$data['kanca'] = $this->model_mstuser->data_kanca();
		$data['kanwil'] = $this->model_mstuker->data_kanwil();
		$data['kanca'] = $this->model_mstuser->data_kanca();
		$data["periode"] = $this->model_mstperiodehadiah->data_mstperiode();
		$data["Jenis_Hadiah"] = $this->model_mstperiodehadiah->data_JenisHadiah();



		$data['page'] = 'data_hadiah/view_edithadiah';
		$data['menu'] = 'main_dashboard';
		//$data['data'] = $this->model_mstuker->data_unit();
		//$data['data'] = $this->model_mstuker->data_unit();
		//$data['getdataunit'] = $this->model_mstuker->getdata_unit($_GET['idkode']);
		//$data['provinsi'] = $this->model_mstuker->data_provinsi();
	//	$data['id'] =$_GET['idkode'];
		$this->load->view("layouts/fix", $data);
	}

	public function list_user()
	{
		$data['page'] = 'v_list_user';
		$data['menu'] = 'main_dashboard';

		$data['list_a'] = $this->m_pingpong->list_a();
		$data['list_b'] = $this->m_pingpong->list_b();
		$data['list_c'] = $this->m_pingpong->list_c();

		$this->load->view("layouts/fix", $data);
	}

	public function add_member()
	{
		$insert = array(
				'nama_member' => $this->input->post('nama_member'),
				'bagian' => $this->input->post('bagian'),
				'email' => $this->input->post('email'),
				'no_telp' => $this->input->post('no_telp'),
				'group' => $this->input->post('group')
			);
		$this->m_pingpong->add_member($insert);

		redirect('c_pingpong/list_user');
	}

	public function delete_member($id_member)
	{
		$this->m_pingpong->delete_member($id_member);

		redirect('c_pingpong/list_user/');
	}



	

	
}
