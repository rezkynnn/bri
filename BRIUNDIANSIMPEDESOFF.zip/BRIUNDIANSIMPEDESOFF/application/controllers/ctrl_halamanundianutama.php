<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class ctrl_halamanundianutama extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -  
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in 
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see http://codeigniter.com/user_guide/general/urls.html
	 */

	public function __construct()
	{
		parent::__construct();
			parent::__construct();
			$this->load->model('data_kupon');
  			$this->load->model('model_tmpdaftarpemenang');
  			$this->load->model('model_daftarpemenang');
			$this->load->model('model_hadiahKanca');
			$this->load->model('model_msthadiahperiode');
			$this->load->model ('model_mstperiode');

	}

	public function index()
	{

		$data["sisahiburan"] = $this->model_hadiahKanca->jumlah_hadiahhiburan();
		$data["sisabiasa"] = $this->model_hadiahKanca->jumlah_hadiahumum();
		$data["sisautama"] = $this->model_hadiahKanca->jumlah_hadiahutama();
		$data["hadiahPeriode"] = $this->model_msthadiahperiode->data_hadiah_tampilkan();
		$data["periode"] = $this->model_mstperiode->data_mstperiode();
	



		$data['page'] = 'view_HalUtamaUndian';
		$data['menu'] = 'main_dashboard';
		$this->load->view("view_HalUtamaUndian", $data);
	}

	public function kosong()
	{



		$data["sisahiburan"] = $this->model_hadiahKanca->jumlah_hadiahhiburan();
		$data["sisabiasa"] = $this->model_hadiahKanca->jumlah_hadiahumum();
		$data["sisautama"] = $this->model_hadiahKanca->jumlah_hadiahutama();
		$data["hadiahPeriode"] = $this->model_msthadiahperiode->data_hadiah_tampilkan();
		$data["periode"] = $this->model_mstperiode->data_mstperiode();
	



		$data['page'] = 'view_HalUtamaUndian';
		$data['menu'] = 'main_dashboard';
		$this->load->view("layouts/fix", $data);
	}

	public function list_user()
	{
		$data['page'] = 'v_list_user';
		$data['menu'] = 'main_dashboard';

		$data['list_a'] = $this->m_pingpong->list_a();
		$data['list_b'] = $this->m_pingpong->list_b();
		$data['list_c'] = $this->m_pingpong->list_c();

		$this->load->view("layouts/fix", $data);
	}

	public function add_member()
	{
		$insert = array(
				'nama_member' => $this->input->post('nama_member'),
				'bagian' => $this->input->post('bagian'),
				'email' => $this->input->post('email'),
				'no_telp' => $this->input->post('no_telp'),
				'group' => $this->input->post('group')
			);
		$this->m_pingpong->add_member($insert);

		redirect('c_pingpong/list_user');
	}

	public function delete_member($id_member)
	{
		$this->m_pingpong->delete_member($id_member);

		redirect('c_pingpong/list_user/');
	}

	public function add_score()
	{
		$temp1 = 0;
		$temp2 = 0;
		$nama1 = '';
		$nama2 = '';
		$id_score = '';
		
		
		$result = $this->input->post('pemain1');
		$result_explode = explode('|', $result);
		
            $temp1 = $result_explode[0];
            $nama1 = $result_explode[1];
		
		$result = $this->input->post('pemain2');
		$result_explode = explode('|', $result);
		
			$temp2 = $result_explode[0];
            $nama2 = $result_explode[1];
			
		
		$idg = $this->input->post('group');
		

		if($temp1 < $temp2)
		{
			$id_score = $idg.''.$temp1.''.$temp2;
		}

		if ($temp1 > $temp2)
		{
			$id_score = $idg.''.$temp2.''.$temp1;
		}

		$insert = array(
					'id_score' => $id_score,
					'pemain1' => $temp1,
					'pemain2' => $temp2,
					'score1' => $this->input->post('score1'),
					'score2' => $this->input->post('score2'),
					'nama1' => $nama1,
					'nama2' => $nama2,
					'group' => $idg 
				);
		$this->m_pingpong->add_score($insert);

		redirect('c_pingpong/score');
	
		
	}
	
	public function score()
	{
		$data['page'] = 'v_add_score';
		$data['menu'] = 'main_dashboard';
		
		$data['score_a'] = $this->m_pingpong->score_a();		
		$data['score_b'] = $this->m_pingpong->score_b();
		$data['score_c'] = $this->m_pingpong->score_c();
				
		$data['list_a'] = $this->m_pingpong->list_a();
		$data['list_b'] = $this->m_pingpong->list_b();
		$data['list_c'] = $this->m_pingpong->list_c();
		
		$this->load->view("layouts/fix", $data);
	}
	
	public function klasemen()
	{
		$data['page'] = 'v_klasemen';
		$data['menu'] = 'main_dashboard';
		
		$data['kls_a'] = $this->m_pingpong->klasemen_a();		
		$data['kls_b'] = $this->m_pingpong->klasemen_b();
		$data['kls_c'] = $this->m_pingpong->klasemen_c();
		
		$this->load->view("layouts/fix", $data);
	}

	public function nextundian()
	{
		$data['hadiah'] = $this->input->post('hadiah');
		$data['page'] = 'view_undianKupon';
		$data['menu'] = 'main_dashboard';
		$data['ok'] = 'okoooooo';
		$this->load->view("layouts/fix", $data);
	}

}
