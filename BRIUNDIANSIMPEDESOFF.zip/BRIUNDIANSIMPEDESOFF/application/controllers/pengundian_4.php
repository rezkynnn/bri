<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class pengundian extends CI_Controller {
	public $totalArrayPemanang='1';

	/**
	*tanggal diperbarui 08 SEPTEMBER 2015
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -  
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in 
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see http://codeigniter.com/user_guide/general/urls.html
	 */

	public function __construct()
	{
		parent::__construct();
			parent::__construct();
			$this->load->model('data_kupon');
  			$this->load->model('model_tmpdaftarpemenang');
  			$this->load->model('model_daftarpemenang');
			//$this->load->model('model_hadiahKanca');
			$this->load->model('model_msthadiahperiode');
			$this->load->model ('brisimpedes/model_mstperiode');
			$this->load->model('brisimpedes/model_mstperiodehadiah');
			$this->load->model('brisimpedes/model_undian');
			$this->load->model('brisimpedes/model_kupon');
			$this->load->model('brisimpedes/model_mstuker');


	}

	public function index()
	{
		redirect("pengundian/setperiode_singledraw");


		$data['kode_user']=$this->session->userdata('kode_user');

		$data['nama_user'] = $this->session->userdata('nama_user');
		$data['kode_kanca'] = $this->session->userdata('kode_kanca');
		$data['group_area'] = $this->session->userdata('group_area');
		$data['otoritas'] = $this->session->userdata('otoritas');
		$data['kodekanwil'] = $this->session->userdata('kanwil');
		$idkanca = $this->session->userdata('kode_kanca');
		$otoritas = $this->session->userdata('otoritas');

		//$data["sisahiburan"] = $this->model_hadiahKanca->jumlah_hadiahhiburan();
		//$data["sisabiasa"] = $this->model_hadiahKanca->jumlah_hadiahumum();
		//$data["sisautama"] = $this->model_hadiahKanca->jumlah_hadiahutama();
		$data["hadiahPeriode"] = $this->model_msthadiahperiode->data_hadiah_tampilkan();
		$data["periode"] = $this->model_mstperiode->data_mstperiode();

		
	

		 $data['page'] = 'pengundian/v_periodeundian';
		 $data['menu'] = 'main_dashboard';
		 $this->load->view("layouts/fixundian", $data);
	}

	public function multidrawperiod()
	{

		$data['kode_user']=$this->session->userdata('kode_user');

		$data['nama_user'] = $this->session->userdata('nama_user');
		$data['kode_kanca'] = $this->session->userdata('kode_kanca');
		$data['group_area'] = $this->session->userdata('group_area');
		$data['otoritas'] = $this->session->userdata('otoritas');
		$data['kodekanwil'] = $this->session->userdata('kanwil');
		$idkanca = $this->session->userdata('kode_kanca');
		$otoritas = $this->session->userdata('otoritas');

		//$data["sisahiburan"] = $this->model_hadiahKanca->jumlah_hadiahhiburan();
		//$data["sisabiasa"] = $this->model_hadiahKanca->jumlah_hadiahumum();
		//$data["sisautama"] = $this->model_hadiahKanca->jumlah_hadiahutama();
		$data["hadiahPeriode"] = $this->model_msthadiahperiode->data_hadiah_tampilkan();
		$data["periode"] = $this->model_mstperiode->data_mstperiode();

		 $data['page'] = 'pengundian/v_mass_periodeundian';
		 $data['menu'] = 'main_dashboard';
		 $this->load->view("layouts/fixundian", $data);
	}

	public function multidraw_lama()
	{
		$countdown 				= $this->model_mstperiodehadiah->selisihwaktuundian($this->session->userdata('kode_kanca'),$_GET['periode']);
	
		if($countdown>=604800)
		{
			redirect("pengundian/hiburan?st=x&id=".$_GET['periode']);
		}

		$data['kode_user']=$this->session->userdata('kode_user');
		$data['nama_user'] = $this->session->userdata('nama_user');
		$data['kode_kanca'] = $this->session->userdata('kode_kanca');
		$data['group_area'] = $this->session->userdata('group_area');
		$data['otoritas'] = $this->session->userdata('otoritas');
		$data['kodekanwil'] = $this->session->userdata('kanwil');
		$otoritas = $this->session->userdata('otoritas');
		$idkanca = $this->session->userdata('kode_kanca');

		//variable pengunundian
	//	$data["datanokupon"] = $this->model_mstperiodehadiah->get_nomorundian($idkanca);
		//$nomorundian = $this->model_mstperiodehadiah->get_nomorundian($idkanca);
		$arraynomorundian = array();

		$no=0;



	
		//$data["noarray"] = json_encode($arraynomorundian);

		if(isset($_GET['periode']))
		{
			$flag = $this->cekvalidasi_undian($_GET['periode']);
			if($flag!=1)
			{
				redirect("pengundian/multidrawperiod?st=1&id=".$_GET['periode']);
			}

			$tanggal 	= $this->model_mstperiodehadiah->selisihwaktuundian($this->session->userdata('kode_kanca'),$_GET['periode']);
			if($tanggal < 0 )
			{
					redirect("pengundian/multidrawperiod?st=0&id=".$_GET['periode']);
			}

		$data['maxundian'] = $this->model_undian->data_jumlahpengundianKuponCepat($idkanca, $_GET['periode']);
		$data['rangeperiode']=$_GET['x'];
		$data['idperiode']=$_GET['periode'];
		$data['datajenishadiah'] = $this->model_undian->get_undian_hadiahumum($idkanca,$_GET['periode']);
		//$data["sisahiburan"] = $this->model_hadiahKanca->jumlah_hadiahhiburan();
		//$data["sisabiasa"] = $this->model_hadiahKanca->jumlah_hadiahumum();
		//$data["sisautama"] = $this->model_hadiahKanca->jumlah_hadiahutama();
		$data["hadiahPeriode"] = $this->model_msthadiahperiode->data_hadiah_tampilkan();
		$data["periode"] = $this->model_mstperiode->data_mstperiode();
		$data['page'] = 'pengundian/v_mass_pengacakanundian';
		$data['menu'] = 'main_dashboard';
		$this->load->view("layouts/fixundian", $data);
		}
		else{
		redirect("pengundian//multidrawperiod");}
	}

	public function hiburan()
	{


		$data['kode_user']=$this->session->userdata('kode_user');
		$data['nama_user'] = $this->session->userdata('nama_user');
		$data['kode_kanca'] = $this->session->userdata('kode_kanca');
		$data['group_area'] = $this->session->userdata('group_area');
		$data['otoritas'] = $this->session->userdata('otoritas');
		$data['kodekanwil'] = $this->session->userdata('kanwil');
		$otoritas = $this->session->userdata('otoritas');

		//$data["sisahiburan"] = $this->model_hadiahKanca->jumlah_hadiahhiburan();
		//$data["sisabiasa"] = $this->model_hadiahKanca->jumlah_hadiahumum();
		//$data["sisautama"] = $this->model_hadiahKanca->jumlah_hadiahutama();
		$data["hadiahPeriode"] = $this->model_msthadiahperiode->data_hadiah_tampilkan();
		$data["periode"] = $this->model_mstperiode->data_mstperiode();
	

		 $data['page'] = 'pengundian/v_pilihperiodehiburan';
		 $data['menu'] = 'main_dashboard';
		 $this->load->view("layouts/fixundian", $data);
	}


	public function pengacakanundian()
	{
		$countdown 				= $this->model_mstperiodehadiah->selisihwaktuundian($this->session->userdata('kode_kanca'),$_GET['periode']);
		if($countdown>=604800)
		{
			redirect("pengundian?st=x&id=".$_GET['periode']);
		}

		$data['kode_user']=$this->session->userdata('kode_user');
		$data['nama_user'] = $this->session->userdata('nama_user');
		$data['kode_kanca'] = $this->session->userdata('kode_kanca');
		$data['group_area'] = $this->session->userdata('group_area');
		$data['otoritas'] = $this->session->userdata('otoritas');
		$data['kodekanwil'] = $this->session->userdata('kanwil');
		$otoritas = $this->session->userdata('otoritas');
		$idkanca = $this->session->userdata('kode_kanca');

		//variable pengunundian
	//	$data["datanokupon"] = $this->model_mstperiodehadiah->get_nomorundian($idkanca);
		//$nomorundian = $this->model_mstperiodehadiah->get_nomorundian($idkanca);
		$arraynomorundian = array();

		$no=0;


		$data['maxundian'] = 0;

		if(isset($_GET['periode']))
		{	
			$flag = $this->cekvalidasi_undian($_GET['periode']);
			if($flag!=1)
			{
				redirect("pengundian?st=1&id=".$_GET['periode']);
			}


			$tanggal 	= $this->model_mstperiodehadiah->selisihwaktuundian($this->session->userdata('kode_kanca'),$_GET['periode']);
			if($tanggal < 0 )
			{
					redirect("pengundian?st=0&id=".$_GET['periode']);
			}


		$data['maxundian'] = $this->model_undian->data_jumlahpengundianKuponCepat($idkanca,$_GET['periode']);
		$data['rangeperiode']=$_GET['x'];
		$data['idperiode']=$_GET['periode'];
		$data['datajenishadiah'] = $this->model_undian->get_undian_hadiahumum($idkanca,$_GET['periode']);
		//$data["sisahiburan"] = $this->model_hadiahKanca->jumlah_hadiahhiburan();
		//$data["sisabiasa"] = $this->model_hadiahKanca->jumlah_hadiahumum();
		//$data["sisautama"] = $this->model_hadiahKanca->jumlah_hadiahutama();
		$data["hadiahPeriode"] = $this->model_msthadiahperiode->data_hadiah_tampilkan();
		$data["periode"] = $this->model_mstperiode->data_mstperiode();
		$data['page'] = 'pengundian/v_pengacakanundian';
		$data['menu'] = 'main_dashboard';
		$this->load->view("layouts/fixundian", $data);
		}
		else{
		redirect("pengundian");}

	}


	public function pengacakanundianHiburan()
	{
		$countdown 				= $this->model_mstperiodehadiah->selisihwaktuundian($this->session->userdata('kode_kanca'),$_GET['periode']);
	
		if($countdown>=604800)
		{
			redirect("pengundian/hiburan?st=x&id=".$_GET['periode']);
		}

		$data['kode_user']=$this->session->userdata('kode_user');
		$data['nama_user'] = $this->session->userdata('nama_user');
		$data['kode_kanca'] = $this->session->userdata('kode_kanca');
		$data['group_area'] = $this->session->userdata('group_area');
		$data['otoritas'] = $this->session->userdata('otoritas');
		$data['kodekanwil'] = $this->session->userdata('kanwil');
		$otoritas = $this->session->userdata('otoritas');
		$idkanca = $this->session->userdata('kode_kanca');

		//variable pengunundian
	//	$data["datanokupon"] = $this->model_mstperiodehadiah->get_nomorundian($idkanca);
		//$nomorundian = $this->model_mstperiodehadiah->get_nomorundian($idkanca);
		$arraynomorundian = array();

		$no=0;



	
		//$data["noarray"] = json_encode($arraynomorundian);

		if(isset($_GET['periode']))
		{
			$flag = $this->cekvalidasi_undian($_GET['periode']);
			if($flag!=1)
			{
				redirect("pengundian/hiburan?st=1&id=".$_GET['periode']);
			}

			$tanggal 	= $this->model_mstperiodehadiah->selisihwaktuundian($this->session->userdata('kode_kanca'),$_GET['periode']);
			if($tanggal < 0 )
			{
					redirect("pengundian/hiburan?st=0&id=".$_GET['periode']);
			}


		$data['maxundian'] = $this->model_undian->data_jumlahpengundianKuponCepat($idkanca, $_GET['periode']);
		$data['rangeperiode']=$_GET['x'];
		$data['idperiode']=$_GET['periode'];
		$data['datajenishadiah'] = $this->model_undian->get_undian_hadiahHiburan($idkanca,$_GET['periode']);
		//$data["sisahiburan"] = $this->model_hadiahKanca->jumlah_hadiahhiburan();
		//$data["sisabiasa"] = $this->model_hadiahKanca->jumlah_hadiahumum();
		//$data["sisautama"] = $this->model_hadiahKanca->jumlah_hadiahutama();
		$data["hadiahPeriode"] = $this->model_msthadiahperiode->data_hadiah_tampilkan();
		$data["periode"] = $this->model_mstperiode->data_mstperiode();
		$data['page'] = 'pengundian/v_pengacakanundianhiburan';
		$data['menu'] = 'main_dashboard';
		$this->load->view("layouts/fixundian", $data);
		}
		else{
		redirect("pengundian/hiburan");}
	}



	public function kosong()
	{



		$data["sisahiburan"] = $this->model_hadiahKanca->jumlah_hadiahhiburan();
		$data["sisabiasa"] = $this->model_hadiahKanca->jumlah_hadiahumum();
		$data["sisautama"] = $this->model_hadiahKanca->jumlah_hadiahutama();
		$data["hadiahPeriode"] = $this->model_msthadiahperiode->data_hadiah_tampilkan();
		$data["periode"] = $this->model_mstperiode->data_mstperiode();
	



		$data['page'] = 'view_HalUtamaUndian';
		$data['menu'] = 'main_dashboard';
		$this->load->view("layouts/fix", $data);
	}

	public function kirimacakundian()
	{
		ini_set('max_execution_time', 0);
		$idkanca = $this->session->userdata('kode_kanca');
		$periodeUndian=$_GET['id'];
		$tabelBaru = $this->model_undian->CreateTableDistribusi($idkanca,$periodeUndian);

		$hapustabel = $this->model_undian->truncate_dstNoUndian($idkanca,$periodeUndian);
		//$hapustabel = $this->model_undian->truncate_dbo_tampnoundian($idkanca);
		
		//$hapustabel=1;
		//echo"hapus tabel ".$hapustabel; 

		if($hapustabel==1)
		{
		$data['kode_user']=$this->session->userdata('kode_user');
		$data['nama_user'] = $this->session->userdata('nama_user');
		$data['kode_kanca'] = $this->session->userdata('kode_kanca');
		$data['group_area'] = $this->session->userdata('group_area');
		$data['otoritas'] = $this->session->userdata('otoritas');
		$data['kodekanwil'] = $this->session->userdata('kanwil');
		

		$tampung = $this->model_undian->get_transfernomorundianPeriode($idkanca,$periodeUndian);
		$no =0;
		foreach ($tampung as $row) {
			//echo "</br>";
			//echo $row->KuponAwal;
			//echo "-----";
			//echo $row->KuponAkhir;
			$a=$row->KuponAwal;
			$kupon ="";
		//		echo "</br>";
			for($a;$a<=$row->KuponAkhir;$a++)
			{
				//echo "<input name=jumlah value=".$no.">";
				$no++;
				$kupon = $a;
				$jumlah=strlen($a);
				for($x=$jumlah; $x<8;$x++)
				{

					$kupon="0".$kupon;
				}
			//	kodeUker 	kodeBulan 	NoRek 	KuponAwal 	KuponAkhir 	chrKdPeriode

				//echo $row->chrKdPeriode." | ".$row->kodeUker." | ".$row->kodeBulan."| " .$row->NoRek."| data kupon ke ".$kupon;
				//echo "|->".$row->kodeUker.$row->kodeBulan.$kupon;
				
				$insert = array(
				'NoUndianSemuaUnit' => $row->kodeUker.$row->kodeBulan.$kupon,
				'noRek' => $row->NoRek,
				'chrKdUnit'=>$row->kodeUker
				);
				//echo $no;
				
			//	$this->model_undian->insert_noAllundian($idkanca,$insert);

				$this->model_undian->insert_noAllundianTabelPeriode($idkanca,$insert,$periodeUndian);
				$this->model_undian->closedonconection($idkanca);
			//	echo "</br>";
			}
			//	echo "</br>";

		}



		}
		

	}

	public function getNomorUndianDanRekening()
	{
		$idkanca = $this->session->userdata('kode_kanca');
		$periode = '';

		if($_GET['id'])
		{
			$periode = $_GET['id'];
		}
 

		if(isset($_GET['noAcak']))
		{
			$nomorundiandtl= $this->model_kupon->data_cariKupondtl($idkanca, $_GET['noAcak'],$periode);
			echo $nomorundiandtl;
		}
	

	}



	public function nextundian()
	{
		$data['hadiah'] = $this->input->post('hadiah');
		$data['page'] = 'view_undianKupon';
		$data['menu'] = 'main_dashboard';
		$data['ok'] = 'okoooooo';
		$this->load->view("layouts/fix", $data);
	}

	function ajax_call() {
		$ok=$this->model_mstperiodehadiah->tmpbanyakperiode('01');
		$idkanca = $this->session->userdata('kode_kanca');
		if (isset($_GET['noundian']) && isset($_GET['id']))
		{
			$norektamp="";
			$nama= $this->model_undian->get_namaukerundian($idkanca,substr($_GET['noundian'],0,4)."-------");
    		$uker= $this->model_undian->get_namaukerundian($idkanca,$idkanca);


    		$norek = $this->model_undian->get_nomorrekening($idkanca,$_GET['id'],$_GET['noundian']);
    		$norektamp=$norek;
    		if(strlen($norek) == 14 ){

    			$norektamp="0".$norek;
    		}
    		if(strlen($norek) == 13 ){

    			$norektamp="00".$norek;
    		}

    		if(strlen($norek) == 12 ){

    			$norektamp="000".$norek;
    		}

   			$norektamp = substr($norektamp,0,4)."-".substr($norektamp,4,2)."-".substr($norektamp,6,6)."-".substr($norektamp,12,2)."-".substr($norektamp,14,1);


			echo "<center>
		    <div style='font-size:20px; font-weight:bold; background: #ffe4ba; color: #00509A;''>DETAIL PEMENANG UNDIAN </div>
		    </br>
		    <table width='100%'' style='font-size:26px; font-weight:bold' border='0'>
		      <tr>
  		       <td width='20%'' align='center'></td>
          		<td width='25%' align='center' >
		        <div align='left' class='style4'>
    			Unit Kerja &nbsp;
			    </div>
				</td>
		    
     			<td width='65%' align='left' colspan='2'>
		            ".$nama."
		            <input type='hidden' name='unitkerjacab' value='".$nama."' >
		        </td>
		      </tr>
		      <tr>
		      ".
		      /*
		      "
   		       <td align='center'></td>
		        <td>
		        Kantor Cabang
		        </td>
		    
		        <td align='left' colspan='2'>
		        ".$uker."
	            <input type='hidden' name='kantorcabang' value='".$uker."' >
		        </td>
		      </tr>
		       ".*/
		       "<tr>
   		       <td width='20%' align='center'></td>
		        <td>
		        No. Rekening
		        </td>
		    
     			<td align='left' colspan='2'>
       	            <input type='hidden' name='norekening' value='".$norek."' >
		            ".$norektamp."
		        </td>
		      <tr>

		    </table>
		    </center>";
    	
		
	


		}



	}

	function ajax_callhadiah() {
		
		$a= $this->session->userdata('kode_kanca');
		//$ok=$this->model_mstperiodehadiah->tmpbanyakperiode('01');

		if(isset($_GET['hadiah']) && $_GET['hadiah']!=null)
		{

			$ok=$this->model_mstperiodehadiah->getnamahadiah($a,$_GET['hadiah'],$_GET['periode']);

            if (isset($ok) && $ok!=null) 
              {
                foreach ($ok as $row) 
                {
              echo $row->varJenisHadiah.' '.$row->varMerkHadiah.' '.$row->varTypeHadiah.' ('.$row->intJmlhadiah.')';                    
                }

             }
             else{
             		$pbo_slp = array();
             	}
             //	echo form_dropdown('periode',$pbo_slp);

		}


	}

	public function simpanpemenang() {

		$idkanca = $this->session->userdata('kode_kanca');
		$hadiah='';
		$ok=$this->model_mstperiodehadiah->getnamahadiah($idkanca,$this->input->post("jenishadiah"),$this->input->post("idundian"));
        if (isset($ok) && $ok!=null) 
           {
           foreach ($ok as $row) 
           {
             $hadiah= $row->varJenisHadiah.' '.$row->varMerkHadiah.' '.$row->varTypeHadiah;                    
           }

        }

		$namaunit = $this->input->post("unitkerjacab");
		$insert = array(
				'kodeUker' => $this->input->post('kode_unitkerja'),
				'namaUker' => $namaunit,
				'namahadiah' => $hadiah,
				'chrNoUndian' => $this->input->post('nomor_undian'),
				'chrNoRek' => $this->input->post('norekening'),
				'vcrNmNsbh' => $this->model_undian->get_namarekening($idkanca,$this->input->post("norekening")),
				'chrJnsHadiah' => $this->input->post("jenishadiah"),
				'chrKdPeriode' => $this->input->post('idundian'),
				'chrUserAdd' => $this->session->userdata('kode_user')
				
			);


		echo $this->input->post("unitkerjacab");
		echo "<br/>";
		echo $this->input->post("kantorcabang");
		echo "<br/>";
		echo $this->input->post("norekening");
		echo "<br/>";
		echo $this->input->post("nomor_undian");
		echo "<br/>";
		echo $this->input->post("jenishadiah");
		echo "<br/>";
		echo $this->input->post("idundian");
		echo "<br/>";
		echo $this->model_undian->get_namarekening($idkanca,$this->input->post("norekening"));
		echo "<br/>";
		echo $this->input->post("namahadiahlengkap");
		echo "<br/>";
		echo  $hadiah;
		echo "<br/>";
		$this->model_undian->simpan_noacakUndian($idkanca,$this->input->post("norekening"));
		$url = $this->input->post('urlpost');
		
		
		
		print_r($insert);

		$sukses =  $this->model_undian->simpan_pemenang($idkanca,$insert);
		//$this->model_undian->simpan_tempUndian($idkanca,$idkanca,$this->input->post("norekening"));
		$this->model_undian->simpan_tempUndian($idkanca,$this->input->post('idundian'),$this->input->post("norekening"));
		$sukses = $sukses +1;
		$this->session->set_flashdata('suksesa', $sukses);
		redirect($url);
	


	}

	public function coba_savebanyak()
	{
		$idkanca = $this->session->userdata('kode_kanca');
		echo $this->model_undian->undian_banyak($idkanca);	
		echo "hay"	;
	}

	public function numdownload()
	{
			$idkanca = $this->session->userdata('kode_kanca');
			$idperiode = $_GET['id'];
			$jumlah = $this->model_undian->get_nilaimaxKuponMasuk($idkanca,$idperiode);
			echo $jumlah;
	}

	//pengundian hadiah hiburan
	function ajax_callHiburan() {
	//	$ok=$this->model_mstperiodehadiah->tmpbanyakperiode('01');
		$idkanca = $this->session->userdata('kode_kanca');
		$truncateTempPemenang = $this->model_undian->truncateTempPemenang($idkanca);
		//$truncateTempPemenang  =1;
		if($truncateTempPemenang==1 && isset($_GET['charhadiah']) && isset($_GET['periode']))
		{
			echo "<div style='font-size:20px; font-weight:bold; background: #ffe4ba; color: #00509A;''>DETAIL PEMENANG UNDIAN </div>";
			echo "<table class='table table-striped table-bordered table-condensed' style ='width:70%;'>
          	    <thead style='background: #ffe4ba; color: #00509A;'>
           	 <tr class='info' >
           	   <th width='5'><center>No</center></th>
           	    <th width='25'><center>Unit Kerja</center></th>
           	   <th width='35%' ><center>No Kupon</center></th>
           	   <th width='35%' >No Rekening</th>
           	 </tr>
        	</thead>";




      		//  echo "hay ranmdom=".(mt_rand(0,$jumlah));

			
        	$norek="";
        	$nomorundian="";
			$i=0;
			$no=0;
        	for($i;$i<3;$i++)
        	{
        		        $no++;
        				$jumlah=0; 
        		        $norek="";
//        				$jumlah = $this->model_undian->data_maxUndianDistribusi($idkanca);
        				$jumlah =  $this->model_undian->data_JumlahCalonPemenangDistribusi($idkanca);
        				//$jumlah = $jumlah;
        			//	echo "me is jumlah=.".$jumlah;
        				$indexRandomHadiah = (mt_rand(0,$jumlah));
			   			$dataPemenang = $this->model_undian->data_CalonPemenangDistribusi($idkanca,$indexRandomHadiah);
			   		//	echo "</br>";
			   		//	echo $indexRandomHadiah;
			         //	echo "</br>";
			         //	echo "-----".$jumlah."-----";
			         //	print_r($dataPemenang);


        		        foreach ($dataPemenang as $row) 
				        {
				           $norek= $row->noRek;
				           $nomorundian = $row->NoUndianSemuaUnit;

				        }


        				$ok=$this->model_mstperiodehadiah->getnamahadiah($idkanca,$_GET['charhadiah'],$_GET['periode']);
				        foreach ($ok as $row) 
				        {
				           $hadiah= $row->varJenisHadiah.' '.$row->varMerkHadiah.' '.$row->varTypeHadiah;                    
				        }
				        $nama= $this->model_undian->get_namaukerundian($idkanca,substr($nomorundian,0,4));
    				//	$namaunit = $_POST["unitkerjacab"];
						$insert = array(
								'kodeUker' => substr($nomorundian,0,4),
								'namaUker' => $nama,
								'namahadiah' => $hadiah,
								'chrNoUndian' => $nomorundian,
								'chrNoRek' => $norek,
								'vcrNmNsbh' => $this->model_undian->get_namarekening($idkanca,$norek),
								'chrJnsHadiah' => $_GET['charhadiah'],
								'chrKdPeriode' => $_GET['periode'],
								'chrUserAdd' => $this->session->userdata('kode_user')
							);
					//	echo "data masukan ---";
					//	print_r($insert);
								if(strlen($norek) < 15 ){
					    			$norektamp="0".$norek;
					    			$norektamp = substr($norektamp,0,4)."-".substr($norektamp,4,2)."-".substr($norektamp,6,6)."-".substr($norektamp,12,2)."-".substr($norektamp,14,1);
					    		}
					    		else
					    		{

					    			$norektamp = substr($norektamp,0,4)."-".substr($norektamp,4,2)."-".substr($norektamp,6,6)."-".substr($norektamp,12,2)."-".substr($norektamp,14,1);
					    			
					    		}

						if(($jumlah !=0 || $jumlah!="") && $norek!="" )
						{
							$data['noTotal'] = $no;

							$this->load->view("try", $data);
							//$nama= $this->model_undian->get_namaukerundian($idkanca,substr($nomorundian,0,4));
    						$uker= $this->model_undian->get_namaukerundian($idkanca,$idkanca);

							echo "<tr>";

							echo "<td>";
							echo $no;
							echo "</td>";

							echo "<td>";
							echo $nama;
							echo "</td>";

							echo "<td>";
							echo $nomorundian ;
							echo "</td>";


							echo "<td>";
							echo $norektamp;
							echo "</td>";

							echo "<tr>";
							



							$this->model_undian->simpan_pemenangTempPemenang($idkanca,$insert);
					//		echo 'Save Data';

						}
						else
						{

					//		echo "datakosong";
						}


        	}

		}
		
		






		if (isset($_GET['noundian']))
		{
			$norektamp="";
			$nama= $this->model_undian->get_namaukerundian($idkanca,substr($_GET['noundian'],0,4)."-------");
    		$uker= $this->model_undian->get_namaukerundian($idkanca,$idkanca);
    		$norek = $this->model_undian->get_nomorrekening($_GET['noundian']);
    		if(strlen($norek) < 15 ){

    			$norektamp="0".$norek;
    			$norektamp = substr($norektamp,0,4)."-".substr($norektamp,4,2)."-".substr($norektamp,6,6)."-".substr($norektamp,12,2)."-".substr($norektamp,14,1);
    		}
    	//	echo $nama;
    	//	echo $uker;
		  //  echo substr($_GET['noundian'],0,4)."-------";
			//echo substr($_GET['noundian'],4,4)."-------";
			//echo substr($_GET['noundian'],8,8)."-------";
		
			//echo $_GET['noundian'];
			echo "<div style='font-size:20px; font-weight:bold; background: #ffe4ba; color: #00509A;''>DETAIL PEMENANG UNDIAN </div>";
			echo "<center>
		    <table width='100%'' style='font-size:26px; font-weight:bold' border='0'>
		      <tr>
  		       <td width='20%'' align='center'></td>
          		<td width='25%' align='center' >
		        <div align='left' class='style4'>
    			Unit Kerja &nbsp;
			    </div>
				</td>
		    
     			<td width='65%' align='left' colspan='2'>
		            ".$nama."
		            <input type='hidden' name='unitkerjacab' value='".$nama."' >
		        </td>
		      </tr>
		      <tr>
   		       <td align='center'></td>
		        <td>
		        Kantor Cabang
		        </td>
		    
		        <td align='left' colspan='2'>
		        ".$uker."
	            <input type='hidden' name='kantorcabang' value='".$uker."' >
		        </td>
		      </tr>
		          <tr>
   		       <td width='20%' align='center'></td>
		        <td>
		        No. Rekening
		        </td>
		    
     			<td align='left' colspan='2'>
       	            <input type='hidden' name='norekening' value='".$norek."' >
		            ".$norektamp."
		        </td>
		      <tr>

		    </table>
		    </center>";
    	
		
	


		}


	}



	//pengundian hadiah hiburan
	function ajax_callHiburanCepat() {
		$totalArrayPemanang=array();
		$idkanca = $this->session->userdata('kode_kanca');
		$truncateTempPemenang  =1;
		$namatabel = 'intHiburan'.$_GET['charhadiah'];
		$dataUnit = $this->model_undian->data_UnitDistribusi($idkanca,$namatabel,$_GET['periode']);
		$ok=$this->model_mstperiodehadiah->getnamahadiah($idkanca,$_GET['charhadiah'],$_GET['periode']);
		foreach ($ok as $row) 
		{
		   $hadiah= $row->varJenisHadiah.' '.$row->varMerkHadiah.' '.$row->varTypeHadiah;                    
		}
		if($truncateTempPemenang==1 && isset($_GET['charhadiah']) && isset($_GET['periode']))
		{
			echo "<div style='font-size:20px; font-weight:bold; background: #ffe4ba; color: #00509A;''>DETAIL PEMENANG UNDIAN </div>";
			echo "</br>";
			echo "<table class='table table-striped table-bordered table-condensed' style ='width:70%; font-weight:bold;' border='1'>
          	    <thead style='color: #00509A;'>
           	 <tr class='info' >
           	   <th width='3'><center>No</center></th>
           	    <th width='37'><center>Unit Kerja</center></th>
           	   <th width='30%' ><center>No Kupon</center></th>
           	   <th width='30%' >No Rekening</th>
           	 </tr>
           	 </thead>";

        	$norek="";
        	$nomorundian="";
			$i=0;
			$no=1;
			foreach ($dataUnit as $row) {
			//echo $row->chrKdUnit;
			$nama= $this->model_undian->get_namaukerundian($idkanca,$row->chrKdUnit);
			//echo "</br>";
			$uker = $row->chrKdUnit;
			$nilaimax = $this->model_undian->data_JumlahUnitDistribusiTiapUkerCepat($idkanca,$row->chrKdUnit,$_GET['periode']);
			//echo $nilaimax;
			$indexRandomHadiah = (mt_rand(0,$nilaimax));
			$dataUndian1 = $this->model_undian->data_UnitDistribusiTiapUkerCepat($idkanca,$namatabel,$uker,$indexRandomHadiah,$_GET['periode']);
			if(count($dataUndian1)==0)
			{
			

			}

			foreach ($dataUndian1 as $row1) {
			$norek=$row1->noRek;
			$norektamp=$norek;
			
			if(strlen($norek) == 14 ){

				$norektamp="0".$norek;
			}
			if(strlen($norek) == 13 ){

				$norektamp="00".$norek;
			}

			if(strlen($norek) == 12 ){

				$norektamp="000".$norek;
			}
			if(strlen($norek) == 15 ){

				$norektamp=$norek;
			}





			if($no%2==0)
			{
				echo "<tr bgcolor='#FF0000'>";
	
			}
			else
			{
				echo "<tr>";
			}
				//echo "$indexRandomHadiah";
				echo "<tr bgcolor='#f9f3e8'>";
				echo "<td><center>";
				echo $no;
				echo "</center></td>";
				echo "<td>";
				echo $nama;
				echo "</td>";
				echo "<td>";
				echo $row1->NoUndianSemuaUnit ;
				echo "</td>";
				echo "<td>";
				echo $norektamp;
				echo "</td>";
				echo "<tr>";

				$no++;
				$insert = array(
					'kodeUker' => $uker,
					'namaUker' => $nama,
					'namahadiah' => $hadiah,
					'chrNoUndian' =>  $row1->NoUndianSemuaUnit,
					'chrNoRek' => $norek,
					'vcrNmNsbh' => $this->model_undian->get_namarekening($idkanca,$norek),
					'chrJnsHadiah' => $_GET['charhadiah'],
					'chrKdPeriode' => $_GET['periode'],
					'chrUserAdd' => $this->session->userdata('kode_user')
							);
			array_push($totalArrayPemanang,$insert);
			

			}

			}
			echo "</table>";
			$data['totalArrayPemanang']=$totalArrayPemanang;
			$this->load->view("try", $data);


		}
		
		
	}

	

	public function savePemenangDistribusi()
	{
		$sukses = 0;
		$idkanca = $this->session->userdata('kode_kanca');
		//echo $GLOBALS['totalArrayPemanang'];
		//$arraySave =$this->post['jsonInsert'];
		$arraySave = $this->input->post('jsonInsert');
		//echo $arraySave;
		//echo 'hay';
		$url=  $this->input->post('tampungUrl');

		$a = json_decode($arraySave, true);
		//$sukses = $this->model_undian->simpan_pemenangHadiahHiburan($idkanca,$a);
		//echo $sukses;
		//print_r($a);
		//print_r($a['namahadiah']);
		$periode = $arraySave = $this->input->post('idundian');
		


		foreach ($a as $row) {
	//		echo 1;
			$sukses = $this->model_undian->simpan_pemenangHadiahHiburan($idkanca,$row);
			$this->model_undian->simpan_tempUndian($idkanca, $periode,$row['chrNoRek']);
	//		echo $sukses;
			//echo $row->chrNoUndian;
		//	echo "</br>";
		//	/# code...
		}
		$sukses = $sukses +1;
		$this->session->set_flashdata('suksesa', $sukses);
		redirect($url);

	}


	public function cekvalidasi_undian($kodeperiode)
	{
		$jumlahmax 		= '0';
		$jumlah_masuk 	= '0';
		$jumlahMaxKupon	= '0';

		$data['jumlahmax'] 		= $jumlahmax;
		$data['jumlah_masuk'] 	= $jumlah_masuk;
		$data['jumlahMaxKupon']	= $jumlahMaxKupon;		




		$statushadiahcabang		= $this->model_mstperiodehadiah->statusHadiahDepan($this->session->userdata('kode_kanca'),$kodeperiode);
		//$jumlahunit 			= $this->model_mstuker->jumlahunitsupervisi($this->session->userdata('kode_kanca'));
		//$jumlahunitdistribusi 	= $this->model_mstuker->jumlahunitdistriusi($this->session->userdata('kode_kanca'),$kodeperiode);


		$countdown 				= $this->model_mstperiodehadiah->selisihwaktuundian($this->session->userdata('kode_kanca'),$kodeperiode);


		//cek distribusi
		$flagarraydistribusi = $this->cekdistribusihadiah($kodeperiode,$this->session->userdata('kode_kanca'));
		$statusdistribusi='';

		foreach ($flagarraydistribusi as $row) {
			$statusdistribusi =  $row;
			# code...
		}


//		$jumlahsupervisi	= count($this->model_mstuker->datasupervisi($this->session->userdata('kode_kanca'))); 
		$jumlahsupervisi	= 0; 

		
		$undianready = 1;
		if($statusdistribusi!="" || $statusdistribusi=='kosong')
		{
		//	$undianready = 0;
		}


		if($statushadiahcabang!=4)
		{
		//	echo "hadiah belum disetujui";
			$undianready = 0;
		}
		if($countdown <= 0 )
		{
		//	echo "tanggal undian telah expired";
			$undianready =0;
		}
	    if($jumlahmax <= $jumlahMaxKupon )
	    {
	    	//$undianready = 0;
	   	//	echo "hadiah belumsiap";
	    }

	  //   if($jumlahunit > $jumlahunitdistribusi )
	   // {
	    	//$undianready = 0;
	   	//	echo "hadiah belumsiap";
	    //}


	    
   		return $undianready;

	}

	public function cekvalidasi_undian_hiburan($kodeperiode)
	{
		$jumlahmax 		= '0';
		$jumlah_masuk 	= '0';
		$jumlahMaxKupon	= '0';



		$statushadiahcabang		= $this->model_mstperiodehadiah->statusHadiahDepan($this->session->userdata('kode_kanca'),$kodeperiode);
		$jumlahunit 			= $this->model_mstuker->jumlahunitsupervisi($this->session->userdata('kode_kanca'));
		$jumlahunitdistribusi 	= $this->model_mstuker->jumlahunitdistriusi($this->session->userdata('kode_kanca'),$kodeperiode);




		$cekTable =$this->model_undian->cektable_existornot($this->session->userdata('kode_kanca'),$kodeperiode);

		if($cekTable){
		$jumlahmax 		= $this->model_undian->get_nilaimaxKuponPeriode($this->session->userdata('kode_kanca'),$kodeperiode);
		$jumlah_masuk 	= $this->model_undian->get_nilaimaxKuponMasuk($this->session->userdata('kode_kanca'),$kodeperiode);
		$jumlahMaxKupon	= $this->model_undian->get_maxundiandaridtlnomorundianPeriode($this->session->userdata('kode_kanca'),$kodeperiode);

		$data['jumlahmax'] 		= $jumlahmax;
		$data['jumlah_masuk'] 	= $jumlah_masuk;
		$data['jumlahMaxKupon']	= $jumlahMaxKupon;		
		 }

		$countdown 				= $this->model_mstperiodehadiah->selisihwaktuundian($this->session->userdata('kode_kanca'),$kodeperiode);


		//cek distribusi
		$flagarraydistribusi = $this->cekdistribusihadiah($kodeperiode,$this->session->userdata('kode_kanca'));
		$statusdistribusi='';
		foreach ($flagarraydistribusi as $row) {
			$statusdistribusi =  $row;
			# code...
		}


		





		$undianready = 1;
		if($statusdistribusi!="" || $statusdistribusi=='kosong')
		{
		//	$undianready = 0;
		}


		if($statushadiahcabang!=4)
		{
		//	echo "hadiah belum disetujui";
			$undianready = 0;
		}
		if($countdown <= 0 )
		{
		//	echo "tanggal undian telah expired";
			$undianready =0;
		}
	    
	     if($jumlahunit > $jumlahunitdistribusi )
	       {
	    	//$undianready = 0;
	   	//	echo "hadiah belumsiap";
	      }
	    

	    
   		return $undianready;

	}

	public function cekdistribusihadiah($idperiode,$id_kanca)
	{
		$datajenishadiah		= array();
		$datajumlahhadiah		='';
		$tampung 				="";


		$dataexisting 			 = $this->model_mstperiodehadiah->cek_distribusihadiahhiburanada($idperiode,$id_kanca);

		if($dataexisting == 1)
		{

			$datajenishadiahexisting = $this->model_mstperiodehadiah->get_data_idjenishadiah($idperiode,$id_kanca);
			foreach ($datajenishadiahexisting as $row) {

				$tampung 			 = $this->model_mstperiodehadiah->distribusi_hadiah_hiburan($idperiode,$id_kanca,$row->chrJnsHadiah);

				foreach ($tampung as $cell) {
					
				if( $cell->ditribusi == 0)
					{
						array_push($datajenishadiah, $cell->chrJnsHadiah);
					
					}		

				}

			
			}
		}
		else
		{
						array_push($datajenishadiah, 'kosong');
			
		}
	
		
		return $datajenishadiah;

	}

	public function generate_distribusi_kupon()
	{
		ini_set('max_execution_time', 0);
		$idkanca = $this->session->userdata('kode_kanca');
		$periodeUndian=$_GET['id'];
		$exekusistreprosedur = $this->model_kupon->distribusibysotreprosedur($idkanca,$periodeUndian);
	    //$hapustabel = $this->model_undian->truncate_dbo_tampnoundian($idkanca);
		//$hapustabel=1;
		//echo"hapus tabel ".$hapustabel; 


	}

	//sistem pengundian baru
   public function pengacakan_undian_hadiah()
   {
   	  
   	  ini_set('max_execution_time', 0);


   	  while(true){
   	  
	   $data_range_undian = array();
   	   $range = array();
   	   $x=0;

   	  $idkanca 			 = $this->session->userdata('kode_kanca');
 	  $periodeUndian 	 =$_GET['periode'];

 	  $jumlah_uker_total = $this->model_undian->jumlah_uker($idkanca,$periodeUndian);
 	  $jumlah_bulan_total= $this->model_undian->jumlah_kode_bulan($idkanca,$periodeUndian);

 	  $index_uker 		 = mt_rand(0,$jumlah_uker_total-1);
 	  $index_bulan 		 = mt_rand(0,($jumlah_bulan_total-1));


 	  $kode_uker 		 = $this->model_undian->kode_uker($idkanca,$periodeUndian,$index_uker);
 	  $kode_bulan 		 = $this->model_undian->kode_bulan($idkanca,$periodeUndian,$index_bulan);

   	  $jumlah_nomorkupon = $this->model_undian->jumlah_kupon_total($idkanca,$periodeUndian,$kode_uker ,$kode_bulan);
   	 

   	  $data_range 		 = $this->model_undian->get_range_nomorrekening_kupon($idkanca, $periodeUndian,$kode_bulan,$kode_uker);

   	   if(!empty($data_range))
   	   {
    	   	foreach ($data_range as $row) {
		  	$range = range($row->KuponAwal, $row->KuponAkhir);
   	  		
   	  		foreach ($range as $row) {

 	  	  		array_push($data_range_undian, $row);
   	  		}
   	  	}
   	   }
   	  else
   	  {
   	  	array_push($data_range_undian,'0');
   	  }

   	  

 	  while( in_array( ($index_nomorkupon = rand(1,($jumlah_nomorkupon-1))), $data_range_undian ) );
 
      $nomor_rek 		 = $this->model_undian->get_nomorrekening_kupon($idkanca, $periodeUndian,$kode_bulan,$kode_uker,$index_nomorkupon);



	   	  $concat_kupon = '';
	   	  $jumlah_char =  strlen($index_nomorkupon);
	   	  $ulang = 8;
	   	  
	   	  for($i = 0; $i<$ulang-$jumlah_char; $i++)
	   	  {
	   	  	$concat_kupon = $concat_kupon.'0';
	   	  }

	   	  $concat_uker = '';
	   	  $jumlah_chr_uker =  strlen($kode_uker);
	   	  $ulang = 4;
	   	  for($i = 0; $i<$ulang-$jumlah_chr_uker; $i++)
	   	  {
	   	  	$concat_uker = $concat_uker.'0';
	   	  }

	   	  $nomor_undian = $concat_uker.$kode_uker.$kode_bulan.$concat_kupon.$index_nomorkupon;

	   	  //echo "kirim =".$kode_uker."/".$nomor_undian;
  	   	  echo $kode_uker."/".$nomor_undian;

  	   	  if($nomor_undian!='')
  	   	  {
  	   	  	break;
  	   	  }
  	  }





   	  
   }

   //new

   	public function setperiode_singledraw()
	{

		$data['kode_user']=$this->session->userdata('kode_user');

		$data['nama_user'] = $this->session->userdata('nama_user');
		$data['kode_kanca'] = $this->session->userdata('kode_kanca');
		$data['group_area'] = $this->session->userdata('group_area');
		$data['otoritas'] = $this->session->userdata('otoritas');
		$data['kodekanwil'] = $this->session->userdata('kanwil');
		$idkanca = $this->session->userdata('kode_kanca');
		$otoritas = $this->session->userdata('otoritas');

		//$data["sisahiburan"] = $this->model_hadiahKanca->jumlah_hadiahhiburan();
		//$data["sisabiasa"] = $this->model_hadiahKanca->jumlah_hadiahumum();
		//$data["sisautama"] = $this->model_hadiahKanca->jumlah_hadiahutama();
		$data["hadiahPeriode"] = $this->model_msthadiahperiode->data_hadiah_tampilkan();
		$data["periode"] = $this->model_mstperiode->data_mstperiode();

		
	

		 $data['page'] = 'pengundian/new/v_periodeundian';
		 $data['menu'] = 'main_dashboard';
		 $this->load->view("layouts/fixundian", $data);
	}

	public function singledraw()
	{
		$countdown=10;
		if(isset($_GET['periode']))
		{
			$countdown 				= $this->model_mstperiodehadiah->selisihwaktuundian($this->session->userdata('kode_kanca'),$_GET['periode']);
		}


		
		if($countdown>=604800)
		{
			redirect("pengundian/setperiode_singledraw?st=x&periode=".$_GET['periode']);
		}


		$truncateTempPemenang  = $this->model_undian->truncute_dbo_tmpdaftarpemenang('pengundianoffline');
	 
		
		$data['kode_user']=$this->session->userdata('kode_user');
		$data['nama_user'] = $this->session->userdata('nama_user');
		$data['kode_kanca'] = $this->session->userdata('kode_kanca');
		$data['group_area'] = $this->session->userdata('group_area');
		$data['otoritas'] = $this->session->userdata('otoritas');
		$data['kodekanwil'] = $this->session->userdata('kanwil');
		$otoritas = $this->session->userdata('otoritas');
		$idkanca = $this->session->userdata('kode_kanca');

		//variable pengunundian
	//	$data["datanokupon"] = $this->model_mstperiodehadiah->get_nomorundian($idkanca);
		//$nomorundian = $this->model_mstperiodehadiah->get_nomorundian($idkanca);
		$arraynomorundian = array();

		$no=0;


		$data['maxundian'] = 0;

		if(isset($_GET['periode']))
		{	
			$flag = $this->cekvalidasi_undian($_GET['periode']);
			if($flag!=1)
			{
				redirect("pengundian/setperiode_singledraw?st=1&periode=".$_GET['periode']);
			}


			$tanggal 	= $this->model_mstperiodehadiah->selisihwaktuundian($this->session->userdata('kode_kanca'),$_GET['periode']);
			if($tanggal < 0 )
			{
					redirect("pengundian/setperiode_singledraw?st=0&periode=".$_GET['periode']);
			}


		//$data['maxundian'] = $this->model_undian->data_jumlahpengundianKuponCepat($idkanca,$_GET['periode']);
		$data['rangeperiode']=$_GET['x'];
		$data['idperiode']=$_GET['periode'];
		$data['datajenishadiah'] = $this->model_undian->get_undian_hadiahumum($idkanca,$_GET['periode']);
		//$data["sisahiburan"] = $this->model_hadiahKanca->jumlah_hadiahhiburan();
		//$data["sisabiasa"] = $this->model_hadiahKanca->jumlah_hadiahumum();
		//$data["sisautama"] = $this->model_hadiahKanca->jumlah_hadiahutama();
		$data["hadiahPeriode"] = $this->model_msthadiahperiode->data_hadiah_tampilkan();
		$data["periode"] = $this->model_mstperiode->data_mstperiode();
		$data['page'] = 'pengundian/new/v_pengacakanundian';
		$data['menu'] = 'main_dashboard';
		$this->load->view("layouts/fixundian", $data);
		}
		else{
		//redirect("pengundian/setperiode_singledraw");
		}

	}

	function get_pemenang_undian_single_draw() {

		
		$idkanca = $this->session->userdata('kode_kanca');
		if (isset($_GET['noundian']) && isset($_GET['id']))
		{
			$norektamp="";
			$namaPemenang = '';
			$norek = '';



			$nama= $this->model_undian->get_namaukerundian($idkanca,substr($_GET['noundian'],0,4)."-------");
    		
    		$uker= $this->model_undian->get_namaukerundian_new(substr($_GET['noundian'],0,4));

    		$data_pemenang= $this->model_undian->get_nomorrekening_new($idkanca,$_GET['id'],substr($_GET['noundian'],0,4),substr($_GET['noundian'],4,4),substr($_GET['noundian'],8,8));
	        
	        //echo substr($_GET['noundian'],0,4);
	        //echo "</br>";
	        //echo substr($_GET['noundian'],4,4);
	        //echo "</br>";
	        //echo substr($_GET['noundian'],8,8);
	        //echo "</br>";

	        foreach ($data_pemenang as $row) {
	        	$norek=$row->NoRek;
	        	$namaPemenang = $row->namaNasabah;
			 }

			 


    		//$norek = $this->model_undian->get_nomorrekening($idkanca,$_GET['id'],$_GET['noundian']);
    		 $norektamp=$norek;

    		if(strlen($norek) == 14 ){

    			$norektamp="0".$norek;
    		}
    		if(strlen($norek) == 13 ){

    			$norektamp="00".$norek;
    		}

    		if(strlen($norek) == 12 ){

    			$norektamp="000".$norek;
    		}

   			//$norektamp = substr($norektamp,0,4)."-".substr($norektamp,4,2)."-".substr($norektamp,6,6)."-".substr($norektamp,12,2)."-".substr($norektamp,14,1);
			//hidden
			$norektamp = substr($norektamp,0,4)."-".substr($norektamp,4,2)."-".substr($norektamp,6,6)."-".substr($norektamp,12,1)."X"."-"."XX";


			echo "<center>
		    <div style='font-size:20px; font-weight:bold; background: #ffe4ba; color: #00509A;''>DETAIL PEMENANG UNDIAN </div>
		    </br>
		    <table width='100%' style='font-size:26px; font-weight:bold' border='0'>
		      <tr>
  		       <td width='20%'' align='center'></td>
          		<td width='25%' align='center' >
		        <div align='left' class='style4'>
    			Unit Kerja &nbsp;
			    </div>
				</td>
		   		 <td width='1%' align='center' >
		        </td>
     			<td width='55%' align='left' colspan='2' class='style4' style='vertical-align: text-top;' >
		            ".$nama."
		            <input type='hidden' name='unitkerjacab' value='".$nama."' >
		        </td>
		      </tr>
		      ".
		      /*
		      "
		      <tr>
   		       <td align='center'></td>
		        <td>
		        Kantor Cabang
		        </td>
		    
		        <td align='left' colspan='2' >
		        ".$uker."
	            <input type='hidden' name='kantorcabang' value='".$uker."' >
		        </td>
		      </tr>
		      ".
		      */
		      "
		          <tr>
   		       <td align='center'></td>
		        <td class='style4'>
		        No. Rekening
		        </td>
  		   		 <td width='1%' align='center' >
		        </td>

     			<td class='style4' align='left' colspan='2' style='vertical-align: text-top;'>
       	            <input type='hidden' name='norekening' value='".$norek."' >
		            ".$norektamp."
		        </td>
		      </tr>

		      <tr>
   		       <td align='center' class='style4'></td>
		        <td class='style4'>
		        Nama Nasabah
		        </td>
   		   		 <td width='1%' align='center' >
		        </td>

		    
     			<td class='style4' align='left' colspan='2' style='vertical-align: text-top;'>
       	            <input type='hidden' name='namaPemenang' value='".$namaPemenang."' >
		            ".$namaPemenang."
		        </td>
		      </tr>


		    </table>
		    </center>";
    	
		
	


		}



	}



	public function simpanpemenang_single_draw_new() {

		$idkanca = $this->session->userdata('kode_kanca');
		$hadiah='';
		$ok=$this->model_mstperiodehadiah->getnamahadiah($idkanca,$this->input->post("jenishadiah"),$this->input->post("idundian"));
        if (isset($ok) && $ok!=null) 
           {
           foreach ($ok as $row) 
           {
             $hadiah= $row->varJenisHadiah.' '.$row->varMerkHadiah.' '.$row->varTypeHadiah;                    
           }

        }

		$namaunit = $this->input->post("unitkerjacab");
		$insert = array(
				'kodeUker' => $this->input->post('kode_unitkerja'),
				'namaUker' => $namaunit,
				'namahadiah' => $hadiah,
				'chrNoUndian' => $this->input->post('nomor_undian'),
				'chrNoRek' => $this->input->post('norekening'),
			    'vcrNmNsbh' => $this->input->post('namaPemenang'),	
				//'vcrNmNsbh' => $this->model_undian->get_namarekening($idkanca,$this->input->post("norekening")),
				'chrJnsHadiah' => $this->input->post("jenishadiah"),
				'chrKdPeriode' => $this->input->post('idundian'),
				'chrUserAdd' => $this->session->userdata('kode_user')
				
			);


		echo $this->input->post("unitkerjacab");
		echo "<br/>";
		echo $this->input->post("kantorcabang");
		echo "<br/>";
		echo $this->input->post("norekening");
		echo "<br/>";
		echo $this->input->post("nomor_undian");
		echo "<br/>";
		echo $this->input->post("jenishadiah");
		echo "<br/>";
		echo $this->input->post("idundian");
		echo "<br/>";
		echo $this->model_undian->get_namarekening($idkanca,$this->input->post("norekening"));
		echo "<br/>";
		echo $this->input->post("namahadiahlengkap");
		echo "<br/>";
		echo  $hadiah;
		echo "<br/>";
		$this->model_undian->simpan_noacakUndian($idkanca,$this->input->post("norekening"));
		$url = $this->input->post('urlpost');
		
		
		
		print_r($insert);

		$sukses =  $this->model_undian->simpan_pemenang($idkanca,$insert);
		//$this->model_undian->simpan_tempUndian($idkanca,$idkanca,$this->input->post("norekening"));
		//$this->model_undian->simpan_tempUndian($idkanca,$this->input->post('idundian'),$this->input->post("norekening"));
		$sukses = $sukses +1;
		$this->session->set_flashdata('suksesa', $sukses);
		redirect($url);
	


	}



public function pengacakan_undian_hadiah_multi_draw()
   {
 		$totalArrayPemanang=array();
   	   $data_range_undian = array();
   	   $range = array();
   	   $x=0;
   	   //echo $_GET['periode'];

   	  ini_set('max_execution_time', 0);
   	  $idkanca 			 = $this->session->userdata('kode_kanca');
 	  $periodeUndian 	 =$_GET['periode'];
 	  $jumlah_uker_total = $this->model_undian->jumlah_uker($idkanca,$periodeUndian);
 	  $jumlah_bulan_total= $this->model_undian->jumlah_kode_bulan($idkanca,$periodeUndian);
 	  $idkanca = $this->session->userdata('kode_kanca');
	  $truncateTempPemenang  = $this->model_undian->truncute_dbo_tmpdaftarpemenang($idkanca);
	

	$ok=$this->model_mstperiodehadiah->getnamahadiah($idkanca,$_GET['charhadiah'],$_GET['periode']);
	foreach ($ok as $row) 
	{
	   $hadiah= $row->varJenisHadiah.' '.$row->varMerkHadiah.' '.$row->varTypeHadiah;                    
	}

	if($truncateTempPemenang==1 && isset($_GET['periode']) && isset($_GET['jumlah']))
	{

			echo "<div style='font-size:20px; font-weight:bold; background: #ffe4ba; color: #00509A;''>DETAIL PEMENANG UNDIAN </div>";
			echo "</br>";
			echo "<table class='table table-striped table-bordered table-condensed' style ='width:90%; font-weight:bold;' border='1'>
          	    <thead style='color: #00509A;'>
           	 <tr class='info' >
           	   <th width='3%'><center>No</center></th>
           	    <th width='25%'><center>Unit Kerja</center></th>
           	   <th width='25%' >No Kupon</th>
           	   <th width='25%' >No Rekening</th>
           	   <th width='22%' >Nama Nasabah</th>
           	 </tr>
           	 </thead>";

        	$norek="";
        	$nomorundian="";
			$x=0;
			$no=1;

			$jumlahUndianMax=$_GET['jumlah'];

			 while($x<$jumlahUndianMax){
		 	  $index_uker 		 = mt_rand(0,$jumlah_uker_total-1);
		 	  $index_bulan 		 = mt_rand(0,($jumlah_bulan_total-1));


		 	  $kode_uker 		 = $this->model_undian->kode_uker($idkanca,$periodeUndian,$index_uker);
		 	  $kode_bulan 		 = $this->model_undian->kode_bulan($idkanca,$periodeUndian,$index_bulan);

   		 	  //$nama_uker= $this->model_undian->get_namaukerundian($idkanca,$kode_uker);
   		 	  $nama_uker= $this->model_undian->get_namaukerundian($idkanca,$kode_uker);
		   	  $jumlah_nomorkupon = $this->model_undian->jumlah_kupon_total($idkanca,$periodeUndian,$kode_uker ,$kode_bulan);
		   	 

		   	  $data_range 		 = $this->model_undian->get_range_nomorrekening_kupon_multi_draw($idkanca, $periodeUndian,$kode_bulan,$kode_uker);

		   	   if(!empty($data_range))
		   	   {
		    	   	foreach ($data_range as $row) {
		    	  // 		echo $row->chrNoRek;
		    	   	//	echo "</br>";
				  	$range = range($row->KuponAwal, $row->KuponAkhir);
		   	  		
		   	  		foreach ($range as $row) {
		 	  	  		array_push($data_range_undian, $row);
		   	  		}
		   	  	}
		   	   }
		   	  else
		   	  {
		   	  	array_push($data_range_undian,'0');
		   	  }

		 	 //get rondom
		 	  while( in_array( ($index_nomorkupon = rand(1,($jumlah_nomorkupon-1))), $data_range_undian ) );
		 	  //echo $index_nomorkupon."---";
		 	  //echo $kode_uker;
		 
	    	$nomor_rek='';
        	$namaPemenang = '';;

		     $data_pemenang 		 = $this->model_undian->get_nomorrekening_kupon_multidraw($idkanca, $periodeUndian,$kode_bulan,$kode_uker,$index_nomorkupon);
             
  		    foreach ($data_pemenang as $row) {
	        	$nomor_rek=$row->NoRek;
	        	$namaPemenang = $row->namaNasabah;
			 }


             // echo "======".$nomor_rek;

			   	  $concat_kupon = '';
			   	  $jumlah_char =  strlen($index_nomorkupon);
			   	  $ulang = 8;
			   	  
			   	  for($i = 0; $i<$ulang-$jumlah_char; $i++)
			   	  {
			   	  	$concat_kupon = $concat_kupon.'0';
			   	  }

			   	  $concat_uker = '';
			   	  $jumlah_chr_uker =  strlen($kode_uker);
			   	  $ulang = 4;
			   	  for($i = 0; $i<$ulang-$jumlah_chr_uker; $i++)
			   	  {
			   	  	$concat_uker = $concat_uker.'0';
			   	  }

			   	  $nomor_undian = $concat_uker.$kode_uker.$kode_bulan.$concat_kupon.$index_nomorkupon;

		
			   	  //echo "kirim =".$kode_uker."/".$nomor_undian;
			   	  //echo "</br>";
			   	  //echo "$nama_uker";
        	   	  //echo "</br>";

        	   	if($namaPemenang!=''){  
       	   	    if($no%2==0)
				{
					echo "<tr bgcolor='#f9f3e8'>";
	
				}
				else
				{
					echo "<tr>";
				}
					//echo "<tr bgcolor='#f9f3e8'>";
					echo "<td><center>";
					echo $no;
					echo "</center></td>";
					echo "<td>";
					echo $nama_uker;
					echo "</td>";
					echo "<td>";
					echo $nomor_undian;
					echo "</td>";
					echo "<td>";
					//echo substr($nomor_rek, 0,15)$nomor_rek;
					echo substr($nomor_rek, 0,12)."XXX";
					echo "</td>";
					$nama_nasabah = $namaPemenang;
					echo "<td>";
					echo $nama_nasabah;
					echo "</td>";

					$insert = array(
					'kodeUker' => $kode_uker,
					'namaUker' => $nama_uker,
					'namahadiah' => $hadiah,
					'chrNoUndian' =>  $nomor_undian,
					'chrNoRek' => $nomor_rek,
					'vcrNmNsbh' => $nama_nasabah,
					'chrJnsHadiah' => $_GET['charhadiah'],
					'chrKdPeriode' => $_GET['periode'],
					'chrUserAdd' => $this->session->userdata('kode_user')
						);

					//insert di temp pemenang
					array_push($totalArrayPemanang,$insert);
				    $this->model_undian->simpan_pemenangTempPemenang($idkanca,$insert);


					echo "</tr>";

        	   	  $no++;
			   	  
        	   	  $x++;
        	   	  //print_r($insert);
	   		   	  }
	   		   	}

	   		   //	print_r($totalArrayPemanang);

	   		   	echo "</table>";

	   		   	$data['totalArrayPemanang']=$totalArrayPemanang;
	   		   	$this->load->view("try", $data);



	}
		



 	 



   	  
   }

   //pengacakan massal undian biasa
   	public function setperiode_multidraw()
	{

		$data['kode_user']=$this->session->userdata('kode_user');

		$data['nama_user'] = $this->session->userdata('nama_user');
		$data['kode_kanca'] = $this->session->userdata('kode_kanca');
		$data['group_area'] = $this->session->userdata('group_area');
		$data['otoritas'] = $this->session->userdata('otoritas');
		$data['kodekanwil'] = $this->session->userdata('kanwil');
		$idkanca = $this->session->userdata('kode_kanca');
		$otoritas = $this->session->userdata('otoritas');

		//$data["sisahiburan"] = $this->model_hadiahKanca->jumlah_hadiahhiburan();
		//$data["sisabiasa"] = $this->model_hadiahKanca->jumlah_hadiahumum();
		//$data["sisautama"] = $this->model_hadiahKanca->jumlah_hadiahutama();
		$data["hadiahPeriode"] = $this->model_msthadiahperiode->data_hadiah_tampilkan();
		$data["periode"] = $this->model_mstperiode->data_mstperiode();

		 $data['page'] = 'pengundian/new/v_mass_periodeundian';
		 $data['menu'] = 'main_dashboard';
		 $this->load->view("layouts/fixundian", $data);
	}

	public function multidraw()
	{
		$truncateTempPemenang  = $this->model_undian->truncute_dbo_tmpdaftarpemenang('pengundianoffline');
	 
	 	$countdown = 10;
	 	if(isset($_GET['periode']))
	 	{
		$countdown 				= $this->model_mstperiodehadiah->selisihwaktuundian($this->session->userdata('kode_kanca'),$_GET['periode']);
		}

		if($countdown>=604800)
		{
			redirect("pengundian/setperiode_multidraw?st=x&periode=".$_GET['periode']);
		}

		$data['kode_user']=$this->session->userdata('kode_user');
		$data['nama_user'] = $this->session->userdata('nama_user');
		$data['kode_kanca'] = $this->session->userdata('kode_kanca');
		$data['group_area'] = $this->session->userdata('group_area');
		$data['otoritas'] = $this->session->userdata('otoritas');
		$data['kodekanwil'] = $this->session->userdata('kanwil');
		$otoritas = $this->session->userdata('otoritas');
		$idkanca = $this->session->userdata('kode_kanca');

		//variable pengunundian
	//	$data["datanokupon"] = $this->model_mstperiodehadiah->get_nomorundian($idkanca);
		//$nomorundian = $this->model_mstperiodehadiah->get_nomorundian($idkanca);
		$arraynomorundian = array();

		$no=0;



	
		//$data["noarray"] = json_encode($arraynomorundian);

		if(isset($_GET['periode']))
		{
			$flag = $this->cekvalidasi_undian($_GET['periode']);
			if($flag!=1)
			{
				redirect("pengundian/setperiode_multidraw?st=1&id=".$_GET['periode']);
			}

			$tanggal 	= $this->model_mstperiodehadiah->selisihwaktuundian($this->session->userdata('kode_kanca'),$_GET['periode']);
			if($tanggal < 0 )
			{
					redirect("pengundian/setperiode_multidraw?st=0&id=".$_GET['periode']);
			}

		$data['maxundian'] = 10;
		$data['rangeperiode']=$_GET['x'];
		$data['idperiode']=$_GET['periode'];
		$data['datajenishadiah'] = $this->model_undian->get_undian_hadiahumum($idkanca,$_GET['periode']);
		//$data["sisahiburan"] = $this->model_hadiahKanca->jumlah_hadiahhiburan();
		//$data["sisabiasa"] = $this->model_hadiahKanca->jumlah_hadiahumum();
		//$data["sisautama"] = $this->model_hadiahKanca->jumlah_hadiahutama();
		$data["hadiahPeriode"] = $this->model_msthadiahperiode->data_hadiah_tampilkan();
		$data["periode"] = $this->model_mstperiode->data_mstperiode();
		$data['page'] = 'pengundian/new/v_mass_pengacakanundian';
		$data['menu'] = 'main_dashboard';
		$this->load->view("layouts/fixundian", $data);
		}
		else{
		redirect("pengundian/setperiode_multidraw");}
	}




	public function SavePemenangMultiDraw()
	{
		$sukses = 0;
		$idkanca = $this->session->userdata('kode_kanca');
		//echo $GLOBALS['totalArrayPemanang'];
		//$arraySave =$this->post['jsonInsert'];
		$arraySave = $this->input->post('jsonInsert');
		//echo $arraySave;
		//echo 'hay';
		$url=  $this->input->post('tampungUrl');

		$a = json_decode($arraySave, true);
		//$sukses = $this->model_undian->simpan_pemenangHadiahHiburan($idkanca,$a);
		//echo $sukses;
		//print_r($a);
		//print_r($a['namahadiah']);
		$periode = $arraySave = $this->input->post('idundian');
		


		foreach ($a as $row) {
	//		echo 1;
			$sukses = $this->model_undian->simpan_pemenangHadiah_multidraw($idkanca,$row);
	//		echo $sukses;
			//echo $row->chrNoUndian;
		//	echo "</br>";
		//	/# code...
		}
		$sukses = $sukses +1;
		$this->session->set_flashdata('suksesa', $sukses);
		redirect($url);

	}

	//undian hadiah hiburan
	public function pengacakan_undian_hadiah_hiburan()
   {
 	    $totalArrayPemanang=array();
   	   $data_range_undian = array();
   	   $range = array();
   	   $x=0;
   	   //echo $_GET['periode'];

   	  ini_set('max_execution_time', 0);
   	  $idkanca 			 = $this->session->userdata('kode_kanca');
 	  $periodeUndian 	 =$_GET['periode'];
 	  $jumlah_uker_total = $this->model_undian->jumlah_uker($idkanca,$periodeUndian);
 	  $jumlah_bulan_total= $this->model_undian->jumlah_kode_bulan($idkanca,$periodeUndian);
 	  $idkanca = $this->session->userdata('kode_kanca');
	  $truncateTempPemenang  = $this->model_undian->truncute_dbo_tmpdaftarpemenang($idkanca);
	  $ok=$this->model_mstperiodehadiah->getnamahadiah($idkanca,$_GET['charhadiah'],$_GET['periode']);
	foreach ($ok as $row) 
	{
	   $hadiah= $row->varJenisHadiah.' '.$row->varMerkHadiah.' '.$row->varTypeHadiah;                    
	}

	if($truncateTempPemenang==1 && isset($_GET['periode']))
	{

			echo "<div style='font-size:20px; font-weight:bold; background: #ffe4ba; color: #00509A;''>DETAIL PEMENANG UNDIAN </div>";
			echo "</br>";
			echo "<table class='table table-striped table-bordered table-condensed' style ='width:90%; font-weight:bold;' border='1'>
          	    <thead style='color: #00509A;'>
           	 <tr class='info' >
           	   <th width='3%'><center>No</center></th>
           	    <th width='25%'><center>Unit Kerja</center></th>
           	   <th width='25%' >No Kupon</th>
           	   <th width='25%' >No Rekening</th>
           	   <th width='22%' >Nama Nasabah</th>
           	  </tr>
           	 </thead>";

        	$norek="";
        	$nomorundian="";
			$x=0;
			$no=1;

			$uker_hiburan =  $this->model_undian->get_unit_distribusi_hadiah_hiburan($idkanca,$periodeUndian,$_GET['charhadiah']);
			//print_r($uker_hiburan);


			foreach ($uker_hiburan as $row) {
				//echo $row->chrKdUnit;
				//echo "</br>";
				# code...




			 $flagbulan = 0;
			 $flagbulanrandom = array();
			 array_push($flagbulanrandom, 0);
		   	  	
		 	 while ($flagbulan < $jumlah_bulan_total) {


		 	



		 	 			 	 // $index_uker 		 = mt_rand(0,$jumlah_uker_total-1);
		 	 // $index_bulan 		 = mt_rand(0,($jumlah_bulan_total-1));
		 	  while( in_array( ($index_bulan = rand(1,($jumlah_bulan_total-1))), $flagbulanrandom ) );



		 	 // $kode_uker 		 = $this->model_undian->kode_uker($idkanca,$periodeUndian,$index_uker);
		 	  $kode_uker 		 = $row->chrKdUnit;
		 	  $kode_bulan 		 = $this->model_undian->kode_bulan($idkanca,$periodeUndian,$index_bulan);

   		 	  //$nama_uker= $this->model_undian->get_namaukerundian($idkanca,$kode_uker);
   		 	  $nama_uker= $this->model_undian->get_namaukerundian($idkanca,$kode_uker);
		   	  $jumlah_nomorkupon = $this->model_undian->jumlah_kupon_total($idkanca,$periodeUndian,$kode_uker ,$kode_bulan);
		   	 

		   	  $data_range 		 = $this->model_undian->get_range_nomorrekening_kupon_multi_draw($idkanca, $periodeUndian,$kode_bulan,$kode_uker);

		   	   if(!empty($data_range))
		   	   {
		    	   	foreach ($data_range as $row) {
		    	  // 		echo $row->chrNoRek;
		    	   	//	echo "</br>";
				  	$range = range($row->KuponAwal, $row->KuponAkhir);
		   	  		
		   	  		foreach ($range as $row) {
		 	  	  		array_push($data_range_undian, $row);
		   	  		}
		   	  	}
		   	   }
		   	  else
		   	  {
		   	  	array_push($data_range_undian,'0');
		   	  }

		 	 //get rondom
		 	  while( in_array( ($index_nomorkupon = rand(1,($jumlah_nomorkupon-1))), $data_range_undian ) );
		 	  //echo $index_nomorkupon."---";
		 	  //echo $kode_uker;
		 
		    //$data_pemenang 		 = $this->model_undian->get_nomorrekening_kupon_multidraw($idkanca, $periodeUndian,$kode_bulan,$kode_uker,$index_nomorkupon);
             
	    	$nomor_rek='';
        	$namaPemenang = '';;

		    $data_pemenang 		 = $this->model_undian->get_nomorrekening_kupon_multidraw($idkanca, $periodeUndian,$kode_bulan,$kode_uker,$index_nomorkupon);
             
  		    foreach ($data_pemenang as $row) {
	        	$nomor_rek=$row->NoRek;
	        	$namaPemenang = $row->namaNasabah;
			 }

             // echo "======".$nomor_rek;

			   	  $concat_kupon = '';
			   	  $jumlah_char =  strlen($index_nomorkupon);
			   	  $ulang = 8;
			   	  
			   	  for($i = 0; $i<$ulang-$jumlah_char; $i++)
			   	  {
			   	  	$concat_kupon = $concat_kupon.'0';
			   	  }

			   	  $concat_uker = '';
			   	  $jumlah_chr_uker =  strlen($kode_uker);
			   	  $ulang = 4;
			   	  for($i = 0; $i<$ulang-$jumlah_chr_uker; $i++)
			   	  {
			   	  	$concat_uker = $concat_uker.'0';
			   	  }

			   	  $nomor_undian = $concat_uker.$kode_uker.$kode_bulan.$concat_kupon.$index_nomorkupon;

		
			   	  //echo "kirim =".$kode_uker."/".$nomor_undian;
			   	  //echo "</br>";
			   	  //echo "$nama_uker";
        	   	  //echo "</br>";


        	   	 if($namaPemenang!='')
        	   	 {

		        	   	 if($no%2==0)
						{
							echo "<tr bgcolor='#f9f3e8'>";
			
						}
						else
						{
							echo "<tr>";
						}
							//echo "<tr bgcolor='#f9f3e8'>";
							echo "<td><center>";
							echo $no;
							echo "</center></td>";
							echo "<td>";
							echo $nama_uker;
							echo "</td>";
							echo "<td>";
							echo $nomor_undian;
							echo "</td>";
							echo "<td>";
							echo substr($nomor_rek, 0,12)."XXX";
							echo "</td>";
							$nama_nasabah = $namaPemenang;
							echo "<td>";
							echo $nama_nasabah;
							echo "</td>";

							$insert = array(
							'kodeUker' => $kode_uker,
							'namaUker' => $nama_uker,
							'namahadiah' => $hadiah,
							'chrNoUndian' =>  $nomor_undian,
							'chrNoRek' => $nomor_rek,
							'vcrNmNsbh' => $nama_nasabah,
							'chrJnsHadiah' => $_GET['charhadiah'],
							'chrKdPeriode' => $_GET['periode'],
							'chrUserAdd' => $this->session->userdata('kode_user')
								);

							//insert di temp pemenang
							array_push($totalArrayPemanang,$insert);
						    $this->model_undian->simpan_pemenangTempPemenang($idkanca,$insert);


							echo "</tr>";

		        	   	  $no++;
					   	  
		        	   	  $x++;
		        	   	  $flagbulan = $jumlah_bulan_total +1;
		        	   	  //print_r($insert);
		        	 }
		        	 else
		        	 {
		        	 	array_push($flagbulanrandom, $index_bulan);
		        	 }
	   		   	}

		 	 	$flagbulan = $flagbulan + 1;
		 	 }



	   		   //	print_r($totalArrayPemanang);

	   		   	echo "</table>";

	   		   	$data['totalArrayPemanang']=$totalArrayPemanang;
	   		   	$this->load->view("try", $data);

		}




 	    	  
   }

   //get pengundian hiburan
	public function setperiode_hadiah_hiburan()
	{


		$data['kode_user']=$this->session->userdata('kode_user');
		$data['nama_user'] = $this->session->userdata('nama_user');
		$data['kode_kanca'] = $this->session->userdata('kode_kanca');
		$data['group_area'] = $this->session->userdata('group_area');
		$data['otoritas'] = $this->session->userdata('otoritas');
		$data['kodekanwil'] = $this->session->userdata('kanwil');
		$otoritas = $this->session->userdata('otoritas');

		//$data["sisahiburan"] = $this->model_hadiahKanca->jumlah_hadiahhiburan();
		//$data["sisabiasa"] = $this->model_hadiahKanca->jumlah_hadiahumum();
		//$data["sisautama"] = $this->model_hadiahKanca->jumlah_hadiahutama();
		$data["hadiahPeriode"] = $this->model_msthadiahperiode->data_hadiah_tampilkan();
		$data["periode"] = $this->model_mstperiode->data_mstperiode();
	

		 $data['page'] = 'pengundian/new/v_pilihperiodehiburan';
		 $data['menu'] = 'main_dashboard';
		 $this->load->view("layouts/fixundian", $data);
	}


	public function pengacakan_hadiah_hiburan()
	{
		$countdown 				= $this->model_mstperiodehadiah->selisihwaktuundian($this->session->userdata('kode_kanca'),$_GET['periode']);
	
		if($countdown>=604800)
		{
			redirect("pengundian/setperiode_hadiah_hiburan?st=x&id=".$_GET['periode']);
		}

		$data['kode_user']=$this->session->userdata('kode_user');
		$data['nama_user'] = $this->session->userdata('nama_user');
		$data['kode_kanca'] = $this->session->userdata('kode_kanca');
		$data['group_area'] = $this->session->userdata('group_area');
		$data['otoritas'] = $this->session->userdata('otoritas');
		$data['kodekanwil'] = $this->session->userdata('kanwil');
		$otoritas = $this->session->userdata('otoritas');
		$idkanca = $this->session->userdata('kode_kanca');

		//variable pengunundian
	//	$data["datanokupon"] = $this->model_mstperiodehadiah->get_nomorundian($idkanca);
		//$nomorundian = $this->model_mstperiodehadiah->get_nomorundian($idkanca);
		$arraynomorundian = array();

		$no=0;



	
		//$data["noarray"] = json_encode($arraynomorundian);

		if(isset($_GET['periode']))
		{
			$flag = $this->cekvalidasi_undian_hiburan($_GET['periode']);
			if($flag!=1)
			{
				redirect("pengundian/setperiode_hadiah_hiburan?st=1&id=".$_GET['periode']);
			}

			$tanggal 	= $this->model_mstperiodehadiah->selisihwaktuundian($this->session->userdata('kode_kanca'),$_GET['periode']);
			if($tanggal < 0 )
			{
					redirect("pengundian/setperiode_hadiah_hiburan?st=0&id=".$_GET['periode']);
			}


		$data['maxundian'] = '0';
		$data['rangeperiode']=$_GET['x'];
		$data['idperiode']=$_GET['periode'];
		$data['datajenishadiah'] = $this->model_undian->get_undian_hadiahHiburan($idkanca,$_GET['periode']);
		//$data["sisahiburan"] = $this->model_hadiahKanca->jumlah_hadiahhiburan();
		//$data["sisabiasa"] = $this->model_hadiahKanca->jumlah_hadiahumum();
		//$data["sisautama"] = $this->model_hadiahKanca->jumlah_hadiahutama();
		$data["hadiahPeriode"] = $this->model_msthadiahperiode->data_hadiah_tampilkan();
		$data["periode"] = $this->model_mstperiode->data_mstperiode();
		$data['page'] = 'pengundian/new/v_pengacakanundianhiburan';
		$data['menu'] = 'main_dashboard';
		$this->load->view("layouts/fixundian", $data);
		}
		else{
		redirect("pengundian/setperiode_hadiah_hiburan");}
	}





}
