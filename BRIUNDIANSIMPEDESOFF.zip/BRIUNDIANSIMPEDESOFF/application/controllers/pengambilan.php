<?php

class Pengambilan extends CI_Controller
{
	
	function __construct()
	{
		parent::__construct();
		$this->load->model('model_pengambilan');
		$this->load->model('model_pekerja');
		$this->load->model('model_articles');
	}
	function start(){	
		$data['barang']=$this->model_articles->all_barang();	
		$data['pekerja']=$this->model_pekerja->all_pekerja();	
		$this->load->view('backend/ambil',$data);
	}

	

	function proses_pengambilan(){
		$nama_barang = $this->input->post('nama_barang'); 
		$satuan = $this->model_articles->get_value($nama_barang);
		$data  = array('nama_pengambilan' => $this->input->post('nama_barang') ,
					   'nama_pengambil' => $this->input->post('nama_pengambil') ,
					   'jumlah_pengambilan' => $this->input->post('jumlah_barang') ,
					   'satuan_pengambilan' => $satuan->satuan_barang ,
					   'tanggal_pengambilan' => date ('Y-m-d H:i:s', time()+360*60)						
						 );
		$sisa=$this->model_articles->get_value($nama_barang);
		$jumlah=$this->input->post('jumlah_barang'); 
		$sisanya=($sisa->sisa_barang)-$jumlah;
		$this->model_articles->update_sisa($nama_barang,$sisanya); 
		$this->model_pengambilan->insert($data);
		
		redirect(base_url().'manage/lihat ');
	}

	function sejarah_pengambilan(){
		$data['pengambilan'] =$this->model_pengambilan->all_pengambilan();
		$this->load->view('backend/history',$data);
	}
	function index(){
		$data['barang']=$this->model_articles->all_barang();	
		$data['pekerja']=$this->model_pekerja->all_pekerja();			
		$this->load->view('backend/start',$data);
	}
}
?>