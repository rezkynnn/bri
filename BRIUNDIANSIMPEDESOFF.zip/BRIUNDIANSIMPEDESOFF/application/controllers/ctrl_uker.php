<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class ctrl_uker extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -  
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in 
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see http://codeigniter.com/user_guide/general/urls.html
	 */

	public function __construct()
	{
		parent::__construct();
		$this->load->model('brisimpedes/model_mstuker');
	}

	public function index()
	{
			$data['cari'] = '';
	
		$data['kode_user']=$this->session->userdata('kode_user');
		$data['nama_user'] = $this->session->userdata('nama_user');
		$data['kode_kanca'] = $this->session->userdata('kode_kanca');
		$data['group_area'] = $this->session->userdata('group_area');
		$data['otoritas'] = $this->session->userdata('otoritas');
		$data['kodekanwil'] = $this->session->userdata('kanwil');
		$idkanca= $this->session->userdata('kode_kanca');
		

		 if (isset($_GET['prov']))
		 {

		 	$data['provin'] = $_GET['prov'];
		 	$ok=$this->model_mstuker->data_kab($_GET['prov']); 
		 	$data['dataprovin'] = $ok;
		 }

		 $a= $this->input->post('cari');
		 if ($a!="")
		 {
	 		$data['data'] = $this->model_mstuker->data_unitcari($idkanca,$this->input->post('cari'));
		 	$data['cari'] = $a;
		 }
		 else
		 {
		 	$data['data'] = $this->model_mstuker->data_unit($idkanca);
	
		 }



		$data['page'] = 'view_data_uker';
		$data['menu'] = 'main_dashboard';
		$data['id'] = "";
		//$data['provinsi'] = $this->model_mstuker->data_provinsi();
		//$data['kanwil'] = $this->model_mstuker->data_kanwil();
		$this->load->view("layouts/fix", $data);
	}
	public function datauker()
	{	$data['cari'] = '';
	
		$data['kode_user']=$this->session->userdata('kode_user');
		$data['nama_user'] = $this->session->userdata('nama_user');
		$data['kode_kanca'] = $this->session->userdata('kode_kanca');
		$data['group_area'] = $this->session->userdata('group_area');
		$data['otoritas'] = $this->session->userdata('otoritas');
		$data['kodekanwil'] = $this->session->userdata('kanwil');
		$idkanca= $this->session->userdata('kode_kanca');
		




		$data['page'] = 'view_data_uker';
		$data['menu'] = 'main_dashboard';
		$data['id'] = "";
		$data['provinsi'] = $this->model_mstuker->data_provinsi();
		$data['kanwil'] = $this->model_mstuker->data_kanwil();
		$this->load->view("layouts/fix", $data);
	}

	public function cariuker()
	{
		$data['cari'] = '';
		$data['kode_user']=$this->session->userdata('kode_user');
		$data['nama_user'] = $this->session->userdata('nama_user');
		$data['kode_kanca'] = $this->session->userdata('kode_kanca');
		$data['group_area'] = $this->session->userdata('group_area');
		$data['otoritas'] = $this->session->userdata('otoritas');
		$data['kodekanwil'] = $this->session->userdata('kanwil');
		$idkanca= $this->session->userdata('kode_kanca');
		$a= $this->input->post('cari');
		$data['data'] = $this->model_mstuker->data_unitcari($idkanca,$this->input->post('cari'));
		 if (isset($_GET['prov']))
		 {

		 	$data['provin'] = $_GET['prov'];
		 	$ok=$this->model_mstuker->data_kab($_GET['prov']); 
		 	$data['dataprovin'] = $ok;
		 }

		 if ($a!="")
		 {
		 	$data['cari'] = $a;
		 }


		$data['page'] = 'view_data_uker';
		$data['menu'] = 'main_dashboard';
		$data['id'] = "";
		$data['provinsi'] = $this->model_mstuker->data_provinsi();
		$data['kanwil'] = $this->model_mstuker->data_kanwil();
		$this->load->view("layouts/fix", $data);
	

	}
	function ajax_call() {
		      	echo "<select name ='lamaperiode' onchange='showuker(this.value)''>
              <option value='0'>-Lama Periode-</option>
              <option value='1'>1 Bulan</option>
              <option value='3'>3 Bulan</option>
              <option value='4'>4 Bulan</option>
              <option value='6'>6 Bulan</option>
              <option value='12'>12 Bulan</option>
              </select>";

	}

	public function Kab($id)
	{
	//	$kab= $this->model_mstuker->data_kab($id);
		$kab = "hay";
		return $kab;
	}


	public function tambah_uker()
	{
		$data['kode_user']=$this->session->userdata('kode_user');
		$data['nama_user'] = $this->session->userdata('nama_user');
		$data['kode_kanca'] = $this->session->userdata('kode_kanca');

	$data['aktif'] = "ok";
	if ( isset($_REQUEST["name"]) )
	{
			$activity = $_REQUEST['name'];
			$ok=$this->model_mstuker->data_kab($_REQUEST['name']);
			$data['dataprovin'] = $ok;
			$data['aktif'] = $activity;
	 }


		 if (isset($_GET['prov']))
		 {

		 	$data['provin'] = $_GET['prov'];
		 	$ok=$this->model_mstuker->data_kab($_GET['prov']); 
		 	$data['dataprovin'] = $ok;
		 }

		$idkanca= $this->session->userdata('kode_kanca');
		$data['data'] = $this->model_mstuker->data_unit($idkanca);
		
		$data['page'] = 'data_uker/view_tambahuker';
		$data['menu'] = 'main_dashboard';
		$data['id'] = "";
		$data['provinsi'] = $this->model_mstuker->data_provinsi();
		$data['kanwil'] = $this->model_mstuker->data_kanwil();
		$this->load->view("layouts/fix", $data);
	}

	public function edit_uker()
	{

		$idkanca= $this->session->userdata('kode_kanca');
		$data['data'] = $this->model_mstuker->data_unit($idkanca);
		

		$data['kode_user']=$this->session->userdata('kode_user');
		$data['nama_user'] = $this->session->userdata('nama_user');
		$data['kode_kanca'] = $this->session->userdata('kode_kanca');


		if (isset($_GET['prov']))
		 {

		 	$data['provin'] = $_GET['prov'];
		 	$ok=$this->model_mstuker->data_kab($_GET['prov']); 
		 	$data['dataprovin'] = $ok;
		 }


		$getdataunit = $this->model_mstuker->getdata_frommstunit($_GET['idkode'],$idkanca);
		if (isset($getdataunit)) 
              {
                foreach ($getdataunit as $row) 
                {
                  
                  $data['kodeUker'] = $row->chrKdUnit;
                  $data['namaUker'] = $row->vcrNmUnit;
                  $data['namaUkerleng'] = $row->vcrNmUnit."(".$row->chrKdUnit.")";
                  $data['alamatUker'] = $row->vcrAlmUnit;
                  $data['Provinsi'] = $row->chrPropUnit;
                  $data['Kelurahan'] = "";
                  $data['Kabupaten'] = $row->chrKabUnit;
                  $data['Kecamatan'] = "";
                  $data['kantor_wil'] =$row->chrKdKanwil;
                  $data['kode_pos'] = $row->chrKdPosUnit;
                  $data['no_tlp'] = $row->chrTelpUnit;
                  $data['email'] = $row->chrEmailUnit;
                  $data['chrFaxUnit'] = $row->chrFaxUnit;
                  


                  $data['cabang'] =$this->session->userdata('kode_kanca');
                  $ok=$this->model_mstuker->data_kab($row->chrPropUnit);
                  $data['dataprovin'] = $ok; 
                }
             }
             

		
		$data['page'] = 'data_uker/view_edituker';
		$data['menu'] = 'main_dashboard';
		//$data['data'] = $this->model_mstuker->data_unit();
		//$data['data'] = $this->model_mstuker->data_unit();
		//$data['getdataunit'] = $this->model_mstuker->getdata_unit($_GET['idkode']);
		$data['provinsi'] = $this->model_mstuker->data_provinsi();
		$data['kanwil'] = $this->model_mstuker->data_kanwil();
		$data['id'] =$_GET['idkode'];
		$this->load->view("layouts/fix", $data);
	}

	public function list_user()
	{
		$data['page'] = 'v_list_user';
		$data['menu'] = 'main_dashboard';

		$data['list_a'] = $this->m_pingpong->list_a();
		$data['list_b'] = $this->m_pingpong->list_b();
		$data['list_c'] = $this->m_pingpong->list_c();

		$this->load->view("layouts/fix", $data);
	}

	public function ambil()
	{

			$id = $_REQUEST['name'];
			$this->load->helper('url');
			//echo $id;
			$ok=$this->model_mstuker->getdata_namaunit($id);
			$data['dataprovin'] = $ok; 
			$_POST['key'] = "foo";

			if (isset($ok)) 
            {

                foreach ($ok as $row) 
                {
                 echo $row->vcrNmUnit;
                }     
             }


	//		echo json_encode($data);
	
		
	}
	public function add_member()
	{
		$insert = array(
				'nama_member' => $this->input->post('nama_member'),
				'bagian' => $this->input->post('bagian'),
				'email' => $this->input->post('email'),
				'no_telp' => $this->input->post('no_telp'),
				'group' => $this->input->post('group')
			);
		$this->m_pingpong->add_member($insert);

		redirect('c_pingpong/list_user');
	}

	public function delete_member($id_member)
	{
		$this->m_pingpong->delete_member($id_member);

		redirect('c_pingpong/list_user/');
	}

	public function save_uker()
	{
		$insert = array(
				'chrPropUnit' => $this->input->post('chrPropUnit'),
				
				'chrKdKanwil' => $this->input->post('chrKdKanwil'),
				'chrKdKanca' => $this->input->post('chrKdKanca'),
				'chrKdUnit' => $this->input->post('chrKdUnit'),
				'vcrNmUnit' => $this->input->post('vcrNmUnit'),
				'vcrAlmUnit' => $this->input->post('vcrAlmUnit'),
				'chrKabUnit' => $this->input->post('chrKabUnit'),
				'chrKdPosUnit' => $this->input->post('chrKdPosUnit'),
				'dtmUserAdd' => NOW(),


				'chrFaxUnit' => $this->input->post('chrFaxUnit'),
				'chrEmailUnit' => $this->input->post('chrEmailUnit'),

				'chrUserAdd' => $this->session->userdata('kode_user')
			);

		$kanca=$this->input->post('chrKdKanca');
		$uker = $this->input->post('chrKdUnit');

			$update = array(
				'chrPropUnit' => $this->input->post('chrPropUnit'),
				
				'chrKdKanwil' => $this->input->post('chrKdKanwil'),
				'chrKdKanca' => $this->input->post('chrKdKanca'),
				//'chrKdUnit' => $this->input->post('chrKdUnit'),
				'vcrNmUnit' => $this->input->post('vcrNmUnit'),
				'vcrAlmUnit' => $this->input->post('vcrAlmUnit'),
				'chrKabUnit' => $this->input->post('chrKabUnit'),
				'chrKdPosUnit' => $this->input->post('chrKdPosUnit'),
				'dtmUserAdd' => NOW(),


				'chrFaxUnit' => $this->input->post('chrFaxUnit'),
				'chrEmailUnit' => $this->input->post('chrEmailUnit'),

				'chrUserAdd' => $this->session->userdata('kode_user')
			);
		$this->model_mstuker->add_uker($insert,$update,$kanca,$uker);
		redirect('ctrl_uker/datauker');
	}

	public function update_uker()
	{
		$insert = array(
				'chrPropUnit' => $this->input->post('chrPropUnit'),
				
				'chrKdKanwil' => $this->input->post('chrKdKanwil'),
				'chrKdKanca' => $this->input->post('chrKdKanca'),
				'chrKdUnit' => $this->input->post('chrKdUnit'),
				'vcrNmUnit' => $this->input->post('vcrNmUnit'),
				'vcrAlmUnit' => $this->input->post('vcrAlmUnit'),
				'chrKabUnit' => $this->input->post('chrKabUnit'),
				'chrKdPosUnit' => $this->input->post('chrKdPosUnit'),
				'dtmUserAdd' => NOW(),


				'chrFaxUnit' => $this->input->post('chrFaxUnit'),
				'chrEmailUnit' => $this->input->post('chrEmailUnit'),

				'chrUserAdd' => $this->session->userdata('kode_user')
			);

		$this->model_mstuker->update_uker($this->input->post('chrKdKanca'),$this->input->post('chrKdUnit'),$insert);

		//$this->model_mstuker->update_uker($insert);
		redirect('ctrl_uker/datauker');
	}

	


	public function delete_uker()
	{
		$id_kanca = $this->session->userdata('kode_kanca');
		$this->model_mstuker->delete_uker($id_kanca,$_GET['idkode']);

		redirect('ctrl_uker/datauker');
	}

	
}
