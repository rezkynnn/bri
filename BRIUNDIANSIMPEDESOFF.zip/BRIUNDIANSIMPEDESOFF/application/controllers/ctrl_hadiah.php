<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class ctrl_hadiah extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -  
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in 
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see http://codeigniter.com/user_guide/general/urls.html
	 */

	public function __construct()
	{
		parent::__construct();
		$this->load->model('brisimpedes/model_mstuker');
		$this->load->model('brisimpedes/model_mstuser');
		$this->load->model('brisimpedes/model_mstperiodehadiah');
		$this->load->model('model_mstperiode');
	}

	public function index()
	{
		$data['kode_user']	=$this->session->userdata('kode_user');
		$data['nama_user'] 	= $this->session->userdata('nama_user');
		$data['kode_kanca'] = $this->session->userdata('kode_kanca');
		$idkanca 			= $this->session->userdata('kode_kanca');
		$data['group_area'] = $this->session->userdata('group_area');
		$data['otoritas'] 	= $this->session->userdata('otoritas');
		$data['kodekanwil'] = $this->session->userdata('kanwil');

		$data['data'] 		= $this->model_mstperiodehadiah->data_periodeHadiahkanca($idkanca,$this->session->userdata('kanwil'));
  		$data['kodeperiode']= "";
		$data['tanggal'] 	= "";
		$data['status'] 	= "";

		
		 if (isset($_GET['id']) && $_GET['id']!="0")
		 {		$status = $this->model_mstperiodehadiah->cek_statushadiah($this->session->userdata('kode_kanca'),$_GET['id']);
				$statuschar = "";
				
				if($status=='')
				{	
					$statuschar = "Setelah data lengkap mohon dikirim ke kanwil";		
				}

				else if($status==0)
				{	
					$statuschar = "Menunggu Persetujuan Kantor Wilayah";
				}
				else if($status==1)
				{	
					$statuschar = "Daftar Hadiah ditolak Kantor Wilayah";
				}

				else if($status==2)
				{
					$statuschar = "Menunggu persetujuan Kantor Pusat";	
				}
				else if($status==3)
				{
					$statuschar = "Daftar Hadiah ditolak Kantor Pusat";		
				}
				else if($status==4)
				{	
					$statuschar = "Daftar Hadiah telah disetujui, jika ada perubahan mohon hubungin call center";		
				}
				$data['statushadiah'] = $statuschar;
				$data['status'] = $status;




			 	$data['kodeperiode'] =$_GET['id'];
				$data['data'] = $this->model_mstperiodehadiah->data_periodeHadiahkancaperperiode($idkanca,$this->session->userdata('kanwil'),$_GET['id']);
	  			$data['tanggal'] = $this->model_mstperiodehadiah->getTanggalPelaksanaan($_GET['id'], $this->session->userdata('kode_kanca'));

	 }
		 else
		 {
		 		$data['data'] = $this->model_mstperiodehadiah->data_periodeHadiahkanca($idkanca,$this->session->userdata('kanwil'));
  	 }

	 	$data["periode"] = $this->model_mstperiodehadiah->data_mstperiode();
		$idkanca = '206';
		$data['page'] = 'data_hadiah/view_datahadiah';
		$data['menu'] = 'main_dashboard';
	
	//	$data['kanwil'] = $this->model_mstuker->data_kanwil();
		$this->load->view("layouts/fix", $data);
	}

	public function Kab($id)
	{
		$kab = "hay";
		return $kab;
	}

	public function tambahhadiahKanca()
	{
		$data['kode_user']=$this->session->userdata('kode_user');
		$data['nama_user'] = $this->session->userdata('nama_user');
		$data['kode_kanca'] = $this->session->userdata('kode_kanca');
		$data['group_area'] = $this->session->userdata('group_area');
		$data['otoritas'] = $this->session->userdata('otoritas');
		$data['kodekanwil'] = $this->session->userdata('kanwil');


		$data['gropuarea'] =$this->model_mstuser->data_grouparea();
		$data['kanwil'] = $this->model_mstuker->data_kanwil();
		$data['kanca'] = $this->model_mstuser->data_kanca();
		$data["periode"] = $this->model_mstperiodehadiah->data_mstperiode();

		 if (isset($_GET['id']) and $_GET['id'] !=0 )
		 {
		 	$kodeperiode = $_GET['id'];
 			$data["Jenis_Hadiah"] = $this->model_mstperiodehadiah->get_jeniskosong($kodeperiode);		
		 }



	
	
		$data['page'] = 'data_hadiah/view_tambahhadiah';
		$data['menu'] = 'main_dashboard';
		$this->load->view("layouts/fix", $data);
	}

	public function edithadiahKanca()
	{

		$data['kode_user']=$this->session->userdata('kode_user');
		$data['nama_user'] = $this->session->userdata('nama_user');
		$data['kode_kanca'] = $this->session->userdata('kode_kanca');
		$data['group_area'] = $this->session->userdata('group_area');
		$data['otoritas'] = $this->session->userdata('otoritas');
		$data['kodekanwil'] = $this->session->userdata('kanwil');




	if (isset($_GET['hadiah']))
		 {

		 	$ok=$this->model_mstperiodehadiah->get_periodeHadiah($_GET['hadiah'],$this->session->userdata('kode_kanca'),$this->session->userdata('kanwil'));
		 	$data['datahadiah'] = $ok;
		 }
		 
		$data['gropuarea'] =$this->model_mstuser->data_grouparea();
		$data['kanca'] = $this->model_mstuser->data_kanca();
		$data['kanwil'] = $this->model_mstuker->data_kanwil();
		$data['kanca'] = $this->model_mstuser->data_kanca();
		$data["periode"] = $this->model_mstperiodehadiah->data_mstperiode();
		$data["Jenis_Hadiah"] = $this->model_mstperiodehadiah->data_JenisHadiah();



		$data['page'] = 'data_hadiah/view_edithadiah';
		$data['menu'] = 'main_dashboard';
		$this->load->view("layouts/fix", $data);
	}

	public function list_user()
	{
		$data['page'] = 'v_list_user';
		$data['menu'] = 'main_dashboard';

		$data['list_a'] = $this->m_pingpong->list_a();
		$data['list_b'] = $this->m_pingpong->list_b();
		$data['list_c'] = $this->m_pingpong->list_c();

		$this->load->view("layouts/fix", $data);
	}

	public function add_member()
	{
		$insert = array(
				'nama_member' => $this->input->post('nama_member'),
				'bagian' => $this->input->post('bagian'),
				'email' => $this->input->post('email'),
				'no_telp' => $this->input->post('no_telp'),
				'group' => $this->input->post('group')
			);
		$this->m_pingpong->add_member($insert);

		redirect('c_pingpong/list_user');
	}

	public function delete_member($id_member)
	{
		$this->m_pingpong->delete_member($id_member);

		redirect('c_pingpong/list_user/');
	}

	public function add_hadiah()
	{
		$idkanca = $this->session->userdata('kode_kanca');

		
		$insert = array(
				'chrKdPeriode' => $this->input->post('periode'),
				'chrKdKanwil' => $this->input->post('bagian'),
				'chrKdKanca' => $this->input->post('kantorcabang'),
				'chrJnsHadiah' => $this->input->post('kategori_hadiah'),
				'vcrNamaHadiah' => $this->input->post('type_hadiah'),
				'intJmlhadiah' => $this->input->post('jumlah_hadiah'),
				'chrUserAdd' => $this->input->post('email'),
				'varJenisHadiah' => $this->input->post('jenis_hadiah'),
				'varTypeHadiah' => $this->input->post('type_hadiah'),
				'varMerkHadiah' => $this->input->post('merk_hadiah'),
				'hargaSatuan' => $this->input->post('Harga_satuan'),
				'tahunPembuatan' => $this->input->post('tahun_pembuatan'),
				'varKondisiPembuatan' => $this->input->post('kondisi_hadiah'),
				'statusHadiah' => $this->session->userdata('otoritas'),
				'chrUserAdd' => $this->session->userdata('kode_user'),
				'chrKdKanca' => $this->session->userdata('kode_kanca'),
				'chrKdKanwil' => $this->session->userdata('kanwil'),
				'potonganHarga'=> $this->input->post('PotHarga')
				
			
			);
		//echo $this->input->post('PotHarga');
		$this->model_mstperiodehadiah->add_hadiah($idkanca,$insert,$this->input->post('periode'),$this->input->post('kantorcabang'),$this->session->userdata('kanwil'),$this->input->post('jenis_hadiah'));
		redirect('ctrl_hadiah?id='.$_GET['id']);

	
	}
	public function update_hadiah()
	{
		$idkanca = $this->session->userdata('kode_kanca');

		
		$insert = array(
				//'chrKdPeriode' => $this->input->post('periode'),
				//'chrKdKanwil' => $this->input->post('bagian'),
				//'chrKdKanca' => $this->input->post('kantorcabang'),
				//'chrJnsHadiah' => $this->input->post('kategori_hadiah'),
				'vcrNamaHadiah' => $this->input->post('type_hadiah'),
				'intJmlhadiah' => $this->input->post('jumlah_hadiah'),
				'chrUserAdd' => $this->input->post('email'),
				'varJenisHadiah' => $this->input->post('jenis_hadiah'),
				'varTypeHadiah' => $this->input->post('type_hadiah'),
				'varMerkHadiah' => $this->input->post('merk_hadiah'),
				'hargaSatuan' => $this->input->post('Harga_satuan'),
				'tahunPembuatan' => $this->input->post('tahun_pembuatan'),
				'varKondisiPembuatan' => $this->input->post('kondisi_hadiah'),
				'statusHadiah' => $this->session->userdata('otoritas'),
				'chrUserAdd' => $this->session->userdata('kode_user'),
				'chrKdKanca' => $this->session->userdata('kode_kanca'),
				'chrKdKanwil' => $this->session->userdata('kanwil'),
				'potonganHarga'=> $this->input->post('PotHarga')
				
			
			);
		//echo $this->input->post('PotHarga');
		$this->model_mstperiodehadiah->update_hadiah($idkanca,$insert,$_GET['id'],$this->input->post('kantorcabang'),$this->session->userdata('kanwil'),$this->input->post('kategori_hadiah'));
		redirect('ctrl_hadiah?id='.$_GET['id']);



	}

	public function delete_hadiah()
	{
		$this->model_mstperiodehadiah->delete_hadiah($this->session->userdata('kode_kanca'),$_GET['idperiode'],$_GET['idjenis']);
		redirect('ctrl_hadiah');
	}


	public function apppusat()
	{
		$data['kode_user']=$this->session->userdata('kode_user');
		$data['nama_user'] = $this->session->userdata('nama_user');
		$data['kode_kanca'] = $this->session->userdata('kode_kanca');
		$data['group_area'] = $this->session->userdata('group_area');
		$data['otoritas'] = $this->session->userdata('otoritas');
		$data['kodekanwil'] = $this->session->userdata('kanwil');
		$periode="";
		 if (isset($_GET['id']) && $_GET['id']!="0")
		 {
				$data['data'] = $this->model_mstperiodehadiah->get_kancaUndianAllkanpuspermohonan($_GET['id']);
	 	 		$data['dataTerima'] = $this->model_mstperiodehadiah->get_kancaUndianAllkanpusterima($_GET['id']);
	 	 		$data['dataTolak'] = $this->model_mstperiodehadiah->get_kancaUndianAllkanpustolak($_GET['id']);
		
		 	 	//	$data['data'] = $this->model_mstperiodehadiah->get_kancaUndianAll($periode);
		

		// 	$data['provin'] = $_GET['prov'];
		 //	$ok=$this->model_mstuker->data_kab($_GET['prov']); 
		 	//$data['dataprovin'] = $ok;
		 }
		 else
		 {
		 		$data['data'] = $this->model_mstperiodehadiah->get_kancaUndianAllkanpuspermohonan($periode);
	 	 		$data['dataTerima'] = $this->model_mstperiodehadiah->get_kancaUndianAllkanpusterima($periode);
	 	 		$data['dataTolak'] = $this->model_mstperiodehadiah->get_kancaUndianAllkanpustolak($periode);
		
		 }
	 	$data["periode"] = $this->model_mstperiodehadiah->data_mstperiode();
		$idkanca = '206';
		$data['page'] = 'data_approval/view_datahadiahkanpus';
		$data['menu'] = 'main_dashboard';
	
	//	$data['id'] = "";
	//	$data['provinsi'] = $this->model_mstuker->data_provinsi();
		$data['kanwil'] = $this->model_mstuker->data_kanwil();
		$this->load->view("layouts/fix", $data);
	}


	public function appkanwil()
	{
		$data['kode_user']=$this->session->userdata('kode_user');
		$data['nama_user'] = $this->session->userdata('nama_user');
		$data['kode_kanca'] = $this->session->userdata('kode_kanca');
		$data['group_area'] = $this->session->userdata('group_area');
		$data['otoritas'] = $this->session->userdata('otoritas');
		$data['kodekanwil'] = $this->session->userdata('kanwil');
		$id_kanwil =$this->session->userdata('kanwil');
		$periode="";

		 if (isset($_GET['id']) && $_GET['id']!="0")
		 {
	 			$periode =$_GET['id'];
		 		$data['dataTerima'] = $this->model_mstperiodehadiah->get_kancaUndianAllkanwilterima($periode,$id_kanwil);
	 	 		$data['dataTolak'] = $this->model_mstperiodehadiah->get_kancaUndianAllkanwiltolak($periode,$id_kanwil);
	 	 		$data['data'] = $this->model_mstperiodehadiah->get_kancaUndianAllkanwilpermohonan($periode,$id_kanwil);
				$data['dataTolakkanpus'] = $this->model_mstperiodehadiah->get_kancaUndianAllkanpustolak($periode);

		 }
		 else
		 {
				$data['dataTerima'] = $this->model_mstperiodehadiah->get_kancaUndianAllkanwilterima($periode,$id_kanwil);
	 	 		$data['dataTolak'] = $this->model_mstperiodehadiah->get_kancaUndianAllkanwiltolak($periode,$id_kanwil);
	 	 		$data['data'] = $this->model_mstperiodehadiah->get_kancaUndianAllkanwilpermohonan($periode,$id_kanwil);
				$data['dataTolakkanpus'] = $this->model_mstperiodehadiah->get_kancaUndianAllkanpustolak($periode);
		
		 }
	 	$data["periode"] = $this->model_mstperiodehadiah->data_mstperiode();
		$idkanca = '206';
		$data['page'] = 'data_approval/view_datahadiahkanwil';
		$data['menu'] = 'main_dashboard';
	
	//	$data['id'] = "";
	//	$data['provinsi'] = $this->model_mstuker->data_provinsi();
		$data['kanwil'] = $this->model_mstuker->data_kanwil();
		$this->load->view("layouts/fix", $data);
	}



	public function detail_kanca()
	{
		$data['kode_user']=$this->session->userdata('kode_user');
		$data['nama_user'] = $this->session->userdata('nama_user');
		$data['kode_kanca'] = $this->session->userdata('kode_kanca');
		$data['group_area'] = $this->session->userdata('group_area');
		$data['otoritas'] = $this->session->userdata('otoritas');
		$data['kodekanwil'] = $this->session->userdata('kanwil');

		 if (isset($_POST['id_kanca']))
		 {
		 	 	$data['idkanca']=$_POST['id_kanca'];
		 	   	$data['id_kanwil'] =$_POST['id_kanwil'];
		 	   	$data['namakanca'] =$_POST['nama_kanca'];
  				$status = $this->model_mstperiodehadiah->cek_keteranganhadiah($_POST['id_kanca']);
  				$data['keterangan'] = $status;

  				if($this->session->userdata('otoritas')==5)
  				{
				//	$data['data'] = $this->model_mstperiodehadiah->data_periodeHadiahkancaPusat(($_GET['idkanca']),$this->session->userdata('kanwil'));
  				 }
  				else
  				{
  					$data['data'] = $this->model_mstperiodehadiah->data_periodeHadiahkancadetail(($_GET['idkanca']),$this->session->userdata('kanwil'),$_GET['id']);
  				}
		
		 }
		 else
		 {
				if($this->session->userdata('otoritas')==5)
  				{
				//	$data['data'] = $this->model_mstperiodehadiah->data_periodeHadiahkancaPusat(($_GET['idkanca']),$this->session->userdata('kanwil'));
  				 }
  				else
  				{
  					$data['data'] = $this->model_mstperiodehadiah->data_periodeHadiahkancadetail(($_GET['idkanca']),$this->session->userdata('kanwil'),$_GET['id']);
  				}
		
		 	   	$data['idkanca']=$_GET['idkanca'];
		 	   	$data['namakanca'] =$_GET['namakanca'];
		 		//$data['data'] = $this->model_mstperiodehadiah->data_periodeHadiahkanca($_GET['idkanca'],$this->session->userdata('kanwil'));
		 		$status = $this->model_mstperiodehadiah->cek_keteranganhadiah($_GET['idkanca']);
  				$data['keterangan'] = $status;
		 }
	 	$data["periode"] = $this->model_mstperiodehadiah->data_mstperiode();
		$idkanca = '206';
		$data['page'] = 'data_approval/view_hadiahdetailkanca';
		$data['menu'] = 'main_dashboard';
	
		$data['kanwil'] = $this->model_mstuker->data_kanwil();
		$this->load->view("layouts/fix", $data);
	}

	public function detail_kanca1()
	{
		$data['kode_user']=$this->session->userdata('kode_user');
		$data['nama_user'] = $this->session->userdata('nama_user');
		$data['kode_kanca'] = $this->session->userdata('kode_kanca');
		$data['group_area'] = $this->session->userdata('group_area');
		$data['otoritas'] = $this->session->userdata('otoritas');
		$data['kodekanwil'] = $this->session->userdata('kanwil');
		
		 if (isset($_POST['id_kanca']))
		 {
		 	 	$data['idkanca']=$_POST['id_kanca'];
		 	   	$data['id_kanwil'] =$_POST['id_kanwil'];
		 	   	$data['namakanca'] =$_POST['nama_kanca'];
  				$data['data'] = $this->model_mstperiodehadiah->data_periodeHadiahkanca(($_POST['id_kanca']),$this->session->userdata('kanwil'));
  				$status = $this->model_mstperiodehadiah->cek_keteranganhadiah($_POST['id_kanca']);
  				$data['keterangan'] = $status;

  				if($this->session->userdata('otoritas')==5)
  				{
					$data['data'] = $this->model_mstperiodehadiah->data_periodeHadiahkancaPusatdetail(($_GET['idkanca']),$this->session->userdata('kanwil'),$_GET['id']);
  				}
  				else
  				{
  					$data['data'] = $this->model_mstperiodehadiah->data_periodeHadiahkanca(($_GET['idkanca']),$this->session->userdata('kanwil'),$_GET['id']);
  				}
		
  				//$data

		 }
		 else
		 {
		 		if($this->session->userdata('otoritas')==5)
  				{
					$data['data'] = $this->model_mstperiodehadiah->data_periodeHadiahkancaPusatdetail(($_GET['idkanca']),$this->session->userdata('kanwil'),$_GET['id']);
  				 }
  				else
  				{
  					$data['data'] = $this->model_mstperiodehadiah->data_periodeHadiahkancaPusatdetail(($_GET['idkanca']),$this->session->userdata('kanwil'),$_GET['id']);
  				}

		 	   	$data['idkanca']=$_GET['idkanca'];
		 	   	$data['namakanca'] =$_GET['namakanca'];
		 		//$data['data'] = $this->model_mstperiodehadiah->data_periodeHadiahkanca($_GET['idkanca'],$this->session->userdata('kanwil'));
		  		$data['dataterima'] = $this->model_mstperiodehadiah->data_periodeHadiahkanca($_GET['idkanca'],$this->session->userdata('kanwil'));
		  		$data['datatolak'] = $this->model_mstperiodehadiah->data_periodeHadiahkanca($_GET['idkanca'],$this->session->userdata('kanwil'));
				$status = $this->model_mstperiodehadiah->cek_keteranganhadiah($_GET['idkanca']);
  				$data['keterangan'] = $status;
		
  			
		 }
	 	$data["periode"] = $this->model_mstperiodehadiah->data_mstperiode();
		$data['page'] = 'data_approval/view_hadiahdetailkanca1';
		$data['menu'] = 'main_dashboard';
	
		$data['kanwil'] = $this->model_mstuker->data_kanwil();
		$this->load->view("layouts/fix", $data);
	}

	public function update_kanwil()
	{
		$insert = array(
				'statusHadiah' => 2,
				'KeteranganHadiah' => "-diterima kanwil-"
			);
		
		$this->model_mstperiodehadiah->update_kanwil($this->input->post('id_kanca'),$this->input->post('id_kanwil'),$insert);
			
		redirect('ctrl_hadiah/appkanwil?id=0');
	}

	public function update_kanwilTolak()
	{
		$insert = array(
				'statusHadiah' => 1,
				'KeteranganHadiah' => $this->input->post('vcrketerangan')
				);
		
		$this->model_mstperiodehadiah->update_kanwil($this->input->post('id_kanca'),$this->input->post('id_kanwil'),$insert);
		redirect('ctrl_hadiah/appkanwil?id=0');


	}

	public function update_kanpus()
	{
		$insert = array(
				'statusHadiah' => 4,
				'KeteranganHadiah' =>"-diterima kanpus-"
			);
			$this->model_mstperiodehadiah->update_kanpus($this->input->post('id_kanca'),$this->input->post('id_kanwil'),$insert);
		redirect('ctrl_hadiah/apppusat?id=0');
	}

	public function update_kanpusTolak()
	{
		$insert = array(
				'statusHadiah' => 3,
				'KeteranganHadiah' => $this->input->post('vcrketerangan')
				);
		
		$this->model_mstperiodehadiah->update_kanpus($this->input->post('id_kanca'),$this->input->post('id_kanwil'),$insert);
		redirect('ctrl_hadiah/apppusat?id=0');

	}

	public function update_kirimulangkanca()
	{
		$insert = array(
				'statusHadiah' => 0,
				'KeteranganHadiah' => 'permohonan baru'
				);
		
		$this->model_mstperiodehadiah->update_kirimulangkanca($this->session->userdata('kode_kanca'),$this->session->userdata('kanwil'),$insert);
	redirect('ctrl_hadiah?id='.$_GET['periodehadiah']);
	}

	public function simpan_kirimulangkanca()
	{
		$insert = array(
				'statusHadiah' => 0
				//'KeteranganHadiah' => $this->input->post('vcrketerangan')
				);

		$data['kode_user']=$this->session->userdata('kode_user');
		$data['nama_user'] = $this->session->userdata('nama_user');
		$data['kode_kanca'] = $this->session->userdata('kode_kanca');
		$data['group_area'] = $this->session->userdata('group_area');
		$data['otoritas'] = $this->session->userdata('otoritas');
		$data['kodekanwil'] = $this->session->userdata('kanwil');




		$periodeH =$_GET['periodehadiah'];
		$baru = array(
				'statusHadiah' => 0,	
				'chrKdPeriode'=>$_GET['periodehadiah'],
				'chrKdKanwil'=>$this->session->userdata('kanwil'),
				'chrKdKanca'=>$this->session->userdata('kode_kanca'),
				'iduser'=>$this->session->userdata('kode_user'),
				//'datemodif'=>date('Y-m-d H:i:s'),
				'dtmTglPelaksanaan' => $_GET['dtmpelaksana']
				//'KeteranganHadiah' => $this->input->post('vcrketerangan')
				);
		
		$cek=$this->model_mstperiodehadiah->cekexisting($periodeH, $this->session->userdata('kode_kanca'));

		if($cek==1)
		{
			$this->model_mstperiodehadiah->update_kirimulangkanca($this->session->userdata('kode_kanca'),$this->session->userdata('kanwil'),$insert);
		}
		else if ($cek==0)
		{
			$this->model_mstperiodehadiah->simpan_statuskanca($this->session->userdata('kode_kanca'),$this->session->userdata('kanwil'),$baru);
		}

		$a= $_GET['dtmpelaksana'];

		//echo $a."-hay-".$periodeH;
		
		redirect('ctrl_hadiah?id='.$_GET['periodehadiah']);

	}

	public function datauker()
	{
		$data['kode_user']=$this->session->userdata('kode_user');
		$data['nama_user'] = $this->session->userdata('nama_user');
		$data['kode_kanca'] = $this->session->userdata('kode_kanca');
		$data['group_area'] = $this->session->userdata('group_area');
		$data['otoritas'] = $this->session->userdata('otoritas');
		$data['kodekanwil'] = $this->session->userdata('kanwil');
		$idkanca= $this->session->userdata('kode_kanca');
		
		$data['page'] = 'data_approval/view_ukerkanca';
		$data['menu'] = 'main_dashboard';
		$data['data'] = $this->model_mstuker->data_unit($_GET['kode']);
		$data['id'] = "";
		$data['provinsi'] = $this->model_mstuker->data_provinsi();
		$data['kanwil'] = $this->model_mstuker->data_kanwil();
		$this->load->view("layouts/fix", $data);
	}

	
	

	
}