<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class kuponkanca extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -  
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in 
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see http://codeigniter.com/user_guide/general/urls.html
	 */

	public function __construct()
	{
		    parent::__construct();
			$this->load->model('brisimpedes/model_mstuser');
			$this->load->model('brisimpedes/model_mstperiodehadiah');
			$this->load->model('brisimpedes/model_kupon');
			

			

	}

	public function index()
	{

		$data['cari'] = '';
		$data['pilihperiode'] = '0';
		$data["periode"] = $this->model_mstperiodehadiah->data_mstperiode();	
		$data["bulan"] = $this->model_mstperiodehadiah->data_bulan();	
		

		$data['datanokupon'] = ""; 
		$data['kode_user']=$this->session->userdata('kode_user');
		$data['nama_user'] = $this->session->userdata('nama_user');
		$data['kode_kanca'] = $this->session->userdata('kode_kanca');
		$data['group_area'] = $this->session->userdata('group_area');
		$data['otoritas'] = $this->session->userdata('otoritas');
		$data['kodekanwil'] = $this->session->userdata('kanwil');
		$idkanca= $this->session->userdata('kode_kanca');
		
		$data['page'] = 'data_lihatkupon/view_lihatkuponkanca';
		$data['menu'] = 'main_dashboard';
	//	$data['kode_user']=$param['kode_user'];
		
		$this->load->view("layouts/fix", $data);	
	}

	public function cari()
	{
		//inputan 
		

	
		$idkanca= $this->session->userdata('kode_kanca');
		//$noRek = $this->input->post("nomorrekening");
		$periode = $this->input->post("periodehadiah");
		$data['pilihperiode'] = $periode;
		$bulan = $this->input->post("bulan");
		$data['pilihbulan'] = $bulan;


		//get data rekening
		$datakupon= $this->model_kupon->data_cariKuponkanca($idkanca,$periode);
		$data['datarekening'] = $datakupon;

		
		//prasing data
		//$data["periode"] = $this->model_kupon->data_cariKupon($idkanca,$this->input->post("nomorrekening"),$this->input->post("periodehadiah"));
		$data["periode"] = $this->model_mstperiodehadiah->data_mstperiode();	
		$data['page'] = 'data_lihatkupon/view_lihatkuponkanca';
		$data['menu'] = 'main_dashboard';
		$data['kode_user']=$this->session->userdata('kode_user');
		$data['nama_user'] = $this->session->userdata('nama_user');
		$data['kode_kanca'] = $this->session->userdata('kode_kanca');
		$data['group_area'] = $this->session->userdata('group_area');
		$data['otoritas'] = $this->session->userdata('otoritas');
		$data['kodekanwil'] = $this->session->userdata('kanwil');
	




	

		
		$this->load->view("layouts/fix", $data);

	}

	public function carikuponunit()
	{
		$data["bulan"] = $this->model_mstperiodehadiah->data_bulan();	

		$data['cari'] = $_GET['id'];

		 $data['tanngalMulai'] = "";
		 $data['tanngalSelesai'] ="";
  		$idkanca= $this->session->userdata('kode_kanca');


		if(isset($_GET['id']) && $_GET['id']!=0)
		{	//get tanggal
				$periodeRange = $this->model_mstperiodehadiah->data_periode_kanca($idkanca,$_GET['id']);
				$periodetamp = explode("=",$periodeRange);
				for($i=0 ; $i<2; $i++)
				{
					 $tanggalLengkap = explode("-",$periodetamp[$i]);
					 $tahun = $tanggalLengkap[0];
					 $tanggal = $tanggalLengkap[2];
					 $bulan = $tanggalLengkap[1];
					 if($bulan == '01'){$bulan = "Januari";}
					 else if($bulan == '02'){$bulan = "Februari";}
					 else if($bulan == '03'){$bulan = "Maret";}
					 else if($bulan == '04'){$bulan = "April";}
					 else if($bulan == '05'){$bulan = "Mei";}
					 else if($bulan == '06'){$bulan = "Juni";}
					 else if($bulan == '07'){$bulan = "Juli";}
					 else if($bulan == '08'){$bulan = "Agustus";}
					 else if($bulan == '09'){$bulan = "September";}
					 else if($bulan == '10'){$bulan = "Oktober";}
					 else if($bulan == '11'){$bulan = "November";}
					 else if($bulan == '12'){$bulan = "Desember";}

					 if($i==0){$data['tanngalMulai'] = $tanggal." ".$bulan." ".$tahun." s/d ";}
					 if($i==1){$data['tanngalSelesai'] = $tanggal." ".$bulan." ".$tahun;}
					  

				}




			//$noRek = $this->input->post("nomorrekening");
			$periode = $_GET['id'];
			$data['pilihperiode'] = $periode;
			//get data rekening
			$datakupon= $this->model_kupon->data_cariKuponkanca($idkanca,$periode,$_GET['bulan']);
			$data['datarekening'] = $datakupon;
			//prasing data
			//$data["periode"] = $this->model_kupon->data_cariKupon($idkanca,$this->input->post("nomorrekening"),$this->input->post("periodehadiah"));

		}

			$data["periode"] = $this->model_mstperiodehadiah->data_mstperiode();
			$data['page'] = 'data_lihatkupon/view_lihatkuponkanca';
			$data['menu'] = 'main_dashboard';
			$data['kode_user']=$this->session->userdata('kode_user');
			$data['nama_user'] = $this->session->userdata('nama_user');
			$data['kode_kanca'] = $this->session->userdata('kode_kanca');
			$data['group_area'] = $this->session->userdata('group_area');
			$data['otoritas'] = $this->session->userdata('otoritas');
			$data['kodekanwil'] = $this->session->userdata('kanwil');		
			$this->load->view("layouts/fix", $data);



		
	}


	public function cetak()
	{

		$idkanca= 'pengundianoffline';
		$noRek = $_GET['pd'];
		$periode = $_GET['id'];
		$data['datanokupon'] = $noRek;
		$data['pilihperiode'] = $periode;

		//get data rekening
		$datarekeningCari= $this->model_kupon->data_cariKupon($idkanca,$_GET['id'],$_GET['pd']);
		$data['datarekening'] = $datarekeningCari;

		
		//prasing data
		//$data["periode"] = $this->model_kupon->data_cariKupon($idkanca,$this->input->post("nomorrekening"),$this->input->post("periodehadiah"));
		$data["periode"] = $this->model_mstperiodehadiah->data_mstperiode();	
		$data['page'] = 'data_lihatkupon/cetak';
		$data['menu'] = 'main_dashboard';
		$data['kode_user']=$this->session->userdata('kode_user');
		$data['nama_user'] = $this->session->userdata('nama_user');
		$data['kode_kanca'] = $this->session->userdata('kode_kanca');
		$data['group_area'] = $this->session->userdata('group_area');
		$data['otoritas'] = $this->session->userdata('otoritas');
		$data['kodekanwil'] = $this->session->userdata('kanwil');

		
		$this->load->view("layouts/fixundian", $data);



	
	}



}
