<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class ctrl_kupon extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -  
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in 
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see http://codeigniter.com/user_guide/general/urls.html
	 */

	public function __construct()
	{
		    parent::__construct();
			$this->load->model('brisimpedes/model_mstuser');
			$this->load->model('brisimpedes/model_mstperiodehadiah');
			$this->load->model('brisimpedes/model_kupon');
			

			

	}

	public function index()
	{

		$data['pilihperiode'] = '0';
		$data["periode"] = $this->model_mstperiodehadiah->data_mstperiode();	
		$data['datanokupon'] = ""; 
		$data['kode_user']=$this->session->userdata('kode_user');
		$data['nama_user'] = $this->session->userdata('nama_user');
		$data['kode_kanca'] = $this->session->userdata('kode_kanca');
		$data['group_area'] = $this->session->userdata('group_area');
		$data['otoritas'] = $this->session->userdata('otoritas');
		$data['kodekanwil'] = $this->session->userdata('kanwil');
		$idkanca= 'pengundianoffline';
		
		$data['page'] = 'data_lihatkupon/view_lihatkupon';
		$data['menu'] = 'main_dashboard';
	//	$data['kode_user']=$param['kode_user'];
		
		$this->load->view("layouts/fix", $data);	
	}

	public function cari()
	{
		//inputan 
		$idkanca= 'pengundianoffline';;
		$noRek = $this->input->post("nomorrekening");
		$periode = $this->input->post("periodehadiah");
		$data['datanokupon'] = $noRek;
		$data['pilihperiode'] = $periode;

		//get data rekening
		$datarekeningCari= $this->model_kupon->data_cariKupon($idkanca,$noRek,$periode);
		$data['datarekening'] = $datarekeningCari;

		
		//prasing data
		//$data["periode"] = $this->model_kupon->data_cariKupon($idkanca,$this->input->post("nomorrekening"),$this->input->post("periodehadiah"));
		$data["periode"] = $this->model_mstperiodehadiah->data_mstperiode();
		$data["periode"] = $this->model_mstperiodehadiah->data_mstperiode();	
		$data['page'] = 'data_lihatkupon/view_lihatkupon';
		$data['menu'] = 'main_dashboard';
		$data['kode_user']=$this->session->userdata('kode_user');
		$data['nama_user'] = $this->session->userdata('nama_user');
		$data['kode_kanca'] = $this->session->userdata('kode_kanca');
		$data['group_area'] = $this->session->userdata('group_area');
		$data['otoritas'] = $this->session->userdata('otoritas');
		$data['kodekanwil'] = $this->session->userdata('kanwil');
		$this->load->view("layouts/fix", $data);

	}


	public function total()
	{
		ini_set('max_execution_time', 0);
			
		$this->load->model('brisimpedes/model_undian');
		$offset=0;
	 	     
		$this->load->library('pagination');

		$data['pilihperiode'] = '0';
		$data["periode"] = $this->model_mstperiodehadiah->data_mstperiode();	
		$data['datanokupon'] = ""; 
		$data['kode_user']=$this->session->userdata('kode_user');
		$data['nama_user'] = $this->session->userdata('nama_user');
		$data['kode_kanca'] = $this->session->userdata('kode_kanca');
		$data['group_area'] = $this->session->userdata('group_area');
		$data['otoritas'] = $this->session->userdata('otoritas');
		$data['kodekanwil'] = $this->session->userdata('kanwil');
		$idkanca= $this->session->userdata('kode_kanca');

		if(isset($_GET['id']))
		{

				$data['jumlah_data']  = $this->model_kupon->data_show_all_Kupon_jumlah($idkanca,$_GET['id']);
				$data['jumlah_kupon'] 	=$this->model_undian->get_maxundiandaridtlnomorundianPeriode($idkanca,$_GET['id']);

				$config['base_url'] 		= base_url()."ctrl_kupon/total?id=".$_GET['id'];
				$config['page_query_string'] = TRUE;
	
				$config['uri_segment'] 		= 2;
				$config['per_page']         = 50;
				$config['cur_tag_open'] 	= '&nbsp;<a class="current">';
				$config['cur_tag_close'] 	= '</a>';
				$config['next_link'] 		= 'Next';
				$config['prev_link'] 		= 'Previous';
				$config['num_links'] 		= 5;
				$config['use_page_numbers'] = TRUE;
			
				///////////////////bootsrp
				$config['full_tag_open'] 	= "<ul class='pagination'>";
				$config['full_tag_close'] 	="</ul>";
				$config['num_tag_open'] 	= '<li>';
				$config['num_tag_close'] 	= '</li>';
				$config['cur_tag_open'] 	= "<li class='disabled'><li class='active'><a href='#'>";
				$config['cur_tag_close'] 	= "<span class='sr-only'></span></a></li>";
				$config['next_tag_open'] 	= "<li>";
				$config['next_tagl_close'] 	= "</li>";
				$config['prev_tag_open'] 	= "<li>";
				$config['prev_tagl_close'] 	= "</li>";
				$config['first_tag_open'] 	= "<li>";
				$config['first_tagl_close'] = "</li>";
				$config['last_tag_open'] 	= "<li>";
				$config['last_tagl_close'] 	= "</li>";

				if(isset($_GET['per_page'])) {
				$offset = $_GET['per_page'];
				if($offset=='')
					 {
					 	$offset = 0;
					 }

				} else {
					$offset = 0;
				}
 			 	$akhir=50;

 			 	$data['no'] = $offset;

				$datarekening_show= $this->model_kupon->data_show_all_Kupon_pag($idkanca,$_GET['id'],$offset,$akhir);
				
				$data['datarekening'] = $datarekening_show;

				$config['total_rows'] = $data['jumlah_data'];
		 		$this -> pagination -> initialize($config);

		
		}
		
		$data['page'] = 'data_lihatkupon/view_total_kupon';
		$data['menu'] = 'main_dashboard';
	//	$data['kode_user']=$param['kode_user'];
		
		$this->load->view("layouts/fix", $data);	
	}


}
