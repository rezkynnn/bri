<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class unduhnoundian extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -  
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in 
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see http://codeigniter.com/user_guide/general/urls.html
	 */

	public function __construct()
	{
		parent::__construct();
		$this->load->model('m_pingpong');
		$this->load->model('data_kupon');
		$this->load->model('model_tmpdaftarpemenang');
  		$this->load->model('model_daftarpemenang');
		//$this->load->model('model_hadiahKanca');
		$this->load->model('model_msthadiahperiode');
		$this->load->model ('model_mstperiode');
		$this->load->model('brisimpedes/model_mstperiodehadiah');
		$this->load->model('brisimpedes/model_undian');
	}

	public function index()
	{
		$data['kode_user']=$this->session->userdata('kode_user');
		$data['nama_user'] = $this->session->userdata('nama_user');
		$data['kode_kanca'] = $this->session->userdata('kode_kanca');
		$data['group_area'] = $this->session->userdata('group_area');
		$data['otoritas'] = $this->session->userdata('otoritas');
		$data['kodekanwil'] = $this->session->userdata('kanwil');
		$id_kanca = $this->session->userdata('kode_kanca');
		$id_kanwil = $this->session->userdata('kanwil');
		$data['jumlahMaxKupon'] = 0;
		$data['jumlahmax'] = 0;
		$data['jumlah_masuk'] =0;
		$data["periode"] = $this->model_mstperiode->data_mstperiode();
		$data["percent"] = 0;
			
				
		if(isset($_GET['id']) && $_GET['id']!=0)
		{
			$periode =$_GET['id'];
			$data['jumlahMaxKupon']= $this->model_undian->get_maxundiandaridtlnomorundianPeriode($id_kanca,$periode);
			$cekTable =$this->model_undian->cektable_existornot($id_kanca,$periode);
			$data["cekTable"] =$cekTable;
			if($cekTable==1)
			{
	
				$data['jumlahmax'] = $this->model_undian->get_nilaimaxKuponPeriode($id_kanca,$periode);
				$data['jumlah_masuk'] = $this->model_undian->get_nilaimaxKuponMasuk($id_kanca,$periode);
			//	echo $cekTable;
			}
			else
			{
					$data['jumlahMaxKupon'] = 0;
					$data['jumlahmax'] = 0;
					$data['jumlah_masuk'] =0;
	
			}
		
		}

		$data['page'] = 'pengundian/downloadundian';
		$data['menu'] = 'main_dashboard';


		$this->load->view("layouts/fix", $data);
	}



	
}