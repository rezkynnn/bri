<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class menu extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -  
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in 
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see http://codeigniter.com/user_guide/general/urls.html
	 */

	public function __construct()
	{
		    parent::__construct();
			$this->load->model('brisimpedes/model_mstuser');
			$this->load->model('brisimpedes/model_instalasi');
			$this->load->model('brisimpedes/model_mstperiodehadiah');
			$this->load->model('brisimpedes/model_undian');
			

			

	}

	public function index()
	{
		$param['kode_user']  = ($this->input->post('kode_user')!='')  ? $this->input->post('kode_user')  : ($this->uri->segment(3) ? $this->uri->segment(3) : 'true');

		$data['page'] = 'view_home';
		$data['menu'] = 'main_dashboard';
	//	$data['kode_user']=$param['kode_user'];
		
		$this->load->view("layouts/fix", $data);	
	}

	public function loginHalaman()
	{
		$a=$this->		model_instalasi->	cekdatabase();
		$b =$this->		model_instalasi->	cekdatabasetabel();
		//echo $a;
		//echo $b;

		if($a==1 && $b==1)
		{

			$param['kode_user']  = ($this->input->post('kode_user')!='')  ? $this->input->post('kode_user')  : ($this->uri->segment(3) ? $this->uri->segment(3) : 'true');
			$data['kode_user']=$param['kode_user'];
			$data['page'] = 'halaman_utama';
			$userundian = $this->model_mstuser->data_kancaundian();

			foreach ($userundian as $row) {
				$data['namakanca'] = $row->varNmKanca;
				$data['idkanca']   = $row->chrKdKanca;
				# code...
			}


			//$data['menu'] = 'main_dashboard';
			$this->load->view("halaman_utama", $data);
		}
		else if ($a==0 || $b==0)
		{
			$commandMysql 			= 'sh cekdir.sh /opt/lampp/var/mysql/';
	        $commandXamp 			= 'sh cekdir.sh /opt/lampp/';
	        $commandWebsever 		= 'sh cekdir.sh /opt/lampp/htdocs/';
	        $comandstatus 			= '/opt/lampp/lampp status';

	        $cobaMysql				= exec ($commandMysql);
	        if($cobaMysql==1)
	        {
	        	$cobaMysql = '-terpasang-';
	        }
	        else
	        {
				$cobaMysql = '-belum terpasang-';
	        }

	        $cobaXamp				= exec ($commandXamp);
	        if($cobaXamp==1)
	        {
	        	$cobaXamp = '-terpasang-';
	        }
	        else
	        {
				$cobaXamp = '-belum terpasang-';
	        }
	        

	        $cobaWebserver			= exec ($commandWebsever);
	        if($cobaWebserver==1)
	        {
	        	$cobaWebserver = '-terpasang-';
	        }
	        else
	        {
				$cobaWebserver = '-belum terpasang-';
	        }


	     $statusAllTolls 	= shell_exec($comandstatus);
    	 
    	 $data['folderxamp'] 	=  $cobaXamp;
		 $data['foldermysql'] 	=  $cobaMysql;
		 $data['folderwebserver']=  $cobaWebserver;
		 $data['statusAll'] 	=  $statusAllTolls;


		 	$data['page'] = 'instalasi/instalasi_';
			$data['menu'] = 'main_dashboard';
			$this->load->view("layouts/fix_installasi", $data);

		}

	}





	public function utama()
	{
		$data['jumlahmax'] 		='0';
		$data['jumlah_masuk']	='0';
		$data['jumlahMaxKupon']	= '0';

		$periode 				= $this->model_mstperiodehadiah->data_mstperiode();
		$data["periode"] 		= $periode;
		$kodeperiode 			= '';
		$id_kanca 				=$this->session->userdata('kode_kanca');

			if(isset($_GET['id']) && $_GET['id']!='0')
			{
				$data['countdown'] 		= $this->model_mstperiodehadiah->selisihwaktuundian($this->session->userdata('kode_kanca'),$_GET['id']);
				

				$cekTable =$this->model_undian->cektable_existornot($this->session->userdata('kode_kanca'),$_GET['id']);
				$data["cekTable"] 		=$cekTable;
				$data["idperiode"] 		=$_GET['id'];

				if($cekTable){
				$data['jumlahmax'] 		= $this->model_undian->get_nilaimaxKuponPeriode($id_kanca,$_GET['id']);
				$data['jumlah_masuk'] 	= $this->model_undian->get_nilaimaxKuponMasuk($id_kanca,$_GET['id']);
				$data['jumlahMaxKupon']	= $this->model_undian->get_maxundiandaridtlnomorundianPeriode($id_kanca,$_GET['id']);
				}
				$data['statushadiah']	= $this->model_mstperiodehadiah->statusHadiahDepan($id_kanca,$_GET['id']);
		
			}
			else
			{
				foreach ($periode as $row) {
				$kodeperiode = $row->chrKdPeriode; 
				break;
				}
				$data['countdown'] 		= $this->model_mstperiodehadiah->selisihwaktuundian($this->session->userdata('kode_kanca'),$kodeperiode);
				$cekTable 				=$this->model_undian->cektable_existornot($this->session->userdata('kode_kanca'),$kodeperiode);
				$data["cekTable"] 		=$cekTable;
				$data["idperiode"] 		=$kodeperiode;

				if($cekTable){
				$data['jumlahmax'] 		= $this->model_undian->get_nilaimaxKuponPeriode($id_kanca,$kodeperiode);
				$data['jumlah_masuk'] 	= $this->model_undian->get_nilaimaxKuponMasuk($id_kanca,$kodeperiode);
				$data['jumlahMaxKupon']	= $this->model_undian->get_maxundiandaridtlnomorundianPeriode($id_kanca,$kodeperiode);
			
				}
				$data['statushadiah']	= $this->model_mstperiodehadiah->statusHadiahDepan($id_kanca,$kodeperiode);

			}
		$data['kode_user']		=$this->session->userdata('kode_user');
		$data['nama_user'] 		= $this->session->userdata('nama_user');
		$data['kode_kanca'] 	= $this->session->userdata('kode_kanca');
		$data['group_area'] 	= $this->session->userdata('group_area');
		$data['otoritas'] 		= $this->session->userdata('otoritas');
		$data['kodekanwil'] 	= $this->session->userdata('kanwil');
		$data["pilihperiode"]	= '';

		$data['page'] 			= 'view_home';
		$data['menu'] 			= 'main_dashboard';
		
//echo $kodeperiode;
		$this->load->view("layouts/fixhome", $data);	



	}




	public function login()
	{
		

		if($this->input->post('mode')=='')
		{


		$param['username']  = ($this->input->post('username')!='')  ? $this->input->post('username')  : ($this->uri->segment(3) ? $this->uri->segment(3) : '');
		$param['password']  = ($this->input->post('password')!='')  ? $this->input->post('password')  : ($this->uri->segment(4) ? $this->uri->segment(4) : '');

		$username = $param['username'];
		$password = $param['password'];

		/*$where = array(
				'nama_user' => $username,
				'password' => md5($password)
			);

*/
		$where = array(
				'chrKdUser' => $username,
				'chrPassword' => md5($password)
			);

		$login= $this->model_mstuser->login($where);
		//$login = $this->m_users->login($where);
		$no=0;

		if(isset($login)){

			foreach($login as $log){
				$no++;
				//set session
				$this->session->set_userdata('kode_user',$log->chrKdUser);
				$this->session->set_userdata('nama_user',$log->vcrNmUser);
				$this->session->set_userdata('kode_kanca',$log->chrKdKanca);
				$this->session->set_userdata('group_area',$log->chrKdGrpArea );
				$this->session->set_userdata('otoritas',$log->chrOtoritas);
				$this->session->set_userdata('kanwil',$log->chrKdKanwil);
			
			
			
			}

		}



		if ($no==1)
		{
			redirect('menu/utama');
		}
		else
		{
			redirect('menu/loginHalaman/false');
		}}

	
		if($this->input->post('mode')=='on')
		{
			redirect('http://localhost/BRIUNDIANSIMPEDES/');
		}

	}

	public function loginuser()
	{
		$param['username']  = ($this->input->post('username')!='')  ? $this->input->post('username')  : ($this->uri->segment(3) ? $this->uri->segment(3) : '');
		$param['password']  = ($this->input->post('password')!='')  ? $this->input->post('password')  : ($this->uri->segment(4) ? $this->uri->segment(4) : '');

		$username = $param['username'];
		$password = $param['password'];

		$where = array(
				'chrKdUser' => "s206spv",
				'chrPassword' => "supervisor"
			);
		$login = $this->model_mstuser->login($where);
		if($login->num_rows()==1){

			foreach($login->result() as $log){
				//set session
				$this->session->set_userdata('id',$log->id);
				$this->session->set_userdata('username',$log->nama_user);
				$this->session->set_userdata('ao_status',$log->ao_status);
				$this->session->set_userdata('ao_bumn',$log->ao_bumn);
				$this->session->set_userdata('jabatan',$log->jabatan_user);
			}

			redirect('c_main_dashboard');
		}else{
			redirect('c_users/index/false');
		}
	}



	public function logout()
	{
		$this->session->sess_destroy();
		redirect('menu/loginHalaman');
	}

}