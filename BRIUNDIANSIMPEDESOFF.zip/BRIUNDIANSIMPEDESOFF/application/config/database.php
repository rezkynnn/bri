<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/*
| -------------------------------------------------------------------
| DATABASE CONNECTIVITY SETTINGS
| -------------------------------------------------------------------
| This file will contain the settings needed to access your database.
|
| For complete instructions please consult the 'Database Connection'
| page of the User Guide.
|
| -------------------------------------------------------------------
| EXPLANATION OF VARIABLES
| -------------------------------------------------------------------
|
|	['hostname'] The hostname of your database server.
|	['username'] The username used to connect to the database
|	['password'] The password used to connect to the database
|	['database'] The name of the database you want to connect to
|	['dbdriver'] The database type. ie: mysql.  Currently supported:
				 mysql, mysqli, postgre, odbc, mssql, sqlite, oci8
|	['dbprefix'] You can add an optional prefix, which will be added
|				 to the table name when using the  Active Record class
|	['pconnect'] TRUE/FALSE - Whether to use a persistent connection
|	['db_debug'] TRUE/FALSE - Whether database errors should be displayed.
|	['cache_on'] TRUE/FALSE - Enables/disables query caching
|	['cachedir'] The path to the folder where cache files should be stored
|	['char_set'] The character set used in communicating with the database
|	['dbcollat'] The character collation used in communicating with the database
|				 NOTE: For MySQL and MySQLi databases, this setting is only used
| 				 as a backup if your server is running PHP < 5.2.3 or MySQL < 5.0.7.
| 				 There is an incompatibility in PHP with mysql_real_escape_string() which
| 				 can make your site vulnerable to SQL injection if you are using a
| 				 multi-byte character set and are running versions lower than these.
| 				 Sites using Latin-1 or UTF-8 database character set and collation are unaffected.
|	['swap_pre'] A default table prefix that should be swapped with the dbprefix
|	['autoinit'] Whether or not to automatically initialize the database.
|	['stricton'] TRUE/FALSE - forces 'Strict Mode' connections
|							- good for ensuring strict SQL while developing
|
| The $active_group variable lets you choose which connection group to
| make active.  By default there is only one group (the 'default' group).
|
| The $active_record variables lets you determine whether or not to load
| the active record class
*/

$active_group = 'default';
$active_record = TRUE;

//SETUP DATABASE
$koneksi = 'localhost';
$hakakses = 'root';
$password = '';
//$db['db1']['database'] = 'brisimpedes_back';
$mysql = 'mysqli';
$dbperfixx = '';
$pconnect = FALSE;
$db_debugg = TRUE;
$cache_onn = FALSE;
$cachedirr = '';
$char_sett = 'utf8';
$dbcollatt = 'utf8_general_ci';
$swap_pree = '';
$autoinitt = TRUE;
$strictonn = FALSE;





$db['default']['hostname'] = $koneksi;
$db['default']['username'] = $hakakses;
$db['default']['password'] = $password;
//$db['default']['database'] = 'brisimpedes_back';
$db['default']['database'] = 'pengundianoffline';
$db['default']['dbdriver'] = $mysql;
$db['default']['dbprefix'] = $dbperfixx;
$db['default']['pconnect'] = $pconnect;
$db['default']['db_debug'] = $db_debugg;
$db['default']['cache_on'] = $cache_onn;
$db['default']['cachedir'] = $cachedirr;
$db['default']['char_set'] = $char_sett;
$db['default']['dbcollat'] = $dbcollatt;
$db['default']['swap_pre'] = $swap_pree;
$db['default']['autoinit'] = $autoinitt;
$db['default']['stricton'] = $strictonn;



$db['db1']['hostname'] = 'localhost';
$db['db1']['username'] = $hakakses;
$db['db1']['password'] = $password;
$db['db1']['database'] = 'pengundianoffline';
$db['db1']['dbdriver'] = 'mysqli';
$db['db1']['dbprefix'] = '';
$db['db1']['pconnect'] = FALSE;
$db['db1']['db_debug'] = TRUE;
$db['db1']['cache_on'] = FALSE;
$db['db1']['cachedir'] = '';
$db['db1']['char_set'] = 'utf8';
$db['db1']['dbcollat'] = 'utf8_general_ci';
$db['db1']['swap_pre'] = '';
$db['db1']['autoinit'] = TRUE;
$db['db1']['stricton'] = FALSE;

$db['pengundianoffline']['hostname'] = 'localhost';
$db['pengundianoffline']['username'] = $hakakses;
$db['pengundianoffline']['password'] = $password;
$db['pengundianoffline']['database'] = 'pengundianoffline';
$db['pengundianoffline']['dbdriver'] = 'mysqli';
$db['pengundianoffline']['dbprefix'] = '';
$db['pengundianoffline']['pconnect'] = FALSE;
$db['pengundianoffline']['db_debug'] = TRUE;
$db['pengundianoffline']['cache_on'] = FALSE;
$db['pengundianoffline']['cachedir'] = '';
$db['pengundianoffline']['char_set'] = 'utf8';
$db['pengundianoffline']['dbcollat'] = 'utf8_general_ci';
$db['pengundianoffline']['swap_pre'] = '';
$db['pengundianoffline']['autoinit'] = TRUE;
$db['pengundianoffline']['stricton'] = FALSE;

$db['checksum_file']['hostname'] = 'localhost';
$db['checksum_file']['username'] = $hakakses;
$db['checksum_file']['password'] = $password;
$db['checksum_file']['database'] = 'checksum_file';
$db['checksum_file']['dbdriver'] = 'mysqli';
$db['checksum_file']['dbprefix'] = '';
$db['checksum_file']['pconnect'] = FALSE;
$db['checksum_file']['db_debug'] = TRUE;
$db['checksum_file']['cache_on'] = FALSE;
$db['checksum_file']['cachedir'] = '';
$db['checksum_file']['char_set'] = 'utf8';
$db['checksum_file']['dbcollat'] = 'utf8_general_ci';
$db['checksum_file']['swap_pre'] = '';
$db['checksum_file']['autoinit'] = TRUE;
$db['checksum_file']['stricton'] = FALSE;






/* End of file database.php */
/* Location: ./application/config/database.php */
