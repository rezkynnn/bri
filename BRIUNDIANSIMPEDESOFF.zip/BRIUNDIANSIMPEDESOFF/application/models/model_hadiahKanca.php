<?php

class model_hadiahKanca extends CI_Model
{
	
		function jumlah_hadiahumum(){
			$jumlah = $this->db->query("SELECT COUNT( chrJnsHadiah  )as jumlah FROM dbo_msthadiahkanca e WHERE CAST( chrJnsHadiah AS UNSIGNED ) > 20 AND CAST( chrJnsHadiah AS UNSIGNED ) < 50  and chrKdPeriode = '022014' and
			NOT EXISTS(
        	SELECT  null 
        	FROM    dbo_dtldaftarpemenang d
        	WHERE   e.chrJnsHadiah = d.chrJnsHadiah AND `chrKdPeriode` = '022014')" )->result();
			
			if (isset($jumlah)) 
       		{
	        	foreach ($jumlah as $row) 
	        	{
                  $jumlah = $row->jumlah;
            	}
        	}
			return $jumlah;
		}

			function jumlah_hadiahumumpemenang(){
			$jumlah = $this->db->query("SELECT COUNT( chrJnsHadiah  )as jumlah FROM dbo_dtldaftarpemenang e WHERE CAST( chrJnsHadiah AS UNSIGNED ) > 20 AND CAST( chrJnsHadiah AS UNSIGNED ) < 50  and `chrKdPeriode` = '022014'and
			NOT EXISTS(
        	SELECT  null 
        	FROM    dbo_dtldaftarpemenang d
        	WHERE   e.chrJnsHadiah = d.chrJnsHadiah AND `chrKdPeriode` = '022014')")->result();
			if (isset($jumlah)) 
       		{
	        	foreach ($jumlah as $row) 
	        	{
                  $jumlah = $row->jumlah;
            	}
        	}
			return $jumlah;
		}





		function select_hadiahumum(){
			$data = $this->db->query("SELECT chrJnsHadiah , vcrNamaHadiah FROM dbo_msthadiahkanca e WHERE CAST( chrJnsHadiah AS UNSIGNED ) > 20 AND CAST( chrJnsHadiah AS UNSIGNED ) < 50  and `chrKdPeriode` = '022014'and
			NOT EXISTS(
        	SELECT  null 
        	FROM    dbo_dtldaftarpemenang d
        	WHERE   e.chrJnsHadiah = d.chrJnsHadiah AND `chrKdPeriode` = '022014')" )->result();
			return $data;
		}





		function jumlah_hadiahutama(){
			$jumlah = $this->db->query("SELECT COUNT( chrJnsHadiah  )as jumlah FROM dbo_msthadiahkanca e WHERE CAST( chrJnsHadiah AS UNSIGNED ) > 0 AND CAST( chrJnsHadiah AS UNSIGNED ) < 20  and `chrKdPeriode` = '022014' and
			NOT EXISTS(
        	SELECT  null 
        	FROM    dbo_dtldaftarpemenang d
        	WHERE   e.chrJnsHadiah = d.chrJnsHadiah AND `chrKdPeriode` = '022014')" )->result();
			if (isset($jumlah)) 
       		{
	        	foreach ($jumlah as $row) 
	        	{
                  $jumlah = $row->jumlah;
            	}
        	}
			return $jumlah;
		}


		function select_hadiahutama(){
			$data = $this->db->query("SELECT chrJnsHadiah , vcrNamaHadiah FROM dbo_msthadiahkanca e WHERE CAST( chrJnsHadiah AS UNSIGNED ) > 0 AND CAST( chrJnsHadiah AS UNSIGNED ) < 20  and `chrKdPeriode` = '022014' and
			NOT EXISTS(
        	SELECT  null 
        	FROM    dbo_dtldaftarpemenang d
        	WHERE   e.chrJnsHadiah = d.chrJnsHadiah AND `chrKdPeriode` = '022014')" )->result();
			return $data;
		}



		function jumlah_hadiahhiburan(){
			$jumlah = $this->db->query("SELECT COUNT( chrJnsHadiah  )as jumlah FROM dbo_msthadiahkanca e WHERE CAST( chrJnsHadiah AS UNSIGNED ) > 50 and `chrKdPeriode` = '022014' and
			NOT EXISTS(
        	SELECT  null 
        	FROM    dbo_dtldaftarpemenang d
        	WHERE   e.chrJnsHadiah = d.chrJnsHadiah AND `chrKdPeriode` = '022014')" )->result();
			if (isset($jumlah)) 
       		{
	        	foreach ($jumlah as $row) 
	        	{
                  $jumlah = $row->jumlah;
            	}
        	}
			return $jumlah;
		}


		function select_hadiahhiburan(){
			$data = $this->db->query("SELECT chrJnsHadiah , vcrNamaHadiah FROM dbo_msthadiahkanca e WHERE CAST( chrJnsHadiah AS UNSIGNED ) > 50 and `chrKdPeriode` = '022014' and
			NOT EXISTS(
        	SELECT  null 
        	FROM    dbo_dtldaftarpemenang d
        	WHERE   e.chrJnsHadiah = d.chrJnsHadiah)" )->result();
			return $data;
		}
	

}
?>