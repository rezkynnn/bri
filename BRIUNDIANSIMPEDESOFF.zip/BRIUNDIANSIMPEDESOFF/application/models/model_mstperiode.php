<?php

class model_mstperiode extends CI_Model
{
	
		function data_mstperiode(){
			return $this->db->query('SELECT `chrKdPeriode`,CONVERT(`dtmTglAwal`, DATE) as awal, CONVERT(`dtmTglAkhir`, DATE) as akhir  FROM `dbo_mstperiode` order by `chrKdPeriode` ASC')->result();
		}

		function data_periode(){
			return $this->db->query('SELECT `chrKdPeriode`,CONVERT(`dtmTglAwal`, DATE) as awal, CONVERT(`dtmTglAkhir`, DATE) as akhir  FROM `dbo_mstperiode` order by `chrKdPeriode` ASC')->result();
		}






	

}
?>