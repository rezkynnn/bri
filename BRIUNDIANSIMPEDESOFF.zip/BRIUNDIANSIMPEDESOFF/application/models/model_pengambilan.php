<?php
 
 class Model_pengambilan extends CI_Model
 {
 	
 	function all_pengambilan(){
		return $this->db->query('SELECT * FROM pengambilan ORDER by tanggal_pengambilan DESC ')->result();
	}
	function recent(){
		return $this->db->query('SELECT * FROM pengambilan')->result();
	}
	function insert($data)
	{
		return $this->db->insert('pengambilan',$data);
	}
	function get_article($id){
		$this->db->where('id_pengambilan', $id);
		return $this->db->get('pengambilan')->row();
	}
	function update($id,$data){
		$this->db->where('id', $id);
		$this->db->update('pengambilan', $data);
	}
	function delete($id){
		$this->db->where('id',$id);
		return $this->db->delete('pengambilan');
	}

	function get_barang(){
		 $query = $this->db->query('SELECT nama_barang FROM barang');
        return $query->result();
	}
	function get_satuan(){
		 $query = $this->db->query('SELECT satuan_barang FROM barang');
        return $query->result();
	}
 }
?>