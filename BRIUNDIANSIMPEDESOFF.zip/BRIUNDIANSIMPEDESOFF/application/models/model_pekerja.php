<?php

class Model_pekerja extends CI_Model
{
	
		function all_pekerja(){
			return $this->db->query('SELECT * FROM pekerja')->result();
		}
		function insert($data)
		{
			return $this->db->insert('pekerja',$data);
		}
		function get_pekerja($id){
			$this->db->where('id_pekerja', $id);
			return $this->db->get('pekerja')->row();
		}
		function edit_pekerja($id_pekerja,$nama_pekerja, $bagian_pekerja,$username_pekerja,$password_pekerja){
			$data= array('id_pekerja' => $id_pekerja,
						 'nama_pekerja' =>	$nama_pekerja,
						 'bagian_pekerja' =>	$bagian_pekerja,
						 'username_pekerja' =>	$username_pekerja,
						 'password_pekerja' =>	$password_pekerja,
			 );
			$this->db->where('id_pekerja', $id_pekerja);
			$this->db->update('pekerja', $data);
		}
		function delete($id){
			$this->db->where('id',$id);
			return $this->db->delete('pekerja');
		}
}
?>