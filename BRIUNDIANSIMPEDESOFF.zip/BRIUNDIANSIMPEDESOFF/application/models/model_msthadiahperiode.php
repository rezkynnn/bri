<?php

class model_msthadiahperiode extends CI_Model
{
	
		function data_hadiah_tampilkan(){
			return $this->db->query('SELECT * FROM `dbo_msthadiahperiod` ORDER by `chrKdHadiah` ASC')->result();
		}

		function existing_data($hadiah)
		{
			$sukses = "";
			$sql = "select exists(select `chrJnsHadiah`FROM `dbo_msthadiahkanca` WHERE `chrJnsHadiah` = '".$hadiah."' and `chrKdPeriode` = '022014') as hasil";
			$flag = $this->db->query($sql)->result();
			if (isset($flag)) 
       		{
	        	foreach ($flag as $row) 
	        	{
                  $hasil = $row->hasil;
            	}
        	}

	       	else
	    	{
	    		$hasil = "kosong";


        	}
//        	$hasil = o;
			return $hasil;
			
		}

		function hitung_jumlah_hadiah($hadiah)
		{
			$hasil = 0;
			$flag = $this->db->query("SELECT `vcrNamaHadiah`, `intJmlhadiah` FROM `dbo_msthadiahkanca` WHERE `chrJnsHadiah` = '".$hadiah."' and `chrKdPeriode` = '022014'")->result();
			if (isset($flag)) 
       		{
	        	foreach ($flag as $row) 
	        	{
                  $hasil = $row->intJmlhadiah;
            	}
        	}
        	else
	    	{
	    		$hasil = 0;


        	}
			return $hasil;
	
		}

		function tmpbanyakperiode(){
			return $this->db->query('SELECT * FROM `dbo_tmpbanyakperiode`')->result();
		}







	

}
?>