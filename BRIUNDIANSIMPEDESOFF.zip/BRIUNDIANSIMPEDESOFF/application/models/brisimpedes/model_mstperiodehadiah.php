<?php

class model_mstperiodehadiah extends CI_Model
{
	 	private $another;
  		function __construct()
  		{
    		parent::__construct();
  		}

	
		function data_mstperiode(){
			return $this->db->query('SELECT `chrKdPeriode`,CONVERT(`dtmTglAwal`, DATE) as awal, CONVERT(`dtmTglAkhir`, DATE) as akhir  FROM `dbo_mstperiode` order by `chrKdPeriode` ASC')->result();
		}
		function data_periode(){
			return $this->db->query('SELECT `chrKdPeriode`,`numJmlGrandprize`,`numJmlUtama`,`numJmlBiasa`,`numJmlHiburan`,CONVERT(`dtmTglAwal`, DATE) as awal, CONVERT(`dtmTglAkhir`, DATE) as akhir  
				FROM `dbo_mstperiode` order by `chrKdPeriode` ASC')->result();
		}

		function data_bulan(){
			return $this->db->query('SELECT `kodeBulan` FROM `dbo_dtlnomorundian` GROUP by `kodeBulan` ')->result();
		}


		function data_periode_kanca($idkanca,$period){
			$this->db_kanca = $this->load->database('pengundianoffline',TRUE); 
			$periode = $this->db_kanca->query("SELECT `chrKdPeriode`,`numJmlGrandprize`,`numJmlUtama`,`numJmlBiasa`,`numJmlHiburan`,CONVERT(`dtmTglAwal`, DATE) as awal, CONVERT(`dtmTglAkhir`, DATE) as akhir  
			FROM dbo_mstperiode where chrKdPeriode = '".$period."' order by `chrKdPeriode` ASC")->result();
			
			$get_periode = '';
			foreach ($periode as $row) {
				$get_periode = $row->awal."=".$row->akhir;
			}

			return $get_periode;
		}

		function data_periode_undian($periode){
			return $this->db->query(
				"SELECT *, CONVERT(`dtmTglAwal`, DATE) as awal, CONVERT(`dtmTglAkhir`, DATE) as akhir 
				FROM `dbo_mstperiode` 
				where `chrKdPeriode` ='".$periode."' order by `chrKdPeriode` ASC")->result();
		}


		function data_periodehuUdian($idkanca,$idundian){
			$this->db_kanca = $this->load->database($idkanca,TRUE);  
			return $this->db_kanca->query("SELECT k.chrKdPeriode, k.varJenisHadiah, k.varTypeHadiah, k.varMerkHadiah, k.chrJnsHadiah, vcrNamaHadiah as nama, chrNmHadiah as jenishadiah, intJmlhadiah as jumlah, chrKdHadiah as kode
			FROM dbo_mstperiode h, dbo_msthadiahkanca k, dbo_msthadiahperiod p
			WHERE h.chrKdPeriode = k.chrKdPeriode
			AND k.chrKdPeriode = p.chrKdPeriode
			AND k.chrKdPeriode='".$idundian."'
			AND k.chrJnsHadiah > 80
			AND k.chrJnsHadiah = p.chrKdHadiah
				")->result();
		}

		function data_periodehuUdiankategori($idundian,$idkategori,$idkanca){
			$this->db_kanca = $this->load->database($idkanca,TRUE);  
			return $this->db_kanca->query("SELECT k.chrKdPeriode, k.varJenisHadiah, k.varTypeHadiah, k.varMerkHadiah, k.chrJnsHadiah, vcrNamaHadiah as nama, chrNmHadiah as jenishadiah, intJmlhadiah as jumlah, chrKdHadiah as kode
			FROM dbo_mstperiode h, dbo_msthadiahkanca k, dbo_msthadiahperiod p
			WHERE h.chrKdPeriode = k.chrKdPeriode
			AND k.chrKdPeriode = p.chrKdPeriode
			AND k.chrKdPeriode='".$idundian."'
			AND k.chrJnsHadiah = '".$idkategori."'
			AND k.chrJnsHadiah = p.chrKdHadiah
				")->result();
		}


		function data_periodeHadiah($idkanca){
			
			$this->db_kanca = $this->load->database($idkanca,TRUE);  
			return $this->db_kanca->query("SELECT h.chrKdPeriode, CONVERT( h.dtmTglAwal, DATE ) AS awal, CONVERT( h.dtmTglAkhir, DATE ) AS akhir, vcrNamaHadiah as nama, chrNmHadiah as jenishadiah, intJmlhadiah as jumlah, chrKdHadiah as kode
			FROM dbo_mstperiode h, dbo_msthadiahkanca k, dbo_msthadiahperiod p
			WHERE h.chrKdPeriode = k.chrKdPeriode
			AND k.chrKdPeriode = p.chrKdPeriode
			AND k.chrJnsHadiah = p.chrKdHadiah
			ORDER BY `chrKdPeriode` ASC
				")->result();
		}

		function data_periodeHadiahdistribusi($idkanca){
			
			$this->db_kanca = $this->load->database($idkanca,TRUE);  
			return $this->db_kanca->query("SELECT h.chrKdPeriode, CONVERT( h.dtmTglAwal, DATE ) AS awal, CONVERT( h.dtmTglAkhir, DATE ) AS akhir, vcrNamaHadiah as nama, chrNmHadiah as jenishadiah, intJmlhadiah as jumlah, chrKdHadiah as kode
			FROM dbo_mstperiode h, dbo_msthadiahkanca k, dbo_msthadiahperiod p
			WHERE h.chrKdPeriode = k.chrKdPeriode
			AND k.chrKdPeriode = p.chrKdPeriode
			AND k.chrJnsHadiah = p.chrKdHadiah
			ORDER BY `chrKdPeriode` ASC
				")->result();
		}

		function data_periodeHadiahTiapKanca($idkanca,$idperiode){
			
			$this->db_kanca = $this->load->database($idkanca,TRUE);  
			return $this->db_kanca->query("SELECT * FROM `dbo_msthadiahkanca` WHERE `chrKdPeriode`='".$idperiode."'
			ORDER BY `chrKdPeriode` ASC
				")->result();
		}

		function data_periodeHadiahTiapKancaAll($idkanca){
			
			$this->db_kanca = $this->load->database($idkanca,TRUE);  
			return $this->db_kanca->query("SELECT * FROM `dbo_msthadiahkanca` ORDER BY `chrKdPeriode` ASC
				")->result();
		}

		function data_periodeHadiahGet($idperiode){
			return $this->db->query("SELECT h.chrKdPeriode, CONVERT( h.dtmTglAwal, DATE ) AS awal, CONVERT( h.dtmTglAkhir, DATE ) AS akhir, vcrNamaHadiah as nama, chrNmHadiah as jenishadiah, intJmlhadiah as jumlah, chrKdHadiah as kode
			FROM dbo_mstperiode h, dbo_msthadiahkanca k, dbo_msthadiahperiod p
			WHERE h.chrKdPeriode = k.chrKdPeriode
			AND k.chrKdPeriode = p.chrKdPeriode
			AND k.chrJnsHadiah = p.chrKdHadiah
			AND k.chrKdPeriode = '".$idperiode."'
			ORDER BY `chrKdPeriode` ASC
				")->result();
		}


		 function get_jenishadiah($kodeperiode){
			return $this->db->query("SELECT h.chrKdPeriode, CONVERT( h.dtmTglAwal, DATE ) AS awal, CONVERT( h.dtmTglAkhir, DATE ) AS akhir, vcrNamaHadiah as nama, chrNmHadiah as jenishadiah, intJmlhadiah as jumlah, chrKdHadiah as kode
			FROM dbo_mstperiode h, dbo_msthadiahkanca k, dbo_msthadiahperiod p
			WHERE h.chrKdPeriode = '".$kodeperiode."'
			AND k.chrKdPeriode = '".$kodeperiode."'
			AND k.chrJnsHadiah = p.chrKdHadiah
			ORDER BY `chrKdPeriode` ASC
				")->result();
		}

		function get_jeniskosong($kodeperiode)
		{
			return $this->db->query("SELECT * FROM dbo_msthadiahperiod e WHERE NOT EXISTS(
			select null from dbo_msthadiahkanca d where
			e.chrKdHadiah= d.chrJnsHadiah AND e.chrKdPeriode = '".$kodeperiode."')")->result();
		}


		function get_periodeHadiah($kodehadiah, $kodekanca, $kodekanwil){
			return $this->db->query("SELECT h.chrKdPeriode, k.chrKdKanca,
			k.chrKdKanwil,k.varJenisHadiah,k.varTypeHadiah,k.hargaSatuan,
			k.potonganHarga,K.tahunPembuatan,k.varKondisiPembuatan,k.statusHadiah,k.varMerkHadiah,
			CONVERT( h.dtmTglAwal, DATE ) AS awal, CONVERT( h.dtmTglAkhir, DATE ) AS akhir, vcrNamaHadiah as nama, chrNmHadiah as jenishadiah, intJmlhadiah as jumlah, chrKdHadiah as kode
			FROM dbo_mstperiode h, dbo_msthadiahkanca k, dbo_msthadiahperiod p
			WHERE h.chrKdPeriode = k.chrKdPeriode
			AND k.chrKdPeriode = p.chrKdPeriode
			AND k.chrJnsHadiah = p.chrKdHadiah
			AND k.chrJnsHadiah = '".$kodehadiah."'
			AND p.chrKdHadiah = '".$kodehadiah."'
			AND k.chrKdKanca ='".$kodekanca."'
			AND k.chrKdKanwil = '".$kodekanwil."'
			ORDER BY `chrKdPeriode` ASC
				")->result();
		}


		function data_JenisHadiah(){
			return $this->db->query("SELECT * FROM `dbo_msthadiahperiod` WHERE 1")->result();
		}

		function pemenang($kodeperiode,$idkanca)
		{
				$this->kanca = $this->load->database('pengundianoffline',TRUE);  
				return $this->kanca->query("SELECT p.chrNoUndian, p.chrNoRek,p.vcrNmNsbh,p.chrJnsHadiah,k.vcrNamaHadiah,p.dtmTglAdd, m.chrNmHadiah,p.namahadiah,p.chrKdPeriode,p.namaUker, p.kodeUker,p.chrJnsHadiah,p.chrUserAdd,k.varJenisHadiah,k.varTypeHadiah,k.varMerkHadiah   FROM dbo_dtldaftarpemenang p , dbo_msthadiahkanca k, dbo_msthadiahperiod m  WHERE p.chrJnsHadiah = k.chrJnsHadiah and p.chrKdPeriode='".$kodeperiode."' and k.chrKdPeriode='".$kodeperiode."' and m.chrKdHadiah=k.chrJnsHadiah group by chrNoRek order by chrJnsHadiah ASC")->result();
		}
		function pemenanghaidahuntukdropdown($kodeperiode,$idkanca)
		{
				$this->kanca = $this->load->database('pengundianoffline',TRUE);  
				return $this->kanca->query("SELECT p.chrNoUndian, p.chrNoRek,p.vcrNmNsbh,p.chrJnsHadiah,k.vcrNamaHadiah,p.dtmTglAdd, m.chrNmHadiah,p.namahadiah,p.chrKdPeriode,p.namaUker, p.kodeUker,p.chrJnsHadiah,p.chrUserAdd  FROM dbo_dtldaftarpemenang p , dbo_msthadiahkanca k, dbo_msthadiahperiod m  WHERE p.chrJnsHadiah = k.chrJnsHadiah and p.chrKdPeriode='".$kodeperiode."' and m.chrKdHadiah=k.chrJnsHadiah group by chrJnsHadiah order by chrJnsHadiah ASC")->result();
				$this->db->close();

		}

		function pemenanghadiah($kodeperiode , $kodehadiah,$idkanca)
		{
			$this->kanca = $this->load->database('pengundianoffline',TRUE);  
			return $this->kanca->query("SELECT p.chrNoUndian, p.chrNoRek,p.vcrNmNsbh,p.chrJnsHadiah,k.vcrNamaHadiah,p.dtmTglAdd, m.chrNmHadiah,p.namahadiah,p.chrKdPeriode,p.namaUker, p.kodeUker,p.chrJnsHadiah,p.chrUserAdd, k.varJenisHadiah,k.varTypeHadiah, k.varMerkHadiah   FROM dbo_dtldaftarpemenang p , dbo_msthadiahkanca k, dbo_msthadiahperiod m  WHERE p.chrJnsHadiah = k.chrJnsHadiah and k.chrJnsHadiah ='".$kodehadiah."' and k.chrKdPeriode=".$kodeperiode." and p.chrKdPeriode=".$kodeperiode." and m.chrKdHadiah=k.chrJnsHadiah group by chrNoRek order by chrJnsHadiah ASC")->result();
		}

		public function add_periode($insert,$char,$dateakhir,$jumlahG, $jmlUtama,$jmlBiasa,$jmlHiburan,$iduser)
		{

			  $jumlahGrand = 0;
              $jumlahUtama = 0;
              $numJmlBiasa = 0;
              $numJmlHiburan =  0;

			$this->another = $this->load->database('db1',TRUE); 
			$this->db->set('dtmUserAdd', 'NOW()', FALSE); 

		
			$this->db->insert('dbo_mstperiode',$insert);
			//$this->another->insert('dbo_mstperiode',$insert);
		

        	for($i=1; $i <=$jumlahG;$i++)
        	{ 
        		$charI="";
        		if($i<10)
        		{
        			$charI = "0".$i;
        		 	$insertgrandprize = array(
				    'chrKdPeriode' => $char,
				    'chrKdHadiah' => $charI,
					'chrNmHadiah' => 'GRANDPRIZE '.$this->romanic_number($i,"true"),
					'chrUserEdit' =>$iduser
					);
        		}
        		else
        		{
        			 $insertgrandprize = array(
				    'chrKdPeriode' => $char,
				    'chrKdHadiah' => $i,
					'chrNmHadiah' => 'GRANDPRIZE '.$this->romanic_number($i,"true"),
					'chrUserEdit' =>$iduser
					);

        		}

        		    
        		$this->db->insert('dbo_msthadiahperiod',$insertgrandprize);
        	}

           	for($i=1; $i <=$jmlUtama;$i++)
        	{

        		     $insertgrandprize = array(
				    'chrKdPeriode' => $char,
				    'chrKdHadiah' => 19+$i,
					'chrNmHadiah' => 'HADIAH UTAMA '.$this->romanic_number($i,"true"),
					'chrUserEdit' =>$iduser

					);
        		$this->db->insert('dbo_msthadiahperiod',$insertgrandprize);
        	}

        	for($i=1; $i <=$jmlBiasa;$i++)
        	{

        		     $insertgrandprize = array(
				    'chrKdPeriode' => $char,
				    'chrKdHadiah' => 49+$i,
					'chrNmHadiah' => 'HADIAH BIASA '.$this->romanic_number($i,"true"),
					'chrUserEdit' =>$iduser

					);
        		$this->db->insert('dbo_msthadiahperiod',$insertgrandprize);
        	}

        	for($i=1; $i <=$jmlHiburan;$i++)
        	{

        		     $insertgrandprize = array(
				    'chrKdPeriode' => $char,
				    'chrKdHadiah' => 79+$i,
					'chrNmHadiah' => 'HADIAH HIBURAN '.$this->romanic_number($i,"true"),
					'chrUserEdit' =>$iduser

					);
        		$this->db->insert('dbo_msthadiahperiod',$insertgrandprize);
        	}


	
		}

		public function updateperiode($insert,$char,$dateakhir,$jumlahG, $jmlUtama,$jmlBiasa,$jmlHiburan,$iduser)
		{
			  $jumlahGrand = 0;
              $jumlahUtama = 0;
              $numJmlBiasa = 0;
              $numJmlHiburan =  0;

		//	$this->another = $this->load->database('db1',TRUE); 
			$this->db->set('dtmUserEdit', 'NOW()', FALSE); 
			$this->db->where('chrKdPeriode',$char);
			$this->db->update('dbo_mstperiode',$insert);
//

			$this->db->where('chrKdPeriode', $char);
			if ($this->db->delete('dbo_msthadiahperiod'))
			{
				for($i=1; $i <=$jumlahG;$i++)
        	{ 
        		$charI="";
        		if($i<10)
        		{
        			$charI = "0".$i;
        		 	$insertgrandprize = array(
				    'chrKdPeriode' => $char,
				    'chrKdHadiah' => $charI,
					'chrNmHadiah' => 'GRANDPRIZE '.$this->romanic_number($i,"true"),
					'chrUserAdd' =>$iduser
					);
        		}
        		else
        		{
        			 $insertgrandprize = array(
				    'chrKdPeriode' => $char,
				    'chrKdHadiah' => $i,
					'chrNmHadiah' => 'GRANDPRIZE '.$this->romanic_number($i,"true"),
					'chrUserAdd' =>$iduser
					);

        		}

        		    
        		$this->db->insert('dbo_msthadiahperiod',$insertgrandprize);
        	}

           	for($i=1; $i <=$jmlUtama;$i++)
        	{

        		     $insertgrandprize = array(
				    'chrKdPeriode' => $char,
				    'chrKdHadiah' => 19+$i,
					'chrNmHadiah' => 'HADIAH UTAMA '.$this->romanic_number($i,"true"),
					'chrUserAdd' =>$iduser

					);
        		$this->db->insert('dbo_msthadiahperiod',$insertgrandprize);
        	}

        	for($i=1; $i <=$jmlBiasa;$i++)
        	{

        		     $insertgrandprize = array(
				    'chrKdPeriode' => $char,
				    'chrKdHadiah' => 49+$i,
					'chrNmHadiah' => 'HADIAH BIASA '.$this->romanic_number($i,"true"),
					'chrUserAdd' =>$iduser

					);
        		$this->db->insert('dbo_msthadiahperiod',$insertgrandprize);
        	}

        	for($i=1; $i <=$jmlHiburan;$i++)
        	{

        		     $insertgrandprize = array(
				    'chrKdPeriode' => $char,
				    'chrKdHadiah' => 79+$i,
					'chrNmHadiah' => 'HADIAH HIBURAN '.$this->romanic_number($i,"true"),
					'chrUserAdd' =>$iduser

					);
        		$this->db->insert('dbo_msthadiahperiod',$insertgrandprize);
        	}

		}
			
			//$this->another->insert('dbo_mstperiode',$insert);
		/*

        	
        	*/


		}


		public function delete_period($id_periode)
		{
			$this->db->where('chrKdPeriode', $id_periode);
			$this->db->delete('dbo_mstperiode');

			$this->db->where('chrKdPeriode', $id_periode);
			$this->db->delete('dbo_msthadiahperiod');
		}

		function tmpbanyakperiode($banyak){
	  		$this->another = $this->load->database('db1',TRUE);  
			//return $this->another->query("SELECT * FROM `dbo_msthadiahperiod` WHERE 1")->result();
			return $this->another->query("SELECT * FROM `dbo_tmpbanyakperiode` where `banyakBulan` = ".$banyak."")->result();
		}


		public function add_hadiah($idkanca,$insert, $periode, $kanwil, $kanca, $charjenis)
		{
			$this->another = $this->load->database($idkanca,TRUE);  
			
			$this->db->insert('dbo_msthadiahkanca',$insert);
			$this->another->insert('dbo_msthadiahkanca',$insert);
		//	 $sql = "UPDATE  `db_kc_s`.`dbo_msthadiahkanca` SET dtmUserAdd =  NOW() WHERE  `dbo_msthadiahkanca`.`chrKdPeriode` =  '".$periode."' AND  `dbo_msthadiahkanca`.`chrKdKanwil` =  '".$kanwil."' AND  `dbo_msthadiahkanca`.`chrKdKanca` =  '".$kanca."' AND  `dbo_msthadiahkanca`.`chrJnsHadiah` =  '".$charjenis."'";
		//	$this->db->query($sql);

		
		}

		public function update_hadiah($idkanca,$insert, $periode, $kanwil, $kanca, $charjenis)
		{
			$this->another = $this->load->database($idkanca,TRUE);  

			$this->db->where('chrJnsHadiah', $charjenis);
			$this->db->where('chrKdKanca', $idkanca);
			$this->db->where('chrKdPeriode', $periode);
			
			$this->db->update('dbo_msthadiahkanca', $insert);


			$this->another->where('chrJnsHadiah', $charjenis);
			$this->another->where('chrKdKanca', $idkanca);
			$this->another->where('chrKdPeriode', $periode);
			
			$this->another->update('dbo_msthadiahkanca', $insert);
	
	
		
		}

		public function delete_hadiah($idkanca, $periode, $charjenis)
		{
			$this->db->where('chrJnsHadiah', $charjenis);
			$this->db->where('chrKdKanca', $idkanca);
			$this->db->where('chrKdPeriode', $periode);
			$this->db->delete('dbo_msthadiahkanca');

			$this->kanca = $this->load->database($idkanca,TRUE);
			$this->kanca->where('chrJnsHadiah', $charjenis);
			$this->kanca->where('chrKdKanca', $idkanca);
			$this->kanca->where('chrKdPeriode', $periode);
			$this->kanca->delete('dbo_msthadiahkanca');


			
		}

		public function get_kancaUndian($kodeperiode)
		{
			return $this->db->query("SELECT h.chrKdKanca, h.chrKdPeriode, k.vcrNmKanca, w.vcrNmKanwil FROM dbo_msthadiahkanca h, dbo_mstkanca k, dbo_mstkanwil w WHERE h.chrKdPeriode='022014' and h.chrKdKanca=k.chrKdKanca and h.chrKdKanwil=w.chrKdKanwil group by h.chrKdKanca")->result();
		}

		public function get_kancaUndianAll($periode)
		{
			$this->another = $this->load->database('db1',TRUE);  
			return $this->another->query("SELECT hc.statusHadiah, h.chrKdKanca as kodekanca, h.chrKdPeriode, k.vcrNmKanca, w.vcrNmKanwil,CONVERT( p.dtmTglAwal, DATE ) AS awal, CONVERT( p.dtmTglAkhir, DATE ) AS akhir, h.KeteranganHadiah 
			FROM dbo_statushadiahkanca h, dbo_mstkanca k, dbo_mstkanwil w,dbo_mstperiode p, dbo_statushadiahkanca hc 
			WHERE hc.chrKdKanca=h.chrKdKanca and hc.statusHadiah=1 and hc.chrKdPeriode=h.chrKdPeriode and h.chrKdPeriode='".$periode."' and h.chrKdKanca=k.chrKdKanca and h.chrKdKanwil=w.chrKdKanwil group by kodekanca")->result();
		}
		public function update_kanwil($id_kanca,$id_kanwil,$data)
		{
			$this->another = $this->load->database('db1',TRUE);  
			//$sql = "UPDATE  `brisimpedes_back`.`dbo_statushadiahkanca` 
			//SET  `statusHadiah` =  '2' 
			//WHERE  `dbo_statushadiahkanca`.`chrKdPeriode` =  '022014' AND  `dbo_statushadiahkanca`.`chrKdKanwil` =  '".$id_kanwil."' AND `dbo_statushadiahkanca`.`chrKdKanca` =  '".$id_kanca."'";
			$this->another->set('datemodif', 'NOW()', FALSE); 
			$this->another->where('chrKdKanca', $id_kanca);
			$this->another->where('chrKdKanwil', $id_kanwil);

			$this->another->update('dbo_statushadiahkanca', $data);

		}

		public function update_kanpus($id_kanca,$id_kanwil,$data)
		{
			$this->another = $this->load->database('db1',TRUE);  
			//$sql = "UPDATE  `brisimpedes_back`.`dbo_statushadiahkanca` 
			//SET  `statusHadiah` =  '2' 
			//WHERE  `dbo_statushadiahkanca`.`chrKdPeriode` =  '022014' AND  `dbo_statushadiahkanca`.`chrKdKanwil` =  '".$id_kanwil."' AND `dbo_statushadiahkanca`.`chrKdKanca` =  '".$id_kanca."'";
			$this->another->set('datemodif', 'NOW()', FALSE); 

			$this->another->where('chrKdKanca', $id_kanca );
		//	$this->another->where('chrKdKanwil', $id_kanwil);

			$this->another->update('dbo_statushadiahkanca', $data);
		}

		function data_periodeHadiahkanca($idkanca, $idkanwil){
			$this->another = $this->load->database('db1',TRUE);  
		
			return $this->another->query("SELECT k.chrJnsHadiah,k.potonganHarga,h.chrKdPeriode,k.varJenisHadiah as varJenisHadiah, k.varTypeHadiah, k.varMerkHadiah,k.hargaSatuan,k.tahunPembuatan,k.varKondisiPembuatan, k.statusHadiah
		    ,k.chrKdKanwil,k.chrKdKanca, CONVERT( h.dtmTglAwal, DATE ) AS awal, CONVERT( h.dtmTglAkhir, DATE ) AS akhir, vcrNamaHadiah as nama, chrNmHadiah as jenishadiah, intJmlhadiah as jumlah, chrKdHadiah as kode
			FROM dbo_mstperiode h, dbo_msthadiahkanca k, dbo_msthadiahperiod p
			WHERE h.chrKdPeriode = k.chrKdPeriode
			AND k.chrKdPeriode = p.chrKdPeriode
			AND k.chrJnsHadiah = p.chrKdHadiah AND k.chrKdKanca ='".$idkanca."' AND k.chrKdKanwil='".$idkanwil."'
			ORDER BY k.`chrJnsHadiah` DESC
				")->result();
		}

		function data_periodeHadiahkancadetail($idkanca, $idkanwil,$periode){
			$this->another = $this->load->database('db1',TRUE);  
		
			return $this->another->query("SELECT k.chrJnsHadiah,k.potonganHarga,h.chrKdPeriode,k.varJenisHadiah as varJenisHadiah, k.varTypeHadiah, k.varMerkHadiah,k.hargaSatuan,k.tahunPembuatan,k.varKondisiPembuatan, k.statusHadiah
		    ,k.chrKdKanwil,k.chrKdKanca, CONVERT( h.dtmTglAwal, DATE ) AS awal, CONVERT( h.dtmTglAkhir, DATE ) AS akhir, vcrNamaHadiah as nama, chrNmHadiah as jenishadiah, intJmlhadiah as jumlah, chrKdHadiah as kode
			FROM dbo_mstperiode h, dbo_msthadiahkanca k, dbo_msthadiahperiod p
			WHERE h.chrKdPeriode = k.chrKdPeriode
			AND k.chrKdPeriode = p.chrKdPeriode
			AND p.chrKdPeriode = '".$periode."'
			AND k.chrJnsHadiah = p.chrKdHadiah AND k.chrKdKanca ='".$idkanca."' AND k.chrKdKanwil='".$idkanwil."'
			ORDER BY `chrKdPeriode` ASC
				")->result();
		}



	

		function data_periodeHadiahkancaperperiode($idkanca, $idkanwil, $periode){
			$this->another = $this->load->database('db1',TRUE);  
		
			return $this->another->query("SELECT k.chrJnsHadiah,k.potonganHarga,h.chrKdPeriode,k.varJenisHadiah as varJenisHadiah, k.varTypeHadiah, k.varMerkHadiah,k.hargaSatuan,k.tahunPembuatan,k.varKondisiPembuatan, k.statusHadiah
		    ,k.chrKdKanwil,k.chrKdKanca, CONVERT( h.dtmTglAwal, DATE ) AS awal, CONVERT( h.dtmTglAkhir, DATE ) AS akhir, vcrNamaHadiah as nama, chrNmHadiah as jenishadiah, intJmlhadiah as jumlah, chrKdHadiah as kode
			FROM dbo_mstperiode h, dbo_msthadiahkanca k, dbo_msthadiahperiod p
			WHERE h.chrKdPeriode = k.chrKdPeriode
			AND k.chrKdPeriode = p.chrKdPeriode
			AND k.chrKdPeriode = '".$periode."'
			AND k.chrJnsHadiah = p.chrKdHadiah AND k.chrKdKanca ='".$idkanca."' AND k.chrKdKanwil='".$idkanwil."'
			ORDER BY k.`chrJnsHadiah` ASC
				")->result();
		}


		function data_periodeHadiahkancaPusat($idkanca, $idkanwil){
			$this->another = $this->load->database('db1',TRUE);  
		
			return $this->another->query("SELECT k.chrJnsHadiah,k.potonganHarga,h.chrKdPeriode,k.varJenisHadiah as varJenisHadiah, k.varTypeHadiah, k.varMerkHadiah,k.hargaSatuan,k.tahunPembuatan,k.varKondisiPembuatan, k.statusHadiah
		    ,k.chrKdKanwil,k.chrKdKanca, CONVERT( h.dtmTglAwal, DATE ) AS awal, CONVERT( h.dtmTglAkhir, DATE ) AS akhir, vcrNamaHadiah as nama, chrNmHadiah as jenishadiah, intJmlhadiah as jumlah, chrKdHadiah as kode
			FROM dbo_mstperiode h, dbo_msthadiahkanca k, dbo_msthadiahperiod p
			WHERE h.chrKdPeriode = k.chrKdPeriode
			AND k.chrKdPeriode = p.chrKdPeriode
			AND k.chrJnsHadiah = p.chrKdHadiah AND k.chrKdKanca ='".$idkanca."'
			ORDER BY `chrKdPeriode` ASC
				")->result();
		}

		function data_periodeHadiahkancaPusatdetail($idkanca, $idkanwil,$periode){
			$this->another = $this->load->database('db1',TRUE);  
		
			return $this->another->query("SELECT k.chrJnsHadiah,k.potonganHarga,h.chrKdPeriode,k.varJenisHadiah as varJenisHadiah, k.varTypeHadiah, k.varMerkHadiah,k.hargaSatuan,k.tahunPembuatan,k.varKondisiPembuatan, k.statusHadiah
		    ,k.chrKdKanwil,k.chrKdKanca, CONVERT( h.dtmTglAwal, DATE ) AS awal, CONVERT( h.dtmTglAkhir, DATE ) AS akhir, vcrNamaHadiah as nama, chrNmHadiah as jenishadiah, intJmlhadiah as jumlah, chrKdHadiah as kode
			FROM dbo_mstperiode h, dbo_msthadiahkanca k, dbo_msthadiahperiod p
			WHERE h.chrKdPeriode = k.chrKdPeriode
			AND k.chrKdPeriode = p.chrKdPeriode
			AND k.chrKdPeriode = '".$periode."'
			AND k.chrJnsHadiah = p.chrKdHadiah AND k.chrKdKanca ='".$idkanca."'
			ORDER BY `chrKdPeriode` ASC
				")->result();
		}

		// kantor Pusat 
		public function get_kancaUndianAllkanpusterima($periode)
		{
			$this->another = $this->load->database('db1',TRUE);  
			return $this->another->query("SELECT CONVERT(hc.dtmTglPelaksanaan,DATE) as dtmTglPelaksanaan,hc.datemodif, hc.statusHadiah, h.chrKdKanca as kodekanca, h.chrKdPeriode, k.vcrNmKanca, w.vcrNmKanwil,CONVERT( p.dtmTglAwal, DATE ) AS awal, CONVERT( p.dtmTglAkhir, DATE ) AS akhir, h.KeteranganHadiah 
			FROM dbo_statushadiahkanca h, dbo_mstkanca k, dbo_mstkanwil w,dbo_mstperiode p, dbo_statushadiahkanca hc 
			WHERE hc.chrKdKanca=h.chrKdKanca and hc.statusHadiah=4 and hc.chrKdPeriode=h.chrKdPeriode and h.chrKdPeriode='".$periode."' and h.chrKdKanca=k.chrKdKanca and h.chrKdKanwil=w.chrKdKanwil group by kodekanca")->result();
		}
		public function get_kancaUndianAllkanpustolak($periode)
		{
			$this->another = $this->load->database('db1',TRUE);  
			return $this->another->query("SELECT CONVERT(hc.dtmTglPelaksanaan,DATE) as dtmTglPelaksanaan,hc.datemodif, hc.statusHadiah, h.chrKdKanca as kodekanca, h.chrKdPeriode, k.vcrNmKanca, w.vcrNmKanwil,CONVERT( p.dtmTglAwal, DATE ) AS awal, CONVERT( p.dtmTglAkhir, DATE ) AS akhir, h.KeteranganHadiah 
			FROM dbo_statushadiahkanca h, dbo_mstkanca k, dbo_mstkanwil w,dbo_mstperiode p, dbo_statushadiahkanca hc 
			WHERE hc.chrKdKanca=h.chrKdKanca and hc.statusHadiah=3 and hc.chrKdPeriode=h.chrKdPeriode and h.chrKdPeriode='".$periode."' and h.chrKdKanca=k.chrKdKanca and h.chrKdKanwil=w.chrKdKanwil group by kodekanca")->result();
		}
		public function get_kancaUndianAllkanpuspermohonan($periode)
		{
			$this->another = $this->load->database('db1',TRUE);  
			return $this->another->query("SELECT CONVERT(hc.dtmTglPelaksanaan,DATE) as dtmTglPelaksanaan, hc.datemodif, hc.statusHadiah, h.chrKdKanca as kodekanca, h.chrKdPeriode, k.vcrNmKanca, w.vcrNmKanwil,CONVERT( p.dtmTglAwal, DATE ) AS awal, CONVERT( p.dtmTglAkhir, DATE ) AS akhir, h.KeteranganHadiah 
			FROM dbo_statushadiahkanca h, dbo_mstkanca k, dbo_mstkanwil w,dbo_mstperiode p, dbo_statushadiahkanca hc 
			WHERE hc.chrKdKanca=h.chrKdKanca and hc.statusHadiah=2 and hc.chrKdPeriode=h.chrKdPeriode and h.chrKdPeriode='".$periode."' and h.chrKdKanca=k.chrKdKanca and h.chrKdKanwil=w.chrKdKanwil group by kodekanca")->result();
		}

		//kantor wilayah
		public function get_kancaUndianAllkanwilterima($periode,$kodekanwil)
		{
			$this->another = $this->load->database('db1',TRUE);  
			return $this->another->query("SELECT CONVERT(hc.dtmTglPelaksanaan,DATE) as dtmTglPelaksanaan, hc.datemodif,hc.statusHadiah, h.chrKdKanca as kodekanca, h.chrKdPeriode, k.vcrNmKanca, w.vcrNmKanwil,CONVERT( p.dtmTglAwal, DATE ) AS awal, CONVERT( p.dtmTglAkhir, DATE ) AS akhir, h.KeteranganHadiah 
			FROM dbo_statushadiahkanca h, dbo_mstkanca k, dbo_mstkanwil w,dbo_mstperiode p, dbo_statushadiahkanca hc 
			WHERE hc.chrKdKanca=h.chrKdKanca and (hc.statusHadiah=4 or hc.statusHadiah=2 ) and hc.chrKdPeriode=h.chrKdPeriode and h.chrKdPeriode='".$periode."' 
			and h.chrKdKanca=k.chrKdKanca and h.chrKdKanwil='".$kodekanwil."' and h.chrKdKanwil=w.chrKdKanwil group by kodekanca")->result();
		}
		public function get_kancaUndianAllkanwiltolak($periode,$kodekanwil)
		{
			$this->another = $this->load->database('db1',TRUE);  
			return $this->another->query("SELECT CONVERT(hc.dtmTglPelaksanaan,DATE) as dtmTglPelaksanaan,hc.datemodif, hc.statusHadiah, h.chrKdKanca as kodekanca, h.chrKdPeriode, k.vcrNmKanca, w.vcrNmKanwil,CONVERT( p.dtmTglAwal, DATE ) AS awal, CONVERT( p.dtmTglAkhir, DATE ) AS akhir, h.KeteranganHadiah 
			FROM dbo_statushadiahkanca h, dbo_mstkanca k, dbo_mstkanwil w,dbo_mstperiode p, dbo_statushadiahkanca hc 
			WHERE hc.chrKdKanca=h.chrKdKanca and hc.statusHadiah=1 and hc.chrKdPeriode=h.chrKdPeriode 
			and h.chrKdKanwil='".$kodekanwil."' and h.chrKdPeriode='".$periode."' and h.chrKdKanca=k.chrKdKanca and h.chrKdKanwil=w.chrKdKanwil group by kodekanca")->result();
		}
		public function get_kancaUndianAllkanwilpermohonan($periode, $kodekanwil)
		{
			$this->another = $this->load->database('db1',TRUE);  
			return $this->another->query("SELECT CONVERT(hc.dtmTglPelaksanaan,DATE) as dtmTglPelaksanaan,hc.datemodif,hc.statusHadiah, h.chrKdKanca as kodekanca, h.chrKdPeriode, k.vcrNmKanca, w.vcrNmKanwil,CONVERT( p.dtmTglAwal, DATE ) AS awal, CONVERT( p.dtmTglAkhir, DATE ) AS akhir, h.KeteranganHadiah 
			FROM dbo_statushadiahkanca h, dbo_mstkanca k, dbo_mstkanwil w,dbo_mstperiode p, dbo_statushadiahkanca hc 
			WHERE hc.chrKdKanca=h.chrKdKanca and h.chrKdKanwil='".$kodekanwil."' 
			and (hc.statusHadiah=11 or hc.statusHadiah=0) and hc.chrKdPeriode=h.chrKdPeriode and h.chrKdPeriode='".$periode."' and h.chrKdKanca=k.chrKdKanca and h.chrKdKanwil=w.chrKdKanwil group by kodekanca")->result();
		}

		function romanic_number($integer, $upcase = true) 
		{ 
		    $table = array('M'=>1000, 'CM'=>900, 'D'=>500, 'CD'=>400, 'C'=>100, 'XC'=>90, 'L'=>50, 'XL'=>40, 'X'=>10, 'IX'=>9, 'V'=>5, 'IV'=>4, 'I'=>1); 
		    $return = ''; 
		    while($integer > 0) 
		    { 
		        foreach($table as $rom=>$arb) 
		        { 
		            if($integer >= $arb) 
		            { 
		                $integer -= $arb; 
		                $return .= $rom; 
		                break; 
		            } 
		        } 
		    } 

		    return $return; 
		}

		function cek_statushadiah($kodekanca,$idperiode)
		{
				$this->another = $this->load->database('db1',TRUE);  
		
				$ret = '';
				$status = $this->another->query("SELECT * FROM `dbo_statushadiahkanca` WHERE `chrKdKanca` = ".$kodekanca." AND chrKdPeriode = ".$idperiode." limit 1")->result();
				foreach($status as $row) 
		        { 

		            $ret = $row->statusHadiah;
		        } 
		        return $ret;
		
		}

		function cek_keteranganhadiah($kodekanca)
		{
				$this->another = $this->load->database('db1',TRUE);  
		
				$ret = '';
				$status = $this->another->query("SELECT * FROM `dbo_statushadiahkanca` WHERE `chrKdKanca` = ".$kodekanca." limit 1")->result();
				foreach($status as $row) 
		        { 

		            $ret = $row->KeteranganHadiah;
		        } 
		        return $ret;
		
		}

		public function update_kirimulangkanca($id_kanca,$id_kanwil,$data)
		{
			//$cek = $this->cekexisting();

			//$sql = "UPDATE  `brisimpedes_back`.`dbo_statushadiahkanca` 
			//SET  `statusHadiah` =  '2' 
			//WHERE  `dbo_statushadiahkanca`.`chrKdPeriode` =  '022014' AND  `dbo_statushadiahkanca`.`chrKdKanwil` =  '".$id_kanwil."' AND `dbo_statushadiahkanca`.`chrKdKanca` =  '".$id_kanca."'";
			$this->db->set('datemodif', 'NOW()', FALSE); 
			$this->db->where('chrKdKanca', $id_kanca);
			$this->db->where('chrKdKanwil', $id_kanwil);
			$this->db->update('dbo_statushadiahkanca', $data);
		}

		public function simpan_statuskanca($id_kanca,$id_kanwil,$data)
		{
			//$cek = $this->cekexisting();

			//$sql = "UPDATE  `brisimpedes_back`.`dbo_statushadiahkanca` 
			//SET  `statusHadiah` =  '2' 
			//WHERE  `dbo_statushadiahkanca`.`chrKdPeriode` =  '022014' AND  `dbo_statushadiahkanca`.`chrKdKanwil` =  '".$id_kanwil."' AND `dbo_statushadiahkanca`.`chrKdKanca` =  '".$id_kanca."'";
			$this->db->set('datemodif', 'NOW()', FALSE); 
			$this->db->where('chrKdKanca', $id_kanca);
			$this->db->where('chrKdKanwil', $id_kanwil);
			$this->db->insert('dbo_statushadiahkanca', $data);
		}	 
	 

		public function cekexisting($periode, $kanca)
		{
			$sql= "SELECT EXISTS (SELECT * FROM `dbo_statushadiahkanca` WHERE chrKdPeriode='".$periode."' and chrKdKanca='".$kanca."') as exist";
			$data = $this->db->query($sql)->result();
			foreach($data as $row) 
		        { 

		            $ret = $row->exist;
		        } 
		   return $ret;
		}

		public function getTanggalPelaksanaan($periode, $kanca)
		{
			$ret="";
			$sql= "SELECT CONVERT( dtmTglPelaksanaan, DATE ) AS dtmTglPelaksanaan  FROM dbo_statushadiahkanca  WHERE chrKdPeriode='".$periode."' and chrKdKanca='".$kanca."'";
			$data = $this->db->query($sql)->result();
			foreach($data as $row) 
		        { 

		            $ret = $row->dtmTglPelaksanaan;
		        } 
		   return $ret;
		}

		public function simpandistribusi($id_unit,$id_kanca,$id_kanwil,$data)
		{
			$this->distribusi = $this->load->database($id_kanca,TRUE);

			$this->distribusi->where('chrKdUnit', $id_unit);
			$this->distribusi->delete('dbo_dtbhadiahhiburan');
			$this->distribusi->set('dtmUserAdd', 'NOW()', FALSE); 
			$this->distribusi->insert('dbo_dtbhadiahhiburan', $data);

		}

		public function updatedistribusi($id_unit,$id_kanca,$id_kanwil,$data,$periode)
		{
			$this->distribusi = $this->load->database($id_kanca,TRUE);

			$this->distribusi->set('dtmUserEdit', 'NOW()', FALSE); 
			$this->distribusi->where('chrKdUnit', $id_unit);
			$this->distribusi->where('chrKdPeriode', $periode);
			$this->distribusi->update('dbo_dtbhadiahhiburan', $data);
  			
		}



		//CEK EXISTING DATA DISTRIBUSI
		public function existingdistribusi($id_unit,$id_kanca)
		{
			$this->distribusi = $this->load->database($id_kanca,TRUE);
			$sql = "SELECT EXISTS (SELECT `chrKdKanca` FROM `dbo_dtbhadiahhiburan` WHERE `chrKdUnit` ='".$id_unit."') AS ada";
			$existingdata = $this->distribusi->query($sql)->result();
			$ada="";
			foreach ($existingdata as $row) {
				$ada = $row->ada;
			}
			return $ada;

		}
		

		public function getdatadistribusi($id_kanca,$id_kanwil,$tabelhadiah)
		{
			$tabelhadiah = "intHiburan".$tabelhadiah;
			$this->distribusi = $this->load->database($id_kanca,TRUE);		
			$sql="SELECT `chrKdPeriode`,`chrKdKanca`, ".$tabelhadiah." 
			FROM `dbo_dtbhadiahhiburan` 
			WHERE `chrKdKanwil` ='".$id_kanwil."' and `chrKdKanca` ='".$id_kanca."' 
			and `chrKdPeriode` ='022014' order by chrKdUnit ASC";
			return $this->distribusi->query($sql)->result();
		}

		public function getdatadistribusiTamp($id_kanca,$id_kanwil,$tabelhadiah,$periode)
		{
			$tabelhadiah = "intHiburan".$tabelhadiah;
			$this->distribusi = $this->load->database($id_kanca,TRUE);		
			$sql="SELECT `chrKdPeriode`,`chrKdKanca`, `".$tabelhadiah."` as tabel FROM `dbo_dtbhadiahhiburan`
			where `chrKdPeriode` ='".$periode."' order by chrKdUnit ASC";
			return $this->distribusi->query($sql)->result();
		}

		public function getjumlahdistribusi($id_kanca,$id_kanwil,$tabelhadiah,$periode)
		{
			$tabelhadiah = "intHiburan".$tabelhadiah;
			$this->distribusi = $this->load->database($id_kanca,TRUE);		
			$sql="SELECT `chrKdPeriode`,`chrKdKanca`, ".$tabelhadiah." as tabel
			FROM `dbo_dtbhadiahhiburan` 
			WHERE `chrKdKanwil` ='".$id_kanwil."' and `chrKdKanca` ='".$id_kanca."' 
			and `chrKdPeriode` ='".$periode."' order by chrKdUnit ASC";
			return $this->distribusi->query($sql)->result();
		}

		public function getnamahadiah($id_kanca,$hadiah,$periode)
		{	$this->distribusi = $this->load->database('pengundianoffline',TRUE);		
			$sql = "select chrKdKanca, chrJnsHadiah, varJenisHadiah,varTypeHadiah,varMerkHadiah ,(intJmlhadiah -(SELECT COUNT(`chrJnsHadiah`) as jumlah FROM dbo_dtldaftarpemenang where `chrJnsHadiah`='".$hadiah."' and chrKdPeriode = '".$periode."' )) as intJmlhadiah from dbo_msthadiahkanca where chrKdPeriode = '".$periode."' and chrJnsHadiah=".$hadiah."";
			
			return $this->distribusi->query($sql)->result();


		}

		//get undian
		public function get_nomorundian($id_kanca)
		{	$this->distribusi = $this->load->database($id_kanca,TRUE);		
			$sql = "SELECT * FROM dbo_tampnoundian e WHERE NOT EXISTS ( SELECT null FROM `dbo_dtldaftarpemenang` d WHERE d.chrNoRek = e.NoRek )";		
			//$sql = "SELECT * FROM dbo_tampnoundian";		
			
			return $this->distribusi->query($sql)->result();
		}

		//model hitung pemenang tiap hadiah
		public function get_jumlahPemenangUndian($idkanca, $chrjenishadiah,$periode)
		{
			$this->distribusi = $this->load->database('pengundianoffline',TRUE);		
			$sql = "SELECT count(`kodeUker`) as jumlah FROM `dbo_dtldaftarpemenang` WHERE `chrJnsHadiah`= ".$chrjenishadiah." and `chrKdPeriode`='".$periode."' group by chrJnsHadiah";
			$jumlah = $this->distribusi->query($sql)->result();
			$tot=0;
			foreach ($jumlah as $row) {
				$tot= $row->jumlah;
			}
			return $tot;

		}
		//model hitung pemenang tiap hadiah
		function pemenangTiapHadiah($kodeperiode,$idkanca)
		{
				$this->kanca = $this->load->database('pengundianoffline',TRUE);  
				return $this->kanca->query("SELECT p.chrJnsHadiah FROM dbo_dtldaftarpemenang p , dbo_msthadiahkanca k, dbo_msthadiahperiod m  WHERE p.chrJnsHadiah = k.chrJnsHadiah and p.chrKdPeriode='".$kodeperiode."' and m.chrKdHadiah=k.chrJnsHadiah group by p.chrJnsHadiah order by chrJnsHadiah ASC")->result();
		}

		function laporanAprovalPemenang($kodeperiode,$idkanca)
		{
			$this->kanca = $this->load->database('pengundianoffline',TRUE);  
			$sql ="SELECT `chrPngJwb1` FROM `dbo_mstpelengkapundian` WHERE `chrKdPeriode`='".$kodeperiode."'";
			$datanama = $this->kanca->query($sql)->result();
			$nama='';

			foreach ($datanama as $row) {
				$nama=$row->chrPngJwb1;
			}
			return $nama;
		}

				//undian waktu selisih
		public function selisihwaktuundian($idkanca, $periode)
		{
			$sql = "SELECT TIMESTAMPDIFF(SECOND,now(),(SELECT dtmTglPelaksanaan FROM `dbo_statushadiahkanca` WHERE `chrKdKanca`='".$idkanca."' and `chrKdPeriode`='".$periode."')) as selisih";
			$ada 	= $this->db->query($sql)->result();
			$waktu 	= 0;
			foreach ($ada as $row) {
					$waktu = $row->selisih;
			}

			if($waktu>-86400)
			{
				$waktu = $waktu + 86400;
			}
			return $waktu;
			$this->db->close();
			
			$this->db->close();
		}

		//cek status hadiah untuk dashboard
		public function statusHadiahDepan($idkanca, $idperiode)
		{
			$sql = "SELECT `statusHadiah` FROM `dbo_statushadiahkanca` WHERE `chrKdPeriode`='".$idperiode."' and `chrKdKanca` = '".$idkanca."'";
			$ada 	= $this->db->query($sql)->result();
			foreach ($ada as $row) {
					return $row->statusHadiah;
			}
			$this->db->close();

		}

		public function cek_distribusihadiahhiburanada($idperiode,$idkanca)
		{
			$this->db_kanca = $this->load->database('pengundianoffline',TRUE);  
			$sql 	= "SELECT exists(select null FROM `dbo_dtbhadiahhiburan` WHERE `chrKdPeriode`='".$idperiode."') as ada";
			$ada	= $this->db_kanca->query($sql)->result();
			foreach ($ada as $row) {
				return $row->ada;
			}
         	$this->db_kanca->close();
			
		}

			public function get_data_idjenishadiah($idperiode,$idkanca)
		{
			$this->db_kanca = $this->load->database('pengundianoffline',TRUE);  
			$sql = "SELECT `chrJnsHadiah`,`chrKdPeriode`,`varJenisHadiah` FROM `dbo_msthadiahkanca` WHERE `chrKdPeriode`='".$idperiode."' and `chrJnsHadiah`>80";
			return $this->db_kanca->query($sql)->result();
           	$this->db_kanca->close();

		}

		public function distribusi_hadiah_hiburan($idperiode,$idkanca,$idjenishadiah)
		{
				$this->db_kanca = $this->load->database('pengundianoffline',TRUE);  
		//SELECT k.chrKdPeriode, k.varJenisHadiah, k.varTypeHadiah, k.varMerkHadiah, k.chrJnsHadiah,k.intJmlhadiah,(select count(chrKdUnit) FROM dbo_dtbhadiahhiburan where chrKdPeriode ='022014') as jumlahunit,(select sum(intHiburan81) FROM dbo_dtbhadiahhiburan where chrKdPeriode ='022014') as ditribusi FROM dbo_msthadiahkanca k, dbo_dtbhadiahhiburan dh where k.chrKdPeriode ='022014' AND k.chrJnsHadiah ='81' limit 1 

			$sql = 'SELECT k.chrKdPeriode, k.varJenisHadiah, k.varTypeHadiah, k.varMerkHadiah, k.chrJnsHadiah,k.intJmlhadiah,(select sum(intHiburan'.$idjenishadiah.') FROM dbo_dtbhadiahhiburan where chrKdPeriode ='.$idperiode.') as ditribusi, (select count(chrKdUnit) FROM dbo_dtbhadiahhiburan where chrKdPeriode ='.$idperiode.') as jumlahunit 
			FROM dbo_msthadiahkanca k, dbo_dtbhadiahhiburan dh
           	where k.chrKdPeriode      ='.$idperiode.' AND k.chrJnsHadiah   ='.$idjenishadiah.' limit 1'; 
   			return $this->db_kanca->query($sql)->result();

           	$this->db_kanca->close();

		}

		public function datasupervisi($idkanca)
		{
			$sql = "SELECT idsuvervisi,chrKdKanca,`chrKdUnit`,`vcrNmUnit`,`dtmUserEdit`,`idKancaAwal`,`Status`,BRDESC FROM `dbo_supervisikanca` sk, dbo_dwh_branch dw WHERE `chrKdKanca`='".$idkanca."' and (Status='1' or Status='2') and BRANCH=idKancaAwal order by dtmUserEdit DESC";
			return $this->db->query($sql)->result();
			$this->db->close();
		}


		//add laporan
		public function penanggungjawabPemenang($kodeperiode,$idkanca)
		{
			$this->kanca = $this->load->database('pengundianoffline',TRUE);  
		//	$sql ="SELECT * FROM `dbo_mstpelengkapundian` WHERE `chrKdPeriode`='".$kodeperiode."'";
			$sql ="SELECT 
			`chrPngJwb1`,`chrJbtPj1`,
			`chrPngJwb2`,`chrJbtPj2`,
			`chrNotaris`,`chrJbtN`,
			`chrSaksi1`,`chrJbtS1`, 
			`chrSaksi2`,`chrJbtS2`,
			`chrSaksi3`,`chrJbtS3`
			FROM `dbo_mstpelengkapundian`";
			$datanama = $this->kanca->query($sql)->result();
			return $datanama;
			$this->kanca->close();

		}










	

}
?>
