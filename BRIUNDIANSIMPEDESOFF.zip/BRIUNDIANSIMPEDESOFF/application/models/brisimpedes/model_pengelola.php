<?php

class model_pengelola extends CI_Model
{
	
		function data_pengelola_tampilkan($idkanca){
			$this->pengelola = $this->load->database($idkanca,TRUE);
  			return $this->pengelola->query('SELECT * FROM `dbo_mstpelengkapundian` WHERE 1')->result();
		}

		function data_pengelola_tampilkan_periode($idkanca,$periode){
			$this->pengelola = $this->load->database($idkanca,TRUE);
  			return $this->pengelola->query("SELECT * FROM `dbo_mstpelengkapundian` WHERE chrKdPeriode ='".$periode."' ")->result();
		}



		function data_seleksi($nomorkupon,$idkanca){
			$this->another = $this->load->database('db1',TRUE);  
			return $this->db->query('SELECT * FROM ``dbo_dtbkuponutamadtl`` WHERE `numAwl01` <= '.$nomorkupon.' AND `numAkh01` >='.$nomorkupon.' OR (`numAwl02` <= '.$nomorkupon.' AND `numAkh02` >= '.$nomorkupon.') OR (`numAwl03` <= '.$nomorkupon.' AND `numAkh03` >= '.$nomorkupon.') OR (`numAwl04` <= '.$nomorkupon.' AND `numAkh04` >= '.$nomorkupon.') OR (`numAwl05` <= '.$nomorkupon.' AND `numAkh05` >= '.$nomorkupon.') OR (`numAwl06` <= '.$nomorkupon.' AND `numAkh06` >= '.$nomorkupon.')')->result();
		}


		function data_kupon_tampilkan10(){
			return $this->db->query('SELECT * FROM `dbo_dtbkuponutamadtl` ORDER BY RAND() limit 10 ')->result();
		}

		function seleksi_data_kuponBiasa($kupon){
			return $this->db->query('SELECT * FROM `dbo_dtbkuponutamadtl` ORDER BY RAND() limit 10 ')->result();
		}

		function jumlah_hadiah_biasa(){
			return $this->db->query('SELECT max( `numAkh06` ) as max FROM `dbo_dtbkuponutamadtl`')->result();
		}

		function savedatapengelola($insert,$idperiode,$idkanca){
			$this->another = $this->load->database($idkanca,TRUE);  
			
			$exist="SELECT EXISTS (SELECT * FROM `dbo_mstpelengkapundian` WHERE chrKdPeriode='".$idperiode."') as ok";
			$data=$this->another->query($exist)->result();
			$flag ="";

			foreach ($data as $row) {
				$flag =$row->ok;
				# code...
			}
			if($flag==0)
			{
  				return $this->another->insert('dbo_mstpelengkapundian',$insert);
			}
			else if ($flag==1) 
			{
				$this->another->where('chrKdPeriode',$idperiode);
				return $this->another->update('dbo_mstpelengkapundian',$insert);

			}

		
			//return $this->db->query('SELECT * FROM ``dbo_dtbkuponutamadtl`` WHERE `numAwl01` <= '.$nomorkupon.' AND `numAkh01` >='.$nomorkupon.' OR (`numAwl02` <= '.$nomorkupon.' AND `numAkh02` >= '.$nomorkupon.') OR (`numAwl03` <= '.$nomorkupon.' AND `numAkh03` >= '.$nomorkupon.') OR (`numAwl04` <= '.$nomorkupon.' AND `numAkh04` >= '.$nomorkupon.') OR (`numAwl05` <= '.$nomorkupon.' AND `numAkh05` >= '.$nomorkupon.') OR (`numAwl06` <= '.$nomorkupon.' AND `numAkh06` >= '.$nomorkupon.')')->result();
		}

		function hapus_pengelola($idkanca,$id_periode)
		{
			$this->db_kanca = $this->load->database($idkanca,TRUE);  
			
			$this->db_kanca->where('chrKdPeriode', $id_periode);
			return $this->db_kanca->delete('dbo_mstpelengkapundian');
		}

	

}
?>