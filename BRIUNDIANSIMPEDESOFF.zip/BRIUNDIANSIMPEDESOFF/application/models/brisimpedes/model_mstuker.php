<?php

class model_mstuker extends CI_Model
{
	  	private $another;
  		function __construct()
  		{ 
    		parent::__construct();
    		$this->another = $this->load->database('db1',TRUE);
  		}
	
		function data_unit($id_kanca){
			return $this->another->query("SELECT * FROM `dbo_mstunit` WHERE `chrKdKanca` = '".$id_kanca."' order by chrKdUnit ASC ")->result();
		}

		function data_unitcari($id_kanca,$unit){
			return $this->another->query("SELECT * FROM `dbo_mstunit` WHERE `chrKdKanca` = '".$id_kanca."' and `vcrNmUnit` like '%".$unit."%' order by chrKdUnit ASC ")->result();
		}


		function data_provinsi(){
			return $this->another->query("SELECT `chrKdProp` , `chrNmProp` FROM `dbo_mstprop` WHERE 1")->result();
		}

		function data_kab($id){
			return $this->another->query("SELECT `chrKdKab`, `chrNmKab` FROM `dbo_mstkab` WHERE `chrKdProp` = '".$id."';")->result();
		}


		function data_kanwil(){
			return $this->another->query("SELECT `chrKdKanwil`,`vcrNmKanwil` FROM `dbo_mstkanwil` WHERE 1")->result();
		}




		function getdata_unit($id,$id_kanca){
			$getdataunit = $this->another->query(
				"SELECT *
				FROM `dbo_dwh_branch`
				WHERE `SUBBR` = '".$id."' and
				`MAINBR` = '".$id_kanca."'
				LIMIT 1")->result();			 
				return $getdataunit;
		}

		function getdata_frommstunit($id,$id_kanca){
			$getdataunit = $this->another->query(
				"SELECT * FROM dbo_mstunit 
				WHERE chrKdKanca ='".$id_kanca."' and 
				chrKdUnit = '".$id."'
				")->result();			 
				return $getdataunit;
		}


		function getdata_namaunit($id){
			$getdataunit = $this->another->query("SELECT * FROM `dbo_mstunit` WHERE `chrKdUnit`=".$id."")->result();			 
				return $getdataunit;
		}

		public function add_uker($insert,$update,$kanca,$uker)
		{
			$exist="SELECT EXISTS (select chrKdKanca FROM `dbo_mstunit` WHERE chrKdKanca='".$kanca."' and chrKdUnit='".$uker."') as ok";
			$data=$this->another->query($exist)->result();
			$flag ="";

			foreach ($data as $row) {
				$flag =$row->ok;
				# code...
			}

			if($flag=0)
			{
				$this->another->insert('dbo_mstunit',$insert);
			}
			else if($flag=1)
			{
					$this->another->where('chrKdUnit', $uker);
					//$this->another->where('chrKdKanca',$kanca);
					$this->another->update('dbo_mstunit', $update);
					//$this->another->insert('dbo_mstunit',$update);
			}



		}

		public function delete_uker($id_kanca, $id_uker)
		{
			$this->another->where('chrKdUnit', $id_uker);
			$this->another->where('chrKdKanca',$id_kanca);
			$this->another->delete('dbo_mstunit');
		}
		 
		public function update_uker($id_kanca, $id_uker, $update)
		{
			$this->another->where('chrKdUnit', $id_uker);
			$this->another->where('chrKdKanca',$id_kanca);
			$this->another->update('dbo_mstunit', $update);
		}

		function tmpbanyakperiode(){
			return $this->another->query("SELECT * FROM `dbo_msthadiahperiod` WHERE 1")->result();
			//return $this->db->query('SELECT * FROM `dbo_tmpbanyakperiode`')->result();
		}

	//jumlah unit yang sudah supervisi
		public function jumlahunitsupervisi($idkanca)
		{
			$this->db->where('chrKdKanca',$idkanca);
			$this->db->from('dbo_mstunit');
			return $this->db->count_all_results();
			$this->db->close();
		}

		//jumlah unit distribusi
		public function jumlahunitdistriusi($idkanca,$idperiode)
		{
    		$this->db_kanca = $this->load->database('pengundianoffline',TRUE);
			$this->db_kanca->where('chrKdPeriode',$idperiode);
			$this->db_kanca->from('dbo_dtbhadiahhiburan');
			return $this->db_kanca->count_all_results();
			$this->db_kanca->close();
		}

		public function jumlahunitdistriusi_hadiah($idkanca,$idperiode,$hadiah)
		{
    		$this->db_kanca = $this->load->database('pengundianoffline',TRUE);
			$this->db_kanca->where('chrKdPeriode',$idperiode);
			$this->db_kanca->where('intHiburan'.$hadiah,'1');
			$this->db_kanca->from('dbo_dtbhadiahhiburan');
			return $this->db_kanca->count_all_results();
			$this->db_kanca->close();
		}


				//data aproval supervisi unit kerja
		public function dataCariaprovalsupervisi_from_mstunit($iduker)
		{
			$sql = "SELECT * FROM `dbo_mstunit` WHERE `chrKdUnit`='".$iduker."'";
			return $this->db->query($sql)->result();
			$this->db->close();
		}

		public function simpan_pemenangHadiahHiburan($id_kanca,$data)
		{
			$this->db_kanca = $this->load->database('pengundianoffline',TRUE);  
			$this->db_kanca->set('dtmTglAdd', 'NOW()', FALSE); 
			return $this->db_kanca->insert('dbo_dtldaftarpemenang', $data);
			$this->db_kanca->close();

		}

		public function simpan_pemenangHadiah_multidraw($id_kanca,$data)
		{
			$this->db_kanca = $this->load->database('pengundianoffline',TRUE);  
			$this->db_kanca->set('dtmTglAdd', 'NOW()', FALSE); 
			return $this->db_kanca->insert('dbo_dtldaftarpemenang', $data);
			$this->db_kanca->close();

		}





		





	

}
?>