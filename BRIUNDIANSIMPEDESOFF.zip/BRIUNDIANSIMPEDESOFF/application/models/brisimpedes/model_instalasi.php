<?php

class model_instalasi extends CI_Model
{

	  	private $database;
  		function __construct()
  		{ 
    		parent::__construct();
   			$this->load->dbutil();
  		}
	
	
		function cekdatabase(){
    	//	$this->$database = $this->load->dbutil();
		
			if ($this->dbutil->database_exists('pengundianoffline'))
				{
					return '1';
				} 
			else
				{
					return '0';

				}

		}

		function cekdatabasetabel(){
    	//	$this->$database = $this->load->dbutil();
		
			if ( $this->db->table_exists('dbo_dtlNomorRekening') )
				{
					return '1';
				} 
			else
				{
					return '0';

				}

		}


}
?>
