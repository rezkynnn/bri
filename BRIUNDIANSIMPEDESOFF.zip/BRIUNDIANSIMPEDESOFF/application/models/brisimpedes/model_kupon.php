<?php

class model_kupon extends CI_Model
{
	
		function data_kupon_tampilkan(){
			return $this->db->query('SELECT * FROM `dbo_dtbkuponutamadtl` limit 10,20 ')->result();
		}


		function data_seleksi($nomorkupon,$idkanca){
			$this->another = $this->load->database('db1',TRUE);  
			return $this->db->query('SELECT * FROM ``dbo_dtbkuponutamadtl`` WHERE `numAwl01` <= '.$nomorkupon.' AND `numAkh01` >='.$nomorkupon.' OR (`numAwl02` <= '.$nomorkupon.' AND `numAkh02` >= '.$nomorkupon.') OR (`numAwl03` <= '.$nomorkupon.' AND `numAkh03` >= '.$nomorkupon.') OR (`numAwl04` <= '.$nomorkupon.' AND `numAkh04` >= '.$nomorkupon.') OR (`numAwl05` <= '.$nomorkupon.' AND `numAkh05` >= '.$nomorkupon.') OR (`numAwl06` <= '.$nomorkupon.' AND `numAkh06` >= '.$nomorkupon.')')->result();
		}


		function data_kupon_tampilkan10(){
			return $this->db->query('SELECT * FROM `dbo_dtbkuponutamadtl` ORDER BY RAND() limit 10 ')->result();
		}

		function seleksi_data_kuponBiasa($kupon){
			return $this->db->query('SELECT * FROM `dbo_dtbkuponutamadtl` ORDER BY RAND() limit 10 ')->result();
		}

		function jumlah_hadiah_biasa(){
			return $this->db->query('SELECT max( `numAkh06` ) as max FROM `dbo_dtbkuponutamadtl`')->result();
		}

		//data cari kupon
		function data_cariKupon($idkanca,$nomorrek, $periode){
			$this->db_kanca = $this->load->database($idkanca,TRUE);
			return $this->db_kanca->query("SELECT * FROM dbo_dtlnomorundian du WHERE du.NoRek='".$nomorrek."' and du.chrKdPeriode='".$periode."'")->result();
		}

		//data get nomor rekening dari undian
		function data_cariKupondtl($idkanca, $indexUndian, $periode){
			$nomorUndian = '';
			$this->db_kanca = $this->load->database($idkanca,TRUE);
			//$nomorudiantmp = $this->db_kanca->query("SELECT * FROM dbo_tampnoundian e WHERE NOT EXISTS ( SELECT null FROM `dbo_dtldaftarpemenang` d WHERE d.chrNoRek = e.NoRek) limit ".$indexUndian.",1  ")->result();
			$sql = "SELECT NoUndianSemuaUnit FROM `dstNoUndian_".$periode."` WHERE (`pemenang`=0 or `pemenang` IS NULL) limit ".$indexUndian.",1";
			$nomorudiantmp = $this->db_kanca->query($sql)->result();
				foreach ($nomorudiantmp as $row ) {
					$nomorUndian = $row->NoUndianSemuaUnit;
				}
			return $nomorUndian;

		}

		//data hadiah kupon tiap kanca
		/*
		function data_cariKuponkanca($idkanca, $periode){
			$this->db_kanca = $this->load->database('pengundianoffline',TRUE);
			$sql = "SELECT `kodeUker`, `kodeBulan`,`NoRek`,`KuponAwal`, `KuponAkhir`, `chrKdPeriode`,
					CONCAT(`kodeUker`,`kodeBulan`) as kode,
					(select max(KuponAkhir) from dbo_dtlnomorundian a where a.kodeUker = i.kodeUker ) 
					as jumlahmax FROM `dbo_dtlnomorundian` i where `chrKdPeriode`='".$periode."' group by kodeuker";

			return $this->db_kanca->query($sql)->result();
		}
		*/


				//data hadiah kupon tiap kanca
		function data_cariKuponkanca($idkanca, $periode,$kodeBulan){
			$this->db_kanca = $this->load->database("pengundianoffline",TRUE);
			/*
			$sql = "SELECT `kodeUker`,vcrNmUnit,`kodeBulan`,`NoRek`,`KuponAwal`, `KuponAkhir`, `chrKdPeriode`, 
			CONCAT(`kodeUker`,`kodeBulan`) as kode, 
			(select max(KuponAkhir) from dbo_dtlnomorundian a 
			where a.kodeUker = i.kodeUker ) as jumlahmax 
			FROM `dbo_dtlnomorundian` i,dbo_mstunit u where `chrKdPeriode`='".$periode."' and u.chrKdUnit=i.kodeUker group by kodeuker"; 
			*/
			$sql = "select kodeUker.kodeUker,vcrNmUnit,kodeUker.kodeBulan,
					(select max(KuponAkhir) from dbo_dtlnomorundian c
					where c.kodeUker = kodeUker.kodeUker and `chrKdPeriode`='".$periode."' and kodeBulan ='".$kodeBulan."') as jumlahmax 
					from 
					(SELECT `kodeUker`,kodeBulan
					FROM `dbo_dtlnomorundian` a 
					where kodeBulan ='".$kodeBulan."'
					group by kodeUker) kodeUker
					inner join dbo_mstunit b
					on  kodeUker.kodeUker = b.chrKdUnit";


//			$sql = "SELECT `kodeUker`, `kodeBulan`,`NoRek`,`KuponAwal`, `KuponAkhir`, `chrKdPeriode`,
//					CONCAT(`kodeUker`,`kodeBulan`) as kode,
//					(select max(KuponAkhir) from dbo_dtlnomorundian a where a.kodeUker = i.kodeUker ) 
//					as jumlahmax FROM `dbo_dtlnomorundian` i where `chrKdPeriode`='".$periode."' group by kodeuker";

			return $this->db_kanca->query($sql)->result();
			$this->db_kanca->close();
		}
	
		//pagination
		function data_show_all_Kupon_pag($idkanca, $periode,$awal , $akhir){
			$this->db_kanca = $this->load->database('pengundianoffline',TRUE);
			return $this->db_kanca->query("SELECT * FROM dbo_dtlnomorundian du WHERE du.chrKdPeriode='".$periode."' order by namaNasabah ASC limit ".$awal.",".$akhir." ")->result();
			$this->db_kanca->close();
		}



		function data_show_all_Kupon_jumlah($idkanca, $periode){
			$this->db_kanca = $this->load->database('pengundianoffline',TRUE);
			$data =  $this->db_kanca->query("SELECT count(du.NoRek) as jumlah FROM dbo_dtlnomorundian du WHERE du.chrKdPeriode='".$periode."'")->result();
			foreach ($data as $row) {
				return $row->jumlah;
				# code...
			}
			$this->db_kanca->close();
		}

		function data_show_all_Kupon($idkanca, $periode){
			$this->db_kanca = $this->load->database('pengundianoffline',TRUE);
			return $this->db_kanca->query("SELECT * FROM dbo_dtlnomorundian  WHERE chrKdPeriode='".$periode."' order by namaNasabah ASC")->result();
			$this->db_kanca->close();
		}






	

}
?>
