<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
	class model_undian extends CI_Model {

		//tanggal diperbarui 08 SEPTEMBER 2015
		public function index()
		{
			parent::__construct();
		}
		
		public function get_undian_hadiahumum($idkanca,$periode)
		{
			$sql="SELECT k.chrKdPeriode, k.chrJnsHadiah,k.vcrNamaHadiah,p.chrNmHadiah FROM dbo_msthadiahkanca k, dbo_msthadiahperiod p WHERE chrJnsHadiah<80 and p.chrKdHadiah=k.chrJnsHadiah AND k.chrKdPeriode ='".$periode."' group by k.chrJnsHadiah";
			return $this->db->query($sql)->result();
			$this->db->close();
		}

		public function get_undian_hadiahHiburan($idkanca,$periode)
		{
			$sql="SELECT k.chrKdPeriode, k.chrJnsHadiah,k.vcrNamaHadiah,p.chrNmHadiah FROM dbo_msthadiahkanca k, dbo_msthadiahperiod p WHERE chrJnsHadiah>80 and p.chrKdHadiah=k.chrJnsHadiah AND k.chrKdPeriode ='".$periode."' group by k.chrJnsHadiah";
			return $this->db->query($sql)->result();
			$this->db->close();
	}
	

		function data_exel_hadiahPerPeriode($idperiode){
			return $this->db->query(
			"SELECT sk.statusHadiah, k.potonganHarga, h.chrKdPeriode,k.chrKdKanwil,k.chrKdKanca,b.MBDESC as kanwil,b.RGDESC as kanca, k.varJenisHadiah as varJenisHadiah, k.varTypeHadiah, k.varMerkHadiah,k.hargaSatuan,k.tahunPembuatan,k.varKondisiPembuatan, k.statusHadiah,CONVERT( h.dtmTglAwal, DATE ) AS awal, CONVERT( h.dtmTglAkhir, DATE ) AS akhir, vcrNamaHadiah as nama, chrNmHadiah as jenishadiah, intJmlhadiah as jumlah, chrKdHadiah as kode
			FROM dbo_mstperiode h, dbo_msthadiahkanca k, dbo_msthadiahperiod p, dbo_dwh_branch b ,dbo_statushadiahkanca sk
			WHERE h.chrKdPeriode = k.chrKdPeriode
			AND k.chrKdPeriode = p.chrKdPeriode
			AND k.chrJnsHadiah = p.chrKdHadiah
			AND k.chrKdPeriode = '".$idperiode."'
			AND sk.chrKdKanca = k.chrKdKanca	
            AND b.REGION = k.chrKdKanwil
            AND b.MAINBR = k.chrKdKanca
            AND sk.statusHadiah = 4
            group by nama
                        ")->result();
			$this->db->close();

		}
		function data_exel_hadiahAllPeriode(){
			return $this->db->query(
			"SELECT h.chrKdPeriode,k.chrKdKanwil,k.chrKdKanca,b.MBDESC as kanwil,b.RGDESC as kanca, k.varJenisHadiah as varJenisHadiah, k.varTypeHadiah, k.varMerkHadiah,k.hargaSatuan,k.tahunPembuatan,k.varKondisiPembuatan, k.statusHadiah,CONVERT( h.dtmTglAwal, DATE ) AS awal, CONVERT( h.dtmTglAkhir, DATE ) AS akhir, vcrNamaHadiah as nama, chrNmHadiah as jenishadiah, intJmlhadiah as jumlah, chrKdHadiah as kode
			FROM dbo_mstperiode h, dbo_msthadiahkanca k, dbo_msthadiahperiod p, dbo_dwh_branch b
			WHERE h.chrKdPeriode = k.chrKdPeriode
			AND k.chrKdPeriode = p.chrKdPeriode
			AND k.chrJnsHadiah = p.chrKdHadiah
			AND b.REGION = k.chrKdKanwil
            AND b.MAINBR = k.chrKdKanca
            group by nama
                        ")->result();
			$this->db->close();

		}

		public function get_transfernomorundian($idkanca)
		{
			$this->db_kanca = $this->load->database('pengundianoffline',TRUE);  
			$sql="SELECT * FROM `dbo_dtlnomorundian` WHERE 1";
			return $this->db_kanca->query($sql)->result();
			$this->db_kanca->close();
		}

		public function get_transfernomorundianPeriode($idkanca,$periode)
		{
			$this->db_kanca = $this->load->database('pengundianoffline',TRUE);  
			$sql="SELECT * FROM `dbo_dtlnomorundian` WHERE chrKdPeriode='".$periode."'";
			return $this->db_kanca->query($sql)->result();
			$this->db_kanca->close();

		}

		public function get_nilaimax($idkanca)
		{
			$this->db_kanca = $this->load->database('pengundianoffline',TRUE);  
			$sql="SELECT COUNT(`NoUrutan`) as maxnum FROM dbo_tampnoundian e where NOT EXISTS ( SELECT null FROM `dbo_dtldaftarpemenang` d WHERE d.chrNoRek = e.NoRek )";
			//$sql="SELECT COUNT(`NoUrutan`) as maxnum FROM dbo_tampnoundian ";
			
			$maximum = $this->db_kanca->query($sql)->result();
			$max=0;
			
			foreach ($maximum as $row) {
				$max = $row->maxnum;
			}

			return $max;
			$this->db_kanca->close();
		}



		public function get_nilaimaxKuponPeriode($idkanca,$periode)
		{
			$this->db_kanca = $this->load->database('pengundianoffline',TRUE);  
			$sql="SELECT COUNT(`NoUndianSemuaUnit`) as maxnum FROM `dstNoUndian_".$periode."`";
			//$sql="SELECT COUNT(`NoUrutan`) as maxnum FROM dbo_tampnoundian ";
			
			$maximum = $this->db_kanca->query($sql)->result();
			$max=0;
			
			foreach ($maximum as $row) {
				$max = $row->maxnum;
			}

			return $max;
			$this->db_kanca->close();
		}





		public function insert_noAllundian($idkanca,$insert)
		{
			$this->db_kanca = $this->load->database('pengundianoffline',TRUE);  
			$this->db_kanca->insert('dbo_tampnoundian',$insert);
			$this->db_kanca->close();
		}

		//insert tabel distribusi per periode
		public function insert_noAllundianTabelPeriode($idkanca,$insert,$periode)
		{
			$this->db_kanca = $this->load->database('pengundianoffline',TRUE);  
			$this->db_kanca->insert('dstNoUndian_'.$periode,$insert);
			$this->db_kanca->close();
		}

		public function closedonconection($idkanca)
		{
		//	$this->db_kanca = $this->load->database($idkanca,TRUE);  
		//	$this->db_kanca->close();  
		}

		public function get_namaukerundian($idkanca,$iduker)
		{
			$this->db_kanca = $this->load->database('pengundianoffline',TRUE);  
			$sql="SELECT * FROM `dbo_mstunit` where chrKdUnit = '".$iduker."'";
			$namauker= $this->db->query($sql)->result();
			$namaukertamp="hay";
			foreach ($namauker as $row) {
				$namaukertamp = $row->vcrNmUnit;
			}
			return $namaukertamp;
			$this->db_kanca->close();
		}

		public function get_namauker($idkanca)
		{
			$this->db_kanca = $this->load->database('pengundianoffline',TRUE);  
			$sql="SELECT * FROM `dbo_mstunit`";
			$namauker= $this->db->query($sql)->result();
			$namaukertamp="hay";
			foreach ($namauker as $row) {
				$namaukertamp = $row->vcrNmUnit;
			}
			return $namaukertamp;
			$this->db_kanca->close();
		}


		public function get_namarekening($idkanca,$norek)
		{
			$this->db_kanca = $this->load->database('pengundianoffline',TRUE);  
			$sql="SELECT * FROM `dbo_dtlNomorRekening` WHERE `NoRek`='".$norek."'";
			$nama= $this->db_kanca->query($sql)->result();
			$namanas="";
			foreach ($nama as $row) {
				$namanas = $row->namaNasabah;
			}
			return $namanas;
		}

		public function simpan_pemenang($id_kanca,$data)
		{
			$this->db_kanca = $this->load->database('pengundianoffline',TRUE);  
			$this->db_kanca->set('dtmTglAdd', 'NOW()', FALSE); 
			return $this->db_kanca->insert('dbo_dtldaftarpemenang', $data);
			$this->db_kanca->close();
		}

		public function simpan_noacakUndian($idkanca,$norek)
		{
			$this->db_kanca = $this->load->database('pengundianoffline',TRUE);  
			$sql="SELECT * FROM `dbo_tampnoundian` WHERE `NoRek`='".$norek."'";
			$nomor= $this->db_kanca->query($sql)->result();
			$a= '';
			foreach ($nomor as $row) {
			$insert = array(
			'noAcak' => $row->NoUrutan		
			);

			$a= $this->db_kanca->insert('dbo_tampnoundianback', $insert);
			}
			return $a;
			$this->db_kanca->close();
		}


		public function get_maxundiandaridtlnomorundian($idkanca)
		{
			$this->db_kanca = $this->load->database('pengundianoffline',TRUE);  
			$sql="SELECT SUM(`KuponAkhir`-`KuponAwal`) as jumlah_kupon FROM `dbo_dtlnomorundian` WHERE 1 ";
			$jumlah= $this->db_kanca->query($sql)->result();
			$jumlah_tot="";
			foreach ($jumlah as $row) {
				$jumlah_tot = $row->jumlah_kupon;
			}
			return $jumlah_tot;
			$this->db_kanca->close();
		}

		public function get_maxundiandaridtlnomorundianPeriode($idkanca,$periode)
		{
			$this->db_kanca = $this->load->database('pengundianoffline',TRUE);  
			$sql="SELECT SUM((`KuponAkhir`-`KuponAwal`)+1) as jumlah_kupon FROM `dbo_dtlnomorundian` WHERE chrKdPeriode='".$periode."'";
			$jumlah= $this->db_kanca->query($sql)->result();
			$jumlah_tot="";
			foreach ($jumlah as $row) {
				$jumlah_tot = $row->jumlah_kupon;
			}
			return $jumlah_tot;
			$this->db_kanca->close();
		}


		public function truncate_dbo_tampnoundian($idkanca)
		{
			$this->db_kanca = $this->load->database('pengundianoffline',TRUE);
			return $this->db_kanca->truncate('dbo_tampnoundian');
			$this->db_kanca->close();

//			$sql="TRUNCATE dbo_tampnoundian";
//			$jumlah= $this->db_kanca->query($sql)->result();
		}

		public function truncate_dstNoUndian($idkanca,$periode)
		{
			$this->db_kanca = $this->load->database('pengundianoffline',TRUE);
			return $this->db_kanca->truncate("`dstNoUndian_".$periode."`");
			$this->db_kanca->close();		
		}


	//data tampung untuk pengundian get dan insert
		public function undian_banyak($idkanca)
		{
			$this->db_kanca = $this->load->database('pengundianoffline',TRUE);
			$hapus= $this->db_kanca->truncate('dbo_tampnoundianback');
			if($hapus==1)
			{				
				$sql="SELECT `NoUndianSemuaUnit`,`noRek` FROM `dbo_tampnoundian` WHERE 1 ";
				$insert= $this->db_kanca->query($sql)->result();
				if($insert)
				{
					foreach ($insert as $row) {
						$this->db_kanca->insert('dbo_tampnoundianback', $row);
					}

					return 1; 
				}

			}
			$this->db_kanca->close();
		}

		//get data no pemenang
		public function noacakpemenang($idkanca)
		{
			$this->db_kanca = $this->load->database('pengundianoffline',TRUE);  
			$sql="SELECT * FROM `dbo_tampnoundianback` WHERE 1";
			return $this->db_kanca->query($sql)->result();
			$this->db_kanca->close();

		}

		//parameter downlod kupon untuk distriusi undian kupon

		public function get_nilaimaxKuponMasuk($idkanca,$periode)
		{
			$this->db_kanca = $this->load->database('pengundianoffline',TRUE);  
			$sql="SELECT COUNT(`NoUndianSemuaUnit`) as maxnum FROM `dstNoUndian_".$periode."`";
			//$sql="SELECT COUNT(`NoUrutan`) as maxnum FROM dbo_tampnoundian ";
			
			$maximum = $this->db_kanca->query($sql)->result();
			$max=0;
			
			foreach ($maximum as $row) {
				$max = $row->maxnum;
			}

			return $max;
			$this->db_kanca->close();
		}


		function data_cekUndianDistribusi($idkanca, $indexUndian)
		{
			$this->db_kanca = $this->load->database('pengundianoffline',TRUE);
			$sql = "SELECT * FROM dbo_tampnoundian e WHERE NOT EXISTS ( 
			SELECT null FROM `dbo_dtldaftarpemenang` d WHERE d.chrNoRek = e.NoRek) and NOT EXISTS ( 
			SELECT null FROM `dbo_tmpdaftarpemenang` t WHERE t.chrNoRek = e.NoRek) ORDER BY `NoUrutan` ASC limit ".$indexUndian.",1 ";
			$data = $this->db_kanca->query($sql)->result();
			return $data;
			$this->db_kanca->close();

		}


		function data_maxUndianDistribusi($idkanca)
		{
			$this->db_kanca = $this->load->database('pengundianoffline',TRUE);
			$sql = "SELECT count(`NoUrutan`) as maxnum FROM dbo_tampnoundian e 
			WHERE NOT EXISTS ( 
			SELECT null FROM `dbo_dtldaftarpemenang` d WHERE d.chrNoRek = e.NoRek) 
			and NOT EXISTS ( 
			SELECT null FROM `dbo_tmpdaftarpemenang` t WHERE t.chrNoRek = e.NoRek) 
			ORDER BY `NoUrutan` ASC ";
			$maximum = $this->db_kanca->query($sql)->result();
			$max=0;
			
			foreach ($maximum as $row) {
				$max = $row->maxnum;
			}

			return $max;
			$this->db_kanca->close();

		}

		//get data DistribusiPemenaang
		function data_CalonPemenangDistribusi($idkanca,$indexUndian)
		{
			$this->db_kanca = $this->load->database('pengundianoffline',TRUE);
			$sql = "SELECT a.NoUndianSemuaUnit, a.chrKdUnit, a.noRek FROM (SELECT h.chrKdUnit, u.NoUndianSemuaUnit, u.noRek FROM dbo_dtbhadiahhiburan h INNER JOIN dbo_tampnoundian u ON h.intHiburan81 = 1 and h.chrKdUnit = u.chrKdUnit) a WHERE NOT EXISTS (SELECT null FROM `dbo_tmpdaftarpemenang` d WHERE a.chrKdUnit =d.kodeUker or d.chrNoRek = a.noRek) and NOT EXISTS (SELECT null FROM `dbo_dtldaftarpemenang` dp WHERE dp.chrNoRek = a.noRek) limit ".$indexUndian.",1 ";
			$data = $this->db_kanca->query($sql)->result();
			return $data;
			$this->db_kanca->close();			
		}

		function data_JumlahCalonPemenangDistribusi($idkanca)
		{
			$this->db_kanca = $this->load->database('pengundianoffline',TRUE);
			$sql = "SELECT COUNT(a.NoUndianSemuaUnit) as jumlah FROM (SELECT h.chrKdUnit, u.NoUndianSemuaUnit, u.noRek FROM dbo_dtbhadiahhiburan h INNER JOIN dbo_tampnoundian u ON h.intHiburan81 = 1 and h.chrKdUnit = u.chrKdUnit) a WHERE NOT EXISTS (SELECT null FROM `dbo_tmpdaftarpemenang` d WHERE a.chrKdUnit =d.kodeUker or d.chrNoRek = a.noRek) and NOT EXISTS (SELECT null FROM `dbo_dtldaftarpemenang` dp WHERE dp.chrNoRek = a.noRek)";
			$data = $this->db_kanca->query($sql)->result();
			$jumlah =0;
			foreach ($data as $row) {
				$jumlah = $row->jumlah;
			}
			return $jumlah;
			$this->db_kanca->close();			
		}


		//simpan dteilTmp pemenang
		function truncateTempPemenang($idkanca)
		{
			$this->db_kanca = $this->load->database('pengundianoffline',TRUE);
			return $this->db_kanca->truncate('dbo_tmpdaftarpemenang');
			$this->db_kanca->close();
		}

		public function simpan_pemenangTempPemenang($id_kanca,$data)
		{
			$this->db_kanca = $this->load->database('pengundianoffline',TRUE);  
			$this->db_kanca->set('dtmTglAdd', 'NOW()', FALSE); 
			$this->db_kanca->insert('dbo_tmpdaftarpemenang', $data);
			$this->db_kanca->close();
		}



		function data_UnitDistribusi($idkanca,$tabelName,$ideperiode)
		{
			$this->db_kanca = $this->load->database('pengundianoffline',TRUE);
			$sql = "SELECT `chrKdUnit` FROM `dbo_dtbhadiahhiburan` WHERE `".$tabelName."`=1 and chrKdPeriode ='".$ideperiode."'";
			$data = $this->db_kanca->query($sql)->result();
			return $data;
			$this->db_kanca->close();
		}

		function data_UnitDistribusiTiapUker($idkanca,$tabelName,$uker,$indexrandom)
		{
			$this->db_kanca = $this->load->database('pengundianoffline',TRUE);
			$sql = "SELECT * FROM `dbo_tampnoundian` WHERE  `chrKdUnit` =".$uker." and (`pemenang`=0 or `pemenang` IS NULL) limit ".$indexrandom.",1";
			$data = $this->db_kanca->query($sql)->result();
			return $data;
			$this->db_kanca->close();			
		}

		function data_JumlahUnitDistribusiTiapUker($idkanca,$uker)
		{
			$this->db_kanca = $this->load->database('pengundianoffline',TRUE);
			$sql = "SELECT count(NoUrutan) as jumlah FROM `dbo_tampnoundian` WHERE `chrKdUnit` =".$uker." AND (`pemenang`=0 or `pemenang` IS NULL)";
			$data = $this->db_kanca->query($sql)->result();
			$jumlah =0;
			foreach ($data as $row) {
				$jumlah = $row->jumlah;
			}
			return $jumlah;
			$this->db_kanca->close();			
		}

		//cari jumlah berdasarkan nama distribusi kupon tiap uker
		function data_JumlahUnitDistribusiTiapUkerCepat($idkanca,$uker,$periode)
		{
			$this->db_kanca = $this->load->database('pengundianoffline',TRUE);
			
			$sql = "SELECT count(NoUrutan) as jumlah FROM `dstNoUndian_".$periode."` WHERE `chrKdUnit` =".$uker." AND (`pemenang`=0 or `pemenang` IS NULL)";
			$data = $this->db_kanca->query($sql)->result();
			$jumlah =0;
			foreach ($data as $row) {
				$jumlah = $row->jumlah;
			}
			return $jumlah;
			$this->db_kanca->close();			
		}

		function data_UnitDistribusiTiapUkerCepat($idkanca,$tabelName,$uker,$indexrandom,$periode)
		{
			$this->db_kanca = $this->load->database('pengundianoffline',TRUE);
			$sql = "SELECT * FROM `dstNoUndian_".$periode."` WHERE  `chrKdUnit` =".$uker." and (`pemenang`=0 or `pemenang` IS NULL) limit ".$indexrandom.",1";
			$data = $this->db_kanca->query($sql)->result();
			return $data;
			$this->db_kanca->close();			
		}



		public function simpan_pemenangHadiahHiburan($id_kanca,$data)
		{
			$this->db_kanca = $this->load->database('pengundianoffline',TRUE);  
			$this->db_kanca->set('dtmTglAdd', 'NOW()', FALSE); 
			return $this->db_kanca->insert('dbo_dtldaftarpemenang', $data);
			$this->db_kanca->close();
		}

		public function simpan_tempUndian($id_kanca,$periode,$nomorRek)
		{
			$insert = array(	
					'pemenang' =>1);
			$this->db_kanca = $this->load->database('pengundianoffline',TRUE);  
			$this->db_kanca->where('noRek',$nomorRek);
			$this->db_kanca->update("dstNoUndian_".$periode ,$insert);
			$this->db_kanca->close();
		}

//		create tabel untuk distribusi kupon perperiode
		public function CreateTableDistribusi($id_kanca,$periode)
		{
			$this->db_kanca = $this->load->database('pengundianoffline',TRUE);  
			$sql="CREATE TABLE IF NOT EXISTS `dstNoUndian_".$periode."` (
			`NoUrutan` int(11) NOT NULL AUTO_INCREMENT,
  			`NoUndianSemuaUnit` varchar(17) NOT NULL,
  			`noRek` char(20) DEFAULT NULL,
  			`chrKdUnit` varchar(5) DEFAULT NULL,
  			`pemenang` int(2) DEFAULT NULL,
  			PRIMARY KEY (NoUrutan)
			)ENGINE = MyISAM";
			return $this->db_kanca->query($sql);
			$this->db_kanca->close();
		}

		public function cektable_existornot($id_kanca,$periode)
		{
			$this->db_kanca = $this->load->database('pengundianoffline',TRUE);  
			$sql = "SHOW TABLES LIKE 'dstNoUndian_".$periode."'";
			$exist =  $this->db_kanca->query($sql)->result();
			$no = 0;
			foreach ($exist as $row) {
				$no++;
			}
			return $no;
			$this->db_kanca->close();

		}
		//pengundian jumlah cepat hadiah umum dan biasa
		function data_jumlahpengundianKuponCepat($idkanca,$periode)
		{
			$this->db_kanca = $this->load->database('pengundianoffline',TRUE);
			$sql = "SELECT COUNT(`NoUrutan`) as maxnum FROM `dstNoUndian_".$periode."` WHERE (`pemenang`=0 or `pemenang` IS NULL) ";
			//$sql="SELECT COUNT(`NoUrutan`) as maxnum FROM dbo_tampnoundian ";
			$maximum = $this->db_kanca->query($sql)->result();
			$max=0;
			
			foreach ($maximum as $row) {
				$max = $row->maxnum;
			}

			return $max;
		}

		public function get_nomorrekening($idkanca,$periode,$norek)
		{
			$this->db_kanca = $this->load->database('pengundianoffline',TRUE);  
			$sql="SELECT * FROM `dstNoUndian_".$periode."` WHERE `NoUndianSemuaUnit` = '".$norek."' ";
			$namauker= $this->db_kanca->query($sql)->result();
			$namaukertamp="hay";
			foreach ($namauker as $row) {
				$namaukertamp = $row->noRek;
			}
			return $namaukertamp;
			$this->db_kanca->close();
		}

		public function mass_undian($idkanca,$periode)
		{
			$sql = "SELECT  l.*
			FROM    `dstNoUndian_".$periode."` l
			LEFT JOIN
        	dbo_tmpdaftarpemenang r
			ON      r.chrNoRek = l.noRek
			WHERE   r.chrNoRek IS NOT NULL and l.pemenang!=1";
			$dataundian= $this->db_kanca->query($sql)->result();
			return $dataundian;
			$this->db_kanca->close();
		}

		public function mass_undianindex($idkanca,$periode,$indexrandom)
		{
			$sql = "SELECT  l.*
			FROM    `dstNoUndian_".$periode."` l
			LEFT JOIN
        	dbo_tmpdaftarpemenang r
			ON      r.chrNoRek = l.noRek
			WHERE   r.chrNoRek IS NULL and (l.pemenang!=1 or l.pemenang IS NULL) limit ".$indexrandom.",1";
			$dataundian= $this->db_kanca->query($sql)->result();
			return $dataundian;
			$this->db_kanca->close();
		}


		function mass_undianJumlah($idkanca,$periode)
		{
			$this->db_kanca = $this->load->database('pengundianoffline',TRUE);
			$sql = "SELECT  count(`NoUrutan`) as maxnum
			FROM `dstNoUndian_".$periode."` l
			LEFT JOIN
        	dbo_tmpdaftarpemenang r
			ON      r.chrNoRek = l.noRek
			WHERE   r.chrNoRek IS NOT NULL and (l.pemenang!=1 or l.pemenang IS NULL)";

			$maximum = $this->db_kanca->query($sql)->result();
			$max=0;
			
			foreach ($maximum as $row) {
				$max = $row->maxnum;
			}

			return $max;
			$this->db_kanca->close();

		}



		public function truncute_dbo_tmpdaftarpemenang($idkanca)
		{
			$this->db_kanca = $this->load->database('pengundianoffline',TRUE);
			return $this->db_kanca->truncate('dbo_tmpdaftarpemenang');
			$this->db_kanca->close();

//			$sql="TRUNCATE dbo_tampnoundian";
//			$jumlah= $this->db_kanca->query($sql)->result();
		}

		// new undian
		//get jumlah
		public function jumlah_uker($idkanca, $chrKdPeriode,$kodebulan)
		{
			$sql = "SELECT COUNT(`chrKdUnit`) as jumlah FROM `dbo_mstunit`";
			$sql = "SELECT `jumlah` FROM `tamp_jumlah_uker_ran_bulan` WHERE `kodeBulan` ='".$kodebulan."'";
			
			$this->db_kanca = $this->load->database('pengundianoffline',TRUE);  
			$jumlah= $this->db_kanca->query($sql)->result();
			foreach ($jumlah as $row) {
				return $row->jumlah;
			}


		}


		public function jumlah_kode_bulan($idkanca, $chrKdPeriode)
		{
			$sql = "SELECT count(`kodeBulan`) as jumlah FROM dbo_tampbulan";
			
			$this->db_kanca = $this->load->database('pengundianoffline',TRUE);  
			$jumlah= $this->db_kanca->query($sql)->result();
			foreach ($jumlah as $row) {
				return $row->jumlah;
			}


		}

		public function jumlah_kupon_total($idkanca, $chrKdPeriode,$kode_uker,$kodebulan)
		{

			$sql = "SELECT max(KuponAkhir) as total_kupon FROM `dbo_dtlnomorundian` WHERE `kodeUker` =".$kode_uker." and `chrKdPeriode` = '".$chrKdPeriode."' and kodeBulan='".$kodebulan."'
					ORDER BY `dbo_dtlnomorundian`.`KuponAkhir` DESC";

			$this->db_kanca = $this->load->database('pengundianoffline',TRUE);  
			$jumlah= $this->db_kanca->query($sql)->result();
			
			foreach ($jumlah as $row) {
				return $row->total_kupon;
			}
		}

        //get kode
		
		public function kode_uker($idkanca, $chrKdPeriode,$limit,$kodebulan)
		{
			//$sql = "SELECT `chrKdUnit` as kodeUker FROM `dbo_mstunit` limit ".$limit.",1";
			$sql ="SELECT `chrKdUnit` as kodeUker FROM `tamp_random_uker` WHERE kodeBulan= '".$kodebulan."' limit ".$limit.",1";
			
			$this->db_kanca = $this->load->database('pengundianoffline',TRUE);  
			$kode_uker= $this->db_kanca->query($sql)->result();
			foreach ($kode_uker as $row) {
				return $row->kodeUker;
			}


		}

		public function kode_bulan($idkanca, $chrKdPeriode,$limit)
		{
			$sql = "SELECT `kodeBulan` FROM dbo_tampbulan limit ".$limit.",1";
			$this->db_kanca = $this->load->database('pengundianoffline',TRUE);  
			$kode_Bulan= $this->db_kanca->query($sql)->result();
			foreach ($kode_Bulan as $row) {
				return $row->kodeBulan;
			}
			
		}

		public function get_nomorrekening_kupon($idkanca, $chrKdPeriode,$kodebulan,$kode_uker,$kupon)
		{
			$sql 			= "SELECT `NoRek` FROM `dbo_dtlnomorundian` a inner join dbo_dtldaftarpemenang b on a.NoRek != b.chrNoRek WHERE a.`KuponAwal` <= ".$kupon." and a.`KuponAkhir`>=".$kupon." and a.`kodeUker` =".$kode_uker." and a.`chrKdPeriode` = '".$chrKdPeriode."' and a.kodeBulan='".$kodebulan."'";
			#$sql 			= "SELECT `NoRek` FROM `dbo_dtlnomorundian` a inner join dbo_dtldaftarpemenang b on a.NoRek != b.chrNoRek WHERE a.`KuponAwal` <= 5 and a.`KuponAkhir`>=5 and a.`kodeUker` ='3885' and a.`chrKdPeriode` = '012015' and a.kodeBulan='0315' ";
			$this->db_kanca = $this->load->database('pengundianoffline',TRUE);  
			$data_rek		= $this->db_kanca->query($sql)->result();
			foreach ($data_rek as $row) {
				return $row->NoRek;
			}

		}

		public function get_nomorrekening_kupon_cek($idkanca, $chrKdPeriode,$kodebulan,$kode_uker,$kupon)
		{
			$sql 			= "SELECT `NoRek` FROM `dbo_dtlnomorundian` a WHERE a.`KuponAwal` <= ".$kupon." and a.`KuponAkhir`>=".$kupon." and a.`kodeUker` =".$kode_uker." and a.`chrKdPeriode` = '".$chrKdPeriode."' and a.kodeBulan='".$kodebulan."'";
			#$sql 			= "SELECT `NoRek` FROM `dbo_dtlnomorundian` a inner join dbo_dtldaftarpemenang b on a.NoRek != b.chrNoRek WHERE a.`KuponAwal` <= 5 and a.`KuponAkhir`>=5 and a.`kodeUker` ='3885' and a.`chrKdPeriode` = '012015' and a.kodeBulan='0315' ";
			$this->db_kanca = $this->load->database('pengundianoffline',TRUE);  
			$data_rek		= $this->db_kanca->query($sql)->result();
			foreach ($data_rek as $row) {
				return $row->NoRek;
			}

		}


		public function get_nomorrekening_kupon_multidraw($idkanca, $chrKdPeriode,$kodebulan,$kode_uker,$kupon)
		{
			$sql 			= "SELECT `NoRek`,namaNasabah FROM `dbo_dtlnomorundian` a  WHERE a.`KuponAwal` <= ".$kupon." and a.`KuponAkhir`>=".$kupon." and a.`kodeUker` =".$kode_uker." and a.`chrKdPeriode` = '".$chrKdPeriode."' and a.kodeBulan='".$kodebulan."'";
			#$sql 			= "SELECT `NoRek` FROM `dbo_dtlnomorundian` a inner join dbo_dtldaftarpemenang b on a.NoRek != b.chrNoRek WHERE a.`KuponAwal` <= 5 and a.`KuponAkhir`>=5 and a.`kodeUker` ='3885' and a.`chrKdPeriode` = '012015' and a.kodeBulan='0315' ";
			$this->db_kanca = $this->load->database('pengundianoffline',TRUE);  
			$data_rek		= $this->db_kanca->query($sql)->result();

			return $data_rek ;
			
			/*
			foreach ($data_rek as $row) {
				return $row->NoRek;
			}
			*/

		}


		public function get_range_nomorrekening_kupon_single_draw($idkanca, $chrKdPeriode,$kodebulan,$kode_uker)
		{   
			$this->db_kanca = $this->load->database('pengundianoffline',TRUE);  
			//$sql 	= "SELECT a.`KuponAwal`,a.`KuponAkhir` FROM `dbo_dtlnomorundian` a inner join `dbo_dtldaftarpemenang`b on a.`NoRek` = b.chrNoRek where a.`chrKdPeriode`=b.chrKdPeriode and a.`chrKdPeriode`='".$chrKdPeriode."' and a.kodeBulan =SUBSTR(b.chrNoUndian,5,4) and a.kodeUker = b.kodeUker and a.kodeUker = '".$kode_uker."'";
			$sql  ="
			SELECT a.`KuponAwal`,a.`KuponAkhir`,a.`chrKdPeriode`,a.kodeBulan,a.kodeUker,b.chrNoRek,b.chrNoUndian FROM `dbo_dtlnomorundian` a 
			inner join (
			SELECT chrKdPeriode, `kodeUker`,`namaUker`,`chrNoUndian`,`chrNoRek` FROM `dbo_dtldaftarpemenang` a
			WHERE 1
			    )
			b 
			on a.`NoRek` = b.chrNoRek 
			where a.`chrKdPeriode`=b.chrKdPeriode and a.`chrKdPeriode`='".$chrKdPeriode."' and a.kodeUker = b.kodeUker and a.kodeUker = ".$kode_uker."
			";

 
			return $this->db_kanca->query($sql)->result();
			
		}



		public function get_range_nomorrekening_kupon($idkanca, $chrKdPeriode,$kodebulan,$kode_uker)
		{   
			$this->db_kanca = $this->load->database('pengundianoffline',TRUE);  
			$sql 	= "SELECT a.`KuponAwal`,a.`KuponAkhir` FROM `dbo_dtlnomorundian` a inner join `dbo_dtldaftarpemenang`b on a.`NoRek` = b.chrNoRek where a.`chrKdPeriode`=b.chrKdPeriode and a.`chrKdPeriode`='".$chrKdPeriode."' and a.kodeUker = ".$kode_uker." and a.kodeBulan = ".$kodebulan."";
			return $this->db_kanca->query($sql)->result();
			
		}

		public function get_range_nomorrekening_kupon_multi_draw($idkanca, $chrKdPeriode,$kodebulan,$kode_uker)
		{   
			$this->db_kanca = $this->load->database('pengundianoffline',TRUE);  
			//$sql 	= "SELECT a.`KuponAwal`,a.`KuponAkhir` FROM `dbo_dtlnomorundian` a inner join `dbo_dtldaftarpemenang`b on a.`NoRek` = b.chrNoRek where a.`chrKdPeriode`=b.chrKdPeriode and a.`chrKdPeriode`='".$chrKdPeriode."' and a.kodeBulan =SUBSTR(b.chrNoUndian,5,4) and a.kodeUker = b.kodeUker and a.kodeUker = ".$kode_uker."";
			$sql = "SELECT a.`KuponAwal`,a.`KuponAkhir`,a.`chrKdPeriode`,a.kodeBulan,a.kodeUker,b.chrNoRek,b.chrNoUndian FROM `dbo_dtlnomorundian` a 
					inner join (
					SELECT chrKdPeriode, `kodeUker`,`namaUker`,`chrNoUndian`,`chrNoRek` FROM `dbo_dtldaftarpemenang` a
								WHERE a.kodeUker = ".$kode_uker."
								UNION ALL
								SELECT chrKdPeriode,`kodeUker`,`namaUker`,`chrNoUndian`,chrNoRek
								FROM dbo_tmpdaftarpemenang b
								WHERE b.kodeUker = ".$kode_uker." ) b 
					on a.`NoRek` = b.chrNoRek 
					where a.`chrKdPeriode`=b.chrKdPeriode and a.`chrKdPeriode`='".$chrKdPeriode."' and a.kodeBulan=".$kodebulan.""; 

			/*
			$sql  ="
			SELECT a.`KuponAwal`,a.`KuponAkhir`,a.`chrKdPeriode`,a.kodeBulan,a.kodeUker,b.chrNoRek,b.chrNoUndian FROM `dbo_dtlnomorundian` a 
			inner join (
			SELECT chrKdPeriode, `kodeUker`,`namaUker`,`chrNoUndian`,`chrNoRek` FROM `dbo_dtldaftarpemenang` a
			WHERE 1
			UNION ALL
			SELECT chrKdPeriode,`kodeUker`,`namaUker`,`chrNoUndian`,chrNoRek
			FROM dbo_tmpdaftarpemenang a
			WHERE 1   
			    )
			b 
			on a.`NoRek` = b.chrNoRek 
			where a.`chrKdPeriode`=b.chrKdPeriode and a.`chrKdPeriode`='".$chrKdPeriode."' and a.kodeUker = b.kodeUker and a.kodeUker = ".$kode_uker."
			";
			*/


			return $this->db_kanca->query($sql)->result();
			
		}

		//get pemenang single draw new
		public function get_nomorrekening_new($idkanca,$periode,$kode_uker,$kodeBulan,$noundian)
		{

			
			$this->db_kanca = $this->load->database('pengundianoffline',TRUE);  
			$sql="SELECT `NoRek`,namaNasabah FROM `dbo_dtlnomorundian` WHERE `kodeUker`=".$kode_uker." and `kodeBulan`='".$kodeBulan."' and `KuponAwal`<=".$noundian." and `KuponAkhir` >=".$noundian." and chrKdPeriode='".$periode."' limit 1";
			$nama_pemenang= $this->db_kanca->query($sql)->result();
			return $nama_pemenang;
			//$namaukertamp="";
			//foreach ($namauker as $row) {
			//	$namaukertamp = $row->noRek;
			//}
			//return $namaukertamp;
			$this->db_kanca->close();

		}


		//get unit kerja
		public function get_namaukerundian_new($iduker)
		{
			$this->db_kanca = $this->load->database('db1',TRUE);  
			$sql="SELECT `vcrNmUnit` FROM `dbo_mstunit` WHERE chrKdUnit = ".$iduker."";
			//SELECT `MBDESC` FROM `dbo_dwh_branch` WHERE `BRANCH` = ".$iduker."";
			$namauker= $this->db->query($sql)->result();
			$namaukertamp="bri";
			foreach ($namauker as $row) {
				$namaukertamp = $row->vcrNmUnit;
			}
			return $namaukertamp;
			$this->db_kanca->close();


		}

		//pengundian hadiah hiburan
		public function get_unit_distribusi_hadiah_hiburan($idkanca,$periode,$kode_hadiah_hiburan)
		{
		  $sql= "SELECT `chrKdUnit`,`chrKdPeriode` FROM `dbo_dtbhadiahhiburan` WHERE `chrKdPeriode`='".$periode."' and intHiburan".$kode_hadiah_hiburan." = 1 ";
  		  $this->db_kanca = $this->load->database('pengundianoffline',TRUE);  
		  return $this->db_kanca->query($sql)->result();



		}

	
		public function simpan_pemenangHadiah_multidraw($id_kanca,$data)
		{
			$this->db_kanca = $this->load->database('pengundianoffline',TRUE);  
			$this->db_kanca->set('dtmTglAdd', 'NOW()', FALSE); 
			return $this->db_kanca->insert('dbo_dtldaftarpemenang', $data);
			$this->db_kanca->close();

		}









		

	}
?>
