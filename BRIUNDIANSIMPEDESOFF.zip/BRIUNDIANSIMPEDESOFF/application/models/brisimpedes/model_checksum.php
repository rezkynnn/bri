<?php

class model_checksum extends CI_Model
{
		public function index()
		{
			parent::__construct();
		}
		

		//inster chekcsum
		function insert_checksum($insert){
			$this->check = $this->load->database("checksum_file",TRUE);  
			$this->check->set('dtmAdd', 'NOW()', FALSE); 
			return $this->check->insert('checksum',$insert);
			$this->check->close();
		}

}
?>
