<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
	class model_exel extends CI_Model {
		public function index()
		{
			parent::__construct();
		}
		
		

		function data_exel_hadiahPerPeriode($idperiode){
			return $this->db->query(
			"SELECT k.potonganHarga, h.chrKdPeriode,k.chrKdKanwil,k.chrKdKanca, k.varJenisHadiah as varJenisHadiah, k.varTypeHadiah, k.varMerkHadiah,k.hargaSatuan,k.tahunPembuatan,k.varKondisiPembuatan, k.statusHadiah,CONVERT( h.dtmTglAwal, DATE ) AS awal, CONVERT( h.dtmTglAkhir, DATE ) AS akhir, vcrNamaHadiah as nama, chrNmHadiah as jenishadiah, intJmlhadiah as jumlah, chrKdHadiah as kode
			FROM dbo_mstperiode h, dbo_msthadiahkanca k, dbo_msthadiahperiod p
			WHERE h.chrKdPeriode = k.chrKdPeriode
			AND k.chrKdPeriode = p.chrKdPeriode
			AND k.chrJnsHadiah = p.chrKdHadiah
			AND k.chrKdPeriode = '".$idperiode."'
            group by nama
             ")->result();

		}
		function data_exel_hadiahAllPeriode(){
			return $this->db->query(
			"SELECT sk.statusHadiah, k.potonganHarga, h.chrKdPeriode,k.chrKdKanwil,k.chrKdKanca,b.MBDESC as kanwil,b.RGDESC as kanca, k.varJenisHadiah as varJenisHadiah, k.varTypeHadiah, k.varMerkHadiah,k.hargaSatuan,k.tahunPembuatan,k.varKondisiPembuatan, k.statusHadiah,CONVERT( h.dtmTglAwal, DATE ) AS awal, CONVERT( h.dtmTglAkhir, DATE ) AS akhir, vcrNamaHadiah as nama, chrNmHadiah as jenishadiah, intJmlhadiah as jumlah, chrKdHadiah as kode
			FROM dbo_mstperiode h, dbo_msthadiahkanca k, dbo_msthadiahperiod p, dbo_dwh_branch b ,dbo_statushadiahkanca sk
			WHERE h.chrKdPeriode = k.chrKdPeriode
			AND k.chrKdPeriode = p.chrKdPeriode
			AND k.chrJnsHadiah = p.chrKdHadiah
			AND sk.chrKdKanca = k.chrKdKanca	
            AND b.REGION = k.chrKdKanwil
            AND b.MAINBR = k.chrKdKanca
            AND sk.statusHadiah = 4
            group by nama
             ")->result();

		}


		function data_exel_hadiahPerPeriodeKanca($idperiode,$idkanca){
			return $this->db->query(
			"SELECT k.potonganHarga, h.chrKdPeriode,k.chrKdKanwil,k.chrKdKanca, k.varJenisHadiah as varJenisHadiah, k.varTypeHadiah, k.varMerkHadiah,k.hargaSatuan,k.tahunPembuatan,k.varKondisiPembuatan, k.statusHadiah,CONVERT( h.dtmTglAwal, DATE ) AS awal, CONVERT( h.dtmTglAkhir, DATE ) AS akhir, vcrNamaHadiah as nama, chrNmHadiah as jenishadiah, intJmlhadiah as jumlah, chrKdHadiah as kode
			FROM dbo_mstperiode h, dbo_msthadiahkanca k, dbo_msthadiahperiod p
			WHERE h.chrKdPeriode = k.chrKdPeriode
			AND k.chrKdPeriode = p.chrKdPeriode
			AND k.chrJnsHadiah = p.chrKdHadiah
			AND k.chrKdPeriode = '".$idperiode."'
            AND k.chrKdKanca = '".$idkanca."'
            group by nama,chrKdHadiah
            order by chrKdHadiah
             ")->result();

			}

		function data_exel_hadiahPerPeriodeKancaAll($idkanca){
			return $this->db->query(
			"SELECT k.potonganHarga, h.chrKdPeriode,k.chrKdKanwil,k.chrKdKanca, k.varJenisHadiah as varJenisHadiah, k.varTypeHadiah, k.varMerkHadiah,k.hargaSatuan,k.tahunPembuatan,k.varKondisiPembuatan, k.statusHadiah,CONVERT( h.dtmTglAwal, DATE ) AS awal, CONVERT( h.dtmTglAkhir, DATE ) AS akhir, vcrNamaHadiah as nama, chrNmHadiah as jenishadiah, intJmlhadiah as jumlah, chrKdHadiah as kode
			FROM dbo_mstperiode h, dbo_msthadiahkanca k, dbo_msthadiahperiod p
			WHERE h.chrKdPeriode = k.chrKdPeriode
			AND k.chrKdPeriode = p.chrKdPeriode
			AND k.chrJnsHadiah = p.chrKdHadiah
            AND k.chrKdKanca = '".$idkanca."'
            group by nama
             ")->result();

		}

		function data_exel_hadiahPerPeriodekanwil($idperiode,$kanwil){
			return $this->db->query(
			"SELECT sk.statusHadiah, k.potonganHarga, h.chrKdPeriode,k.chrKdKanwil,k.chrKdKanca,b.MBDESC as kanwil,b.RGDESC as kanca, k.varJenisHadiah as varJenisHadiah, k.varTypeHadiah, k.varMerkHadiah,k.hargaSatuan,k.tahunPembuatan,k.varKondisiPembuatan, k.statusHadiah,CONVERT( h.dtmTglAwal, DATE ) AS awal, CONVERT( h.dtmTglAkhir, DATE ) AS akhir, vcrNamaHadiah as nama, chrNmHadiah as jenishadiah, intJmlhadiah as jumlah, chrKdHadiah as kode
			FROM dbo_mstperiode h, dbo_msthadiahkanca k, dbo_msthadiahperiod p, dbo_dwh_branch b ,dbo_statushadiahkanca sk
			WHERE h.chrKdPeriode = k.chrKdPeriode
			AND k.chrKdPeriode = p.chrKdPeriode
			AND k.chrJnsHadiah = p.chrKdHadiah
			AND k.chrKdPeriode = '".$idperiode."'
			AND sk.chrKdKanca = k.chrKdKanca	
            AND b.REGION = k.chrKdKanwil
            AND k.chrKdKanwil = '".$kanwil."'
            AND b.MAINBR = k.chrKdKanca
            AND(sk.statusHadiah = 4
            OR sk.statusHadiah = 2)
            group by nama
             ")->result();

		}
		function data_exel_hadiahAllPeriodekanwil($kanwil){
			return $this->db->query(
			"SELECT sk.statusHadiah, k.potonganHarga, h.chrKdPeriode,k.chrKdKanwil,k.chrKdKanca,b.MBDESC as kanwil,b.RGDESC as kanca, k.varJenisHadiah as varJenisHadiah, k.varTypeHadiah, k.varMerkHadiah,k.hargaSatuan,k.tahunPembuatan,k.varKondisiPembuatan, k.statusHadiah,CONVERT( h.dtmTglAwal, DATE ) AS awal, CONVERT( h.dtmTglAkhir, DATE ) AS akhir, vcrNamaHadiah as nama, chrNmHadiah as jenishadiah, intJmlhadiah as jumlah, chrKdHadiah as kode
			FROM dbo_mstperiode h, dbo_msthadiahkanca k, dbo_msthadiahperiod p, dbo_dwh_branch b ,dbo_statushadiahkanca sk
			WHERE h.chrKdPeriode = k.chrKdPeriode
			AND k.chrKdPeriode = p.chrKdPeriode
			AND k.chrJnsHadiah = p.chrKdHadiah
			AND sk.chrKdKanca = k.chrKdKanca	
            AND b.REGION = k.chrKdKanwil
            AND k.chrKdKanwil = '".$kanwil."'
            AND b.MAINBR = k.chrKdKanca
            AND (sk.statusHadiah = 4
            OR sk.statusHadiah = 2)
            group by nama
                        ")->result();

		}

	}
?>