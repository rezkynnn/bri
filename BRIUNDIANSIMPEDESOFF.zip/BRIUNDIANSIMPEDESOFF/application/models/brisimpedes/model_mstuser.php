<?php

class model_mstuser extends CI_Model
{
	  	private $another;
  		function __construct()
  		{
    		parent::__construct();
    		$this->another = $this->load->database('db1',TRUE);
  		}

  		function login($where)
  		{
  					$conn = $this->load->database('db1',TRUE);
					$conn->where($where);
					$query = $conn->get('dbo_mstUser');
					return $query->result();
			//return $this->another->query("SELECT * FROM `dbo_mstuser` WHERE chrKdUser ='s206spv' and chrPassword='supervisor'")->result();
  		}
	
		function data_unit(){
			return $this->another->query("SELECT * FROM `dbo_mstunit` WHERE `chrKdKanca` = '206'")->result();
		}
		
		function data_kancaundian(){
			return $this->another->query("SELECT `varNmKanca`,`chrKdKanca` FROM `dbo_mstUser` limit 1")->result();
		}

		function data_user($idkanca){
			return $this->another->query("SELECT * FROM `dbo_mstuser` WHERE `chrKdKanca` = '".$idkanca."'")->result();
		}

		function data_grouparea(){
			return $this->another->query("SELECT * FROM `dbo_mstgrouparea` WHERE 1")->result();
		}

		function data_kanca(){
			return $this->another->query("SELECT * FROM `dbo_mstkanca` order by `vcrNmKanca` ASC")->result();
		}


		//function getdata_user($idKanca, $iduser){
		//	$getdataunit = $this->another->query("SELECT * FROM `dbo_mstuser` WHERE `chrKdKanca`='".$idkanca."' and `chrKdUser` = ".$iduser." limit 1")->result();			 
		//		return $getdataunit;
		//}

		function getdata_user($idkanca , $iduser){
			return $this->another->query("SELECT * FROM `dbo_mstuser` WHERE `chrKdKanca` = '".$idkanca."' and `chrKdUser` = '".$iduser."'")->result();
		}

		public function update_user($id_kanca, $id_user, $update)
		{
			$this->another->where('chrKdUser', $id_user);
			$this->another->where('chrKdKanca',$id_kanca);
			$this->another->update('dbo_mstuser', $update);
		}



		





	

}
?>