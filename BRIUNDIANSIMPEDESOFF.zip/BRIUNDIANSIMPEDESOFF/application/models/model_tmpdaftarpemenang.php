<?php

class model_tmpdaftarpemenang extends CI_Model
{
	
		function data_pemenang(){
			return $this->db->query('SELECT * FROM dbo_tmpdaftarpemenang')->result();

		}

		function delete_pemenang(){
			$sql = "DELETE FROM dbo_tmpdaftarpemenang where 1";
			return $this->db->query($sql);
		}


		function existing_data($nomorRek)
		{
			$sukses = "";
			$sql = "select exists (select chrNoUndian FROM `dbo_tmpdaftarpemenang` WHERE `chrNoRek` = '".$nomorRek."' and `chrKdPeriode` = '022015' ) as hasil";
			$flag = $this->db->query($sql)->result();
			return $flag;
			
		}
		
		function data_tampung1($chrNoUndian,$chrNoRek,$vcrNmNsbh,$chrJnsHadiah,$chrKdPeriode,$bitStsData,$chrUserAdd, $dtmTglAdd,$chrUserEdit,$dtmUserEdit){

		    $sql = "INSERT INTO `db_kc_s206`.`dbo_tmpdaftarpemenang` (`chrNoUndian`, `chrNoRek`, `vcrNmNsbh`, `chrJnsHadiah`, `chrKdPeriode`, `bitStsData`, `chrUserAdd`, `dtmTglAdd`, `chrUserEdit`, `dtmUserEdit`) VALUES ( '".$chrNoUndian."' , '".$chrNoRek."', '".$vcrNmNsbh."', '".$chrJnsHadiah."', '4', b'1', '4', '2015-02-27 11:34:45', '', '2015-02-28 11:34:48')";
			return $this->db->query($sql);

		//	retrun "sukses";

		}

		function data_tampung(){

		    $sql = "INSERT INTO `db_kc_s206`.`dbo_tmpdaftarpemenang` (`chrNoUndian`, `chrNoRek`, `vcrNmNsbh`, `chrJnsHadiah`, `chrKdPeriode`, `bitStsData`, `chrUserAdd`, `dtmTglAdd`, `chrUserEdit`, `dtmUserEdit`) VALUES ('4', '4', '4', '4', '4', b'1', '4', '2015-02-27 11:34:45', '', '2015-02-28 11:34:48')";
			return $this->db->query($sql);


		}

		function jumlah_penenang($hadiah)
		{
			$jumlah = 0;
			$sql = "SELECT count(`chrJnsHadiah`) as jumlah FROM `dbo_dtldaftarpemenang` WHERE `chrJnsHadiah` = '".$hadiah."' ";
			$jumlah = $this->db->query($sql)->result();
			if (isset($jumlah)) 
       		{
	        	foreach ($jumlah as $row) 
	        	{
                  $jumlah = $row->jumlah;
            	}
        	}
			return $jumlah;




		}




}
?>