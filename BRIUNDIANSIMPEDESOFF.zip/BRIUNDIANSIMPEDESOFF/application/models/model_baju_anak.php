<?php

class Model_baju_anak extends CI_Model
{	
	function all_baju_anak(){
		return $this->db->query('SELECT * FROM baju_anak')->result();
	}
	function recent(){
		return $this->db->query('SELECT * FROM baju_anak ORDER BY tgl_upload_ba DESC')->result();
	}
	function insert($data)
	{
		return $this->db->insert('baju_anak',$data);
	}
	function get_article($id){
		$this->db->where('id_ba', $id);
		return $this->db->get('baju_anak')->row();
	}
	function update($id,$data){
		$this->db->where('id_ba', $id);
		$this->db->update('baju_anak', $data);
	}
	function delete($id){
		$this->db->where('id_ba',$id);
		return $this->db->delete('baju_anak');
	}
}

?>