<?php

class model_kupounutama extends CI_Model
{
	
		function data_kupon_tampilkan(){
			return $this->db->query('SELECT * FROM `dbo_dtbkuponutamadtl` limit 10,20 ')->result();
		}


		function data_seleksi($nomorkupon){
			return $this->db->query('SELECT * FROM ``dbo_dtbkuponutamadtl`` WHERE `numAwl01` <= '.$nomorkupon.' AND `numAkh01` >='.$nomorkupon.' OR (`numAwl02` <= '.$nomorkupon.' AND `numAkh02` >= '.$nomorkupon.') OR (`numAwl03` <= '.$nomorkupon.' AND `numAkh03` >= '.$nomorkupon.') OR (`numAwl04` <= '.$nomorkupon.' AND `numAkh04` >= '.$nomorkupon.') OR (`numAwl05` <= '.$nomorkupon.' AND `numAkh05` >= '.$nomorkupon.') OR (`numAwl06` <= '.$nomorkupon.' AND `numAkh06` >= '.$nomorkupon.')')->result();
		}


		function data_kupon_tampilkan10(){
			return $this->db->query('SELECT * FROM `dbo_dtbkuponutamadtl` ORDER BY RAND() limit 10 ')->result();
		}

		function seleksi_data_kuponBiasa($kupon){
			return $this->db->query('SELECT * FROM `dbo_dtbkuponutamadtl` ORDER BY RAND() limit 10 ')->result();
		}

		function jumlah_hadiah_biasa(){
			return $this->db->query('SELECT max( `numAkh06` ) as max FROM `dbo_dtbkuponutamadtl`')->result();
		}

	

}
?>