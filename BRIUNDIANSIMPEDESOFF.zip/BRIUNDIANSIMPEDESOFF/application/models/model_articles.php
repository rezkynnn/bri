<?php

class Model_articles extends CI_Model
{	
	function all_barang(){
		return $this->db->query('SELECT * FROM barang')->result();
	}
	function recent(){
		return $this->db->query('SELECT * FROM barang')->result();
	}
	function insert($data)
	{
		return $this->db->insert('barang',$data);
	}
	function get_article($id){
		$this->db->where('id_barang', $id);
		return $this->db->get('barang')->row();
	}
	function get_value($nama_barang = false){
		if ($nama_barang) {
			$result =$this->db->get_where('barang', array('nama_barang' => $nama_barang ));
			if ($result->num_rows()>0) {
				return $result->row();
			}else  {
				return false;
			}
		}else{
			return false;
		}
	}

	function update_sisa($nama_barang,$sisa){
			$data= array('sisa_barang' =>	$sisa);
			$this->db->where('nama_barang', $nama_barang);
			$this->db->update('barang', $data);
	}
	function update($id,$data){
		$this->db->where('id', $id);
		$this->db->update('barang', $data);
	}
	function delete($id){
		$this->db->where('id_barang',$id);
		return $this->db->delete('barang');
	}
}

?>