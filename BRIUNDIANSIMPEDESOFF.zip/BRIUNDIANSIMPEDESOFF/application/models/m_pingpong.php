<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class M_pingpong extends CI_Model {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -  
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in 
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see http://codeigniter.com/user_guide/general/urls.html
	 */
	public function index()
	{
		parent::__construct();
	}

	public function list_a()
	{
		$this->db->where('group','A');
		$this->db->order_by('id_member','desc');
		$query = $this->db->get('tb_member');
		return $query->result();
	}

	public function list_b()
	{
		$this->db->where('group','B');
		$this->db->order_by('id_member','desc');
		$query = $this->db->get('tb_member');
		return $query->result();
	}

	public function list_c()
	{
		$this->db->where('group','C');
		$this->db->order_by('id_member','desc');
		$query = $this->db->get('tb_member');
		return $query->result();
	}

	public function add_member($insert)
	{
		$this->db->insert('tb_member',$insert);
	}

	public function delete_member($id_member)
	{
		$this->db->where('id_member',$id_member);
		$this->db->delete('tb_member');
	}

	public function add_score($insert)
	{
		$this->db->insert('tb_score',$insert);
	}
	
	public function score_a()
	{
		$this->db->where('group','A');
		$this->db->order_by('id_score','desc');
		$query = $this->db->get('tb_score');
		return $query->result();
	}
	
	public function score_b()
	{
		$this->db->where('group','B');
		$this->db->order_by('id_score','desc');
		$query = $this->db->get('tb_score');
		return $query->result();
	}
	
	public function score_c()
	{
		$this->db->where('group','C');
		$this->db->order_by('id_score','desc');
		$query = $this->db->get('tb_score');
		return $query->result();
	}
	
	public function klasemen_a()
	{
		$sql = '
		SELECT A.GROUP, A.ID_MEMBER, A.NAMA_MEMBER, 
			(B.JML_MAIN+C.JML_MAIN) JML_MAIN, ifnull((B.POIN_MENANG+C.POIN_MENANG),0) POIN_MENANG,
			 ifnull((B.POIN_KALAH+C.POIN_KALAH),0) POIN_KALAH,
			(ifnull((B.POIN_MENANG+C.POIN_MENANG),0)-ifnull((B.POIN_KALAH+C.POIN_KALAH),0)) AS TOTAL_POIN

			FROM TB_MEMBER A LEFT JOIN 
			(
			SELECT A.GROUP, A.ID_MEMBER, A.NAMA_MEMBER, COUNT(B.PEMAIN1) AS JML_MAIN, SUM(IFNULL((B.SCORE1),0)) AS  POIN_MENANG,
			SUM(IFNULL((B.SCORE2),0)) AS POIN_KALAH
			FROM TB_MEMBER A LEFT JOIN TB_SCORE B
			ON A.ID_MEMBER = B.PEMAIN1
			GROUP BY A.GROUP, A.ID_MEMBER, A.NAMA_MEMBER
			) B ON A.ID_MEMBER = B.ID_MEMBER 
			LEFT JOIN 
			(
			SELECT A.GROUP, A.ID_MEMBER, A.NAMA_MEMBER, COUNT(B.PEMAIN2) AS JML_MAIN, SUM(IFNULL((B.SCORE2),0)) AS POIN_MENANG,
			SUM(IFNULL((B.SCORE1),0)) AS POIN_KALAH
			FROM TB_MEMBER A LEFT JOIN TB_SCORE B
			ON A.ID_MEMBER = B.PEMAIN2
			GROUP BY A.GROUP, A.ID_MEMBER, A.NAMA_MEMBER
			) C ON A.ID_MEMBER = C.ID_MEMBER
			WHERE A.GROUP = \'A\' 
			GROUP BY A.GROUP, A.ID_MEMBER, A.NAMA_MEMBER
			ORDER BY ifnull((B.POIN_MENANG+C.POIN_MENANG),0) DESC, ifnull((B.JML_MAIN+C.JML_MAIN),0) desc, ifnull((B.POIN_KALAH+C.POIN_KALAH),0) asc, (ifnull((B.POIN_MENANG+C.POIN_MENANG),0)-ifnull((B.POIN_KALAH+C.POIN_KALAH),0)) DESC
		';
		
		$query = $this->db->query($sql);
		return $query->result();
	}
	
	public function klasemen_b()
	{
		$sql = '
		SELECT A.GROUP, A.ID_MEMBER, A.NAMA_MEMBER, 
			(B.JML_MAIN+C.JML_MAIN) JML_MAIN, ifnull((B.POIN_MENANG+C.POIN_MENANG),0) POIN_MENANG,
			 ifnull((B.POIN_KALAH+C.POIN_KALAH),0) POIN_KALAH,
			(ifnull((B.POIN_MENANG+C.POIN_MENANG),0)-ifnull((B.POIN_KALAH+C.POIN_KALAH),0)) AS TOTAL_POIN

			FROM TB_MEMBER A LEFT JOIN 
			(
			SELECT A.GROUP, A.ID_MEMBER, A.NAMA_MEMBER, COUNT(B.PEMAIN1) AS JML_MAIN, SUM(IFNULL((B.SCORE1),0)) AS  POIN_MENANG,
			SUM(IFNULL((B.SCORE2),0)) AS POIN_KALAH
			FROM TB_MEMBER A LEFT JOIN TB_SCORE B
			ON A.ID_MEMBER = B.PEMAIN1
			GROUP BY A.GROUP, A.ID_MEMBER, A.NAMA_MEMBER
			) B ON A.ID_MEMBER = B.ID_MEMBER 
			LEFT JOIN 
			(
			SELECT A.GROUP, A.ID_MEMBER, A.NAMA_MEMBER, COUNT(B.PEMAIN2) AS JML_MAIN, SUM(IFNULL((B.SCORE2),0)) AS POIN_MENANG,
			SUM(IFNULL((B.SCORE1),0)) AS POIN_KALAH
			FROM TB_MEMBER A LEFT JOIN TB_SCORE B
			ON A.ID_MEMBER = B.PEMAIN2
			GROUP BY A.GROUP, A.ID_MEMBER, A.NAMA_MEMBER
			) C ON A.ID_MEMBER = C.ID_MEMBER
			WHERE A.GROUP = \'B\' 
			GROUP BY A.GROUP, A.ID_MEMBER, A.NAMA_MEMBER
			ORDER BY ifnull((B.POIN_MENANG+C.POIN_MENANG),0) DESC, ifnull((B.JML_MAIN+C.JML_MAIN),0) desc, ifnull((B.POIN_KALAH+C.POIN_KALAH),0) asc, (ifnull((B.POIN_MENANG+C.POIN_MENANG),0)-ifnull((B.POIN_KALAH+C.POIN_KALAH),0)) DESC
		';
		
		$query = $this->db->query($sql);
		return $query->result();
	}
	
	public function klasemen_c()
	{
		$sql = '
		SELECT A.GROUP, A.ID_MEMBER, A.NAMA_MEMBER, 
			(B.JML_MAIN+C.JML_MAIN) JML_MAIN, ifnull((B.POIN_MENANG+C.POIN_MENANG),0) POIN_MENANG,
			 ifnull((B.POIN_KALAH+C.POIN_KALAH),0) POIN_KALAH,
			(ifnull((B.POIN_MENANG+C.POIN_MENANG),0)-ifnull((B.POIN_KALAH+C.POIN_KALAH),0)) AS TOTAL_POIN

			FROM TB_MEMBER A LEFT JOIN 
			(
			SELECT A.GROUP, A.ID_MEMBER, A.NAMA_MEMBER, COUNT(B.PEMAIN1) AS JML_MAIN, SUM(IFNULL((B.SCORE1),0)) AS  POIN_MENANG,
			SUM(IFNULL((B.SCORE2),0)) AS POIN_KALAH
			FROM TB_MEMBER A LEFT JOIN TB_SCORE B
			ON A.ID_MEMBER = B.PEMAIN1
			GROUP BY A.GROUP, A.ID_MEMBER, A.NAMA_MEMBER
			) B ON A.ID_MEMBER = B.ID_MEMBER 
			LEFT JOIN 
			(
			SELECT A.GROUP, A.ID_MEMBER, A.NAMA_MEMBER, COUNT(B.PEMAIN2) AS JML_MAIN, SUM(IFNULL((B.SCORE2),0)) AS POIN_MENANG,
			SUM(IFNULL((B.SCORE1),0)) AS POIN_KALAH
			FROM TB_MEMBER A LEFT JOIN TB_SCORE B
			ON A.ID_MEMBER = B.PEMAIN2
			GROUP BY A.GROUP, A.ID_MEMBER, A.NAMA_MEMBER
			) C ON A.ID_MEMBER = C.ID_MEMBER
			WHERE A.GROUP = \'C\' 
			GROUP BY A.GROUP, A.ID_MEMBER, A.NAMA_MEMBER
			ORDER BY ifnull((B.POIN_MENANG+C.POIN_MENANG),0) DESC, ifnull((B.JML_MAIN+C.JML_MAIN),0) desc, ifnull((B.POIN_KALAH+C.POIN_KALAH),0) asc, (ifnull((B.POIN_MENANG+C.POIN_MENANG),0)-ifnull((B.POIN_KALAH+C.POIN_KALAH),0)) DESC
		';
		
		$query = $this->db->query($sql);
		return $query->result();
	}
	
	
	
}