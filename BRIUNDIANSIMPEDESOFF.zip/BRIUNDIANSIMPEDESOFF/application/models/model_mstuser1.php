<?php

class model_mstuser extends CI_Model
{
	  	private $another;
  		function __construct()
  		{
    		parent::__construct();
    		$this->another = $this->load->database('db1',TRUE);
  		}
	
		function data_unit(){
			return $this->another->query("SELECT * FROM `dbo_mstunit` WHERE `chrKdKanca` = '206'")->result();
		}






	

}
?>