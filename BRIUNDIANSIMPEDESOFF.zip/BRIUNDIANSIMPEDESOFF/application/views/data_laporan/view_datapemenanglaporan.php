<style type="text/css">
.style1 {
  color: #FF0000;
  font-weight: bold;
  font-size: 12px;

}
.style11 {color: #3333FF; font-weight: bold; }
.style12 {font-weight: bold; }
</style>

<script>
function showpemenang(str) {


  //  document.getElementById("txtHint").innerHTML= str ;
    var ok = str;
     window.location.href = "<?php echo base_url();?>laporan/pemenang?id=" + ok; 
    var e = document.getElementById("idperiode");
//    var idperiodeundian = e.options[e.selectedIndex].value;
    document.getElementById("periode").innerHTML = "Periode Undian" + e.options[e.selectedIndex].value;
  
}

function showpemenangdetil(str) {


  //  document.getElementById("txtHint").innerHTML= str ;
    var ok = str;
    var periode = document.getElementById('idperiode').value; 
  //  window.location.href = document.URL+"&idp=" + ok;
    window.location.href = "<?php echo base_url();?>laporan/pemenang?id=" + periode + "&idp=" + ok;


 
}

</script>


<div class="well2">

   <h4>Laporan Pemenang</h4>




   <table width="100%" >
       <tr> 
         <td width="60%">
         <label for="cari">Periode:</label>
          <select name ='periode' id="idperiode" onchange="showpemenang(this.value)">
           <?php
                  
                 // $random_dat = this->Ctrl_dtkuponBiasa->random_data($no);

                if (isset($periode)) 
                  {
                    $no++;

                  ?>
       
                   <option value='0'>-Pilih Periode-</option>
                   <?php
       
       
                    foreach ($periode as $row) 
                    {
                        if ( $row->chrKdPeriode == $_GET['id'])
                         {
                              ?>
                            <option value=<?php echo $row->chrKdPeriode; ?> selected="selected"> <?php echo $row->awal; ?>  s/d  <?php echo $row->akhir; ?> </option>   
                            <?php
                          }
                          else
                          {
                            ?>
                            <option value=<?php echo $row->chrKdPeriode; ?>> <?php echo $row->awal; ?>  s/d  <?php echo $row->akhir; ?> </option>
                             <?php
                          } 

                    }

                 }

                 else if ($no==0)
                 {
                  ?>
                      <option value='0'>-data kosong-</option>
                   <?php
                 }
                
                ?>



            </select>

                  
   </td>
   <td>
      <?php 
      if(isset($_GET['idp'])){
      $hadiah = $_GET['idp'];}
      else
      {
        $hadiah = '0';
      }

      ?>

      <?php 
      if(isset($_GET['id']) && $_GET['id']!=0){ ?>    
             <div align="right"><a class="btn btn-success" href="<?php echo site_url('ctrl_excel/laporanePemenangUndian?id='.$_GET['id'].'&idp='.$hadiah); ?>" style="color:white;"><span class="glyphicon glyphicon-file"></span> Export to Excel</a>
           <a class="btn btn-warning" href="<?php echo site_url('ctrl_excel/laporanUploadPemenang?id='.$_GET['id']); ?>" title="generate file yang digunakan untuk upload dokumen"><span class="glyphicon glyphicon-floppy-save" ></span> File to Upload</a></div>

  
<?php } ?>
   </td>
    </tr>
   </table>
  <hr />
  <?php if($_GET['id']==0){?>
  <h4> *pilih periode</h4>
  <?php }?>

    <?php if($_GET['id']!=0 && $jumlahhadiah==NULL){?>
  <h4> *Data Kosong</h4>
  <?php }?>


  <?php if($jumlahhadiah!=NULL && $_GET['id']!=0){?>

  <table border="0" width="100%" style="color: #000000; font-weight: bold;">
      <tr>
        <td>
          <center>
            PT.BANK RAKYAT INDONESIA (PERSERO), Tbk
          </center>
        </td>
      </tr>
      <tr>
        <td>
          <center>
Daftar Pemenang Undian Simpedes (<?php echo $this->session->userdata('kode_kanca');?>)
          </center>
        </td>
      </tr>
      <tr>
        <td>
          <center>
            <?php echo $tanngalMulai;?> 
            <?php echo $tanngalSelesai;?>
          </center>
        </td>
      </tr>
    </table>
</br>

   <table border="0" width="100%" style="color: #000000; font-weight: bold;">
    <tr>
      <td width="15%">Hari / Tanggal </td>
      <td>: <?php echo indonesian_date(date("l")) ?> <?php echo date("d-m-Y") ?></td>
    </tr>
    <tr>
       <td width="15%">Tempat</td>
       <td>: </td>
     </tr>
   </table>


 </br>

<div class="CSS_Table_Example " >
  <table width="100%" border="1"; >
        <thead>
            <tr class="info">
              <th width="3"><center>No</center></th>
               <th width="20"><center>No Undian</center></th>
              <th width="20%" ><center>No Rekening</center></th>
              <th width="15%" ><center>Nama Pemenang</center></th>
              <th width="20%" ><center>Unit Kerja</center></th>
              <th width="20%" ><center>Tanggal Pengundian</center></th>
            </tr>
            </thead>
            <?php
           // echo $hadiah;
              $no=0;
             // $random_dat = this->Ctrl_dtkuponBiasa->random_data($no);
              $tampung="";
              $tampung2 ="";
              $tamp="";
              $a=0;
            if (isset($pemenang)) 
              {
                foreach ($pemenang as $row) 
                {
                
    
                  $no++;
                  ?>
                    <tr>
                      <?php
                        if($no==1){
                        ?>
                          <tr>
                          <td colspan="6" align="left" class="style12">Hadiah : <?php echo $row->varJenisHadiah.' '.$row->varMerkHadiah.' '.$row->varTypeHadiah ?> &nbsp;</td>
                          </tr>
                     <?php
                      }
                      ?>

                      <td ><center><?php echo $no; ?></center></td>
                      <td ><center><?php echo $row->chrNoUndian; ?></center></td>
                      <td ><center><?php echo $row->chrNoRek; ?></center></td>
                      <td><center><?php echo $row->vcrNmNsbh; ?></center></td>
                      <?php 
                     ?>
                      <td><center><?php echo $row->namaUker; ?></center></td>
                                   
                      <td><center><?php echo $row->dtmTglAdd; ?></center></td>
                  </tr>


                  <?php

                    if($no==$jumlahhadiah[$a]){
                    ?>
                      <tr>
                      <td colspan="5" align="right" class="style12">Jumlah Pemenang &nbsp;</td>
                      <td  align="left" class="style12"> &nbsp; <?php echo $no. " orang"?></td>

                      
                      </tr>
                 <?php
                     $no=0;
                     $a++;
                 
                  }

                }



             }

             if($no==0)
             {
              ?>
            <!--    <td colspan="7"><center>Data Kosong</center></td> -->
              <?php
             }
            
            ?>

     </table>
<br/>

<?php foreach ($PenyelenggaraUndian as $row) {
 ?>

 <table border="0" width="100%" style="color: #000000; font-weight: bold;">
    <tr>
      <td width="33%" colspan='2'> <center>Mengesahkan,</center><br/><br/><br/></td>
      <td width="34%"><center>PT Bank Rakyat Indonesia (Persero), Tbk <center><br/><br/><br/></td>
    </tr>
    <tr>
      <td width="33%">
        <center>
          <span style="text-decoration: underline;"><?php echo $row->chrSaksi1; ?></span>
          </br>
          <?php echo $row->chrJbtS1; ?>
        <br/>
        <br/>
        <br/>
        <br/>
        
        </center>
      </td>


      <td width="33%">  
        <center>
          <span style="text-decoration: underline;"><?php echo $row->chrNotaris; ?></span>
          </br>
          <?php echo $row->chrJbtN; ?>
        <br/>
        <br/>
        <br/>
        <br/>
        
        </center>
      </td>
   
       <td>
        <center>
        <span style="text-decoration: underline;"><?php echo $row->chrPngJwb1; ?></span>
        </br>
      <?php echo $row->chrJbtPj1; ?>
        <br/>
        <br/>
        <br/>
        <br/>
        
        </center>
  
       </td>
     </tr>
     
    <tr>
      <td width="33%">
      <center>
        <span style="text-decoration: underline;"><?php echo $row->chrSaksi2; ?></span>
        </br>
      <?php echo $row->chrJbtS2; ?>
        <br/>
        <br/>
        <br/>
        <br/>
        
      </center>
  

      </td>
      <td width="33%">

        <center>
        <span style="text-decoration: underline;"><?php echo $row->chrSaksi3; ?></span>
        </br>
      <?php echo $row->chrJbtS3; ?>
        <br/>
        <br/>
        <br/>
        <br/>
        
      </center>



      </td>
      <td width="34%"></td>
    </tr>
 

    
   </table> 
  <br/>
  <br/>
  <i>*Data penyelenggara undian diambil dari data online, jika terdapat perubahan data penyelenggara undian data dapat dilakukan perubahan secara manual pada file excel dan diharapkan melakukan perubahan data pada portaldwhlinux.bri.co.id/briundiansimpedes.</i>
  
 
<?php } ?>



     </div>

  <hr />

</div>
<?php }?>
<?php 
function indonesian_date ($hari) {
 // $hari = '';
  if($hari=='Sunday'){$hari ="Minggu /";}
  if($hari=='Monday'){$hari ="Senin /";}
  if($hari=='Tuesday'){$hari ="Selasa /";}
  if($hari=='Wednesday'){$hari ="Rabu /";}
  if($hari=='Thursday'){$hari ="Kamis /";}
  if($hari=='Friday'){$hari ="Jumat /";}
  if($hari=='Saturday'){$hari ="Sabtu /";}
  return $hari;
} 
?>