

<style type="text/css">
.style1 {
  color: #FF0000;
  font-weight: bold;
  font-size: 12px;

}
.style11 {color: #3333FF; font-weight: bold; }
</style>

<script>
function showUser(str) {


  //  document.getElementById("txtHint").innerHTML= str ;
    var ok = str;
    window.location.href = "http://10.35.65.141/ppTEST/index.php/ctrl_uker/tambah_uker?id=" + ok; 


  
  
}
</script>

<link rel="stylesheet" href="http://10.35.65.141/ppTEST/index.php/assets/css/table.css" type="text/css"/>



<div class="well2">
   <h4>Edit Hadiah Kanca</h4>
  <hr />
   <?php
   $hay = "hay";
            if (isset($datahadiah)) 
              {
                foreach ($datahadiah as $row) 
                {
                  
                  $chrKdPeriode = $row->chrKdPeriode;
                  $awal = $row->awal;
                  $akhir   = $row->akhir;
                  $nama  = $row->nama ;
                  $jenishadiah = $row->jenishadiah;
                  $jumlah = $row->jumlah;
                  $kode   = $row->kode;
                }
             }
            else
            {
                 $chrKdPeriode = "";
                  $awal = "";
                  $akhir   = "";
                  $nama  = "" ;
                  $jenishadiah = "";
                  $jumlah = "";
                  $kode   = "";
            }

            
            ?>

 <table width="80%" border="0" width="80%" border="1" class="table table-striped table-bordered table-condensed ">
  <thead style="background: #ffe4ba; color: #00509A;">
      <tr>
        <th colspan="8">Informasi Umum</th>
      </tr>
    </thead>
    <tbody>

   <tr>
    <td><span class="style11">Kantor Cabang</span></td>
    <td colspan="3">

    <select name ='kantorcabang'>
      <option value='0'>-Pilih Kantor Cabang-</option> 
       <?php
            if (isset($kanca)) 
              {
                foreach ($kanca as $row) 
                {
                     if ( $row->chrKdKanca == 206)
                  {
                    ?>
                  <option value=<?php echo $row->chrKdKanca; ?> selected="selected" ><?php echo $row->vcrNmKanca; ?></option>
                  <?php
                }
                else
                {
                  ?>
                   <option value=<?php echo $row->chrKdKanca  ; ?>> <?php echo $row->vcrNmKanca; ?> </option>
   
                  <?php
                  $no++;
                }

                 
           
                } 
          } 
                
            ?>
        </select>

    <span class="style1">*</span></td>
  </tr>

     <tr>
    <td><span class="style11">Periode Undian</span></td>
    <td colspan="3">

      <select name ='periode'>
      <option value='0'>-Pilih Periode-</option>
       <?php
              $no=1;
             // $random_dat = this->Ctrl_dtkuponBiasa->random_data($no);

            if (isset($periode)) 
              {
                foreach ($periode as $row) 
                {
                    if ( $row->chrKdPeriode == $chrKdPeriode)
                  {
                    ?>
                  <option value=<?php echo $row->chrKdPeriode; ?> selected="selected" ><?php echo $row->awal; ?>  s/d <?php echo $row->akhir; ?> </option>
                  <?php
                }
                else
                {
                  ?>
                  <option value=<?php echo $row->chrKdPeriode; ?>> <?php echo $row->awal; ?>  s/d  <?php echo $row->akhir; ?> </option>
              
                  <?php
                  $no++;
                }



             }
           }
            
            ?>



        </select>


    <span class="style1">*</span></td>
  </tr>

       <tr>
    <td><span class="style11">Jenis Hadiah</span></td>
    <td colspan="3">

      <select name ='jenishadiah'>
      <option value='0'>-Jenis Hadiah-</option>
       <?php
              $no=1;
             // $random_dat = this->Ctrl_dtkuponBiasa->random_data($no);

            if (isset($Jenis_Hadiah)) 
              {
                foreach ($Jenis_Hadiah as $row) 
                {

                    if ( $row->chrKdHadiah == $kode)
                  {
                    ?>
                  <option value=<?php echo $row->chrKdHadiah; ?> selected="selected" > <?php echo $row->chrNmHadiah; ?> </option>
                  <?php
                }
                else
                {
                  ?>
                <option value=<?php echo $row->chrKdHadiah; ?>> <?php echo $row->chrNmHadiah; ?></option>
              
                  <?php
                  $no++;
                }



             }
           }
            
            ?>



        </select>


    <span class="style1">*</span></td>
  </tr>
  <tr>
    <td><span class="style11">Nama Hadiah</span></td>
    <td width = "30%"><input type="text" name="nama_hadiah" value="<?php echo $nama ?>" /></td>
    <td><span class="style11">Jumlah</span></td>
    <td><input type="text" name="jumlah" value="<?php echo $jumlah ?>"  /></td>
  </tr>


   <tr>
    <td><span class="style11">Jenis Hadiah</span></td>
    <td colspan="3">
     <button type="submit" class="btn btn-info">Simpan</button> 
    <span class="style1">*</span></td>
  </tr>

  </tbody>
    </table>

</div>