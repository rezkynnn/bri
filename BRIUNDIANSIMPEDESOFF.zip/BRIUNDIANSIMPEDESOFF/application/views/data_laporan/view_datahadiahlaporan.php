<style type="text/css">
.style1 {
  color: #FF0000;
  font-weight: bold;
  font-size: 12px;

}
.style11 {color: #3333FF; font-weight: bold; }
.style12 {color: red; font-weight: bold; }
.style13 {color: green; font-weight: bold; }
</style>

<link href="<?php echo base_url();?>/assets/css/rfnet.css" rel="stylesheet" type="text/css">
<script type="text/javascript" src="<?php echo base_url();?>/assets/css/datetimepicker_css.js"></script>


<script>
function showpemenang(str) {


  //  document.getElementById("txtHint").innerHTML= str ;
    var ok = str;
    window.location.href = "<?php echo base_url();?>laporan?id=" + ok; 
    var e = document.getElementById("idperiode");
//    var idperiodeundian = e.options[e.selectedIndex].value;
  
}
</script>


<div class="well2">
   <h4>Data Hadiah</h4>
     <form action="<?php echo base_url().'ctrl_hadiah/simpan_kirimulangkanca?id='.$_GET['id'];?>" >     

   <table width="100%" >
   <tr> 
          <td>
            <label for="cari">Periode:</label>
  
            <select name ='periodehadiah' id="idperiode" onchange="showpemenang(this.value)">
           <?php
                  
                 // $random_dat = this->Ctrl_dtkuponBiasa->random_data($no);

                if (isset($periode) ) 
                  {
                    $no++;

                  ?>
       
                   <option value='0'>-Pilih Periode-</option>
                   <?php
       
       
                    foreach ($periode as $row) 
                    {
                        if ( $row->chrKdPeriode == $_GET['id'])
                         {
                              ?>
                            <option value=<?php echo $row->chrKdPeriode; ?> selected="selected"> <?php echo $row->awal; ?>  s/d  <?php echo $row->akhir; ?> </option>   
                            <?php
                          }
                          else
                          {
                            ?>
                            <option value=<?php echo $row->chrKdPeriode; ?>> <?php echo $row->awal; ?>  s/d  <?php echo $row->akhir; ?> </option>
                             <?php
                          } 

                    }

                 }

                 else if ($no==0)
                 {
                  ?>
                      <option value='0'>-data kosong-</option>
                   <?php
                 }
                
                ?>



            </select>



            &nbsp;
            <?php 
             if(isset($_GET['id']) && $_GET['id']!=0)
              {
              ?>

               <label for="cari">Tanggal Pelaksanaan : <?php echo $tanggal ?></label>
            <input type="hidden"  name="dtmpelaksana" id="dtmpelaksana" maxlength="25" size="20" value="<?php echo $tanggal ?>" readonly> 
          </td>
          <td>
          </td>
        <td>
        <div align="right">
           <a class="btn btn-success" href="<?php echo site_url('ctrl_excel/laporanhadiahtiapkanca?id='.$_GET['id']); ?>"  style="color:white;"><span class="glyphicon glyphicon-file"></span> Export to Excel</a>
                 
       <!--  <a href="<?php echo base_url().'ctrl_hadiah/tambahhadiahKanca?id='.$_GET['id'];?>">TAMBAH <font color="blue">BARU</font></a> | -->
          
      
     
        </td>


          <?php
            }
            else
            {
            ?>

            



          <?php


            }
            ?>
          

    </tr>
  </table>
    <hr />

    <table border="0" width="100%" style="color: #000000; font-weight: bold;">
      <tr>
        <td>
          <center>
            PT.BANK RAKYAT INDONESIA (PERSERO), Tbk
          </center>
        </td>
      </tr>
      <tr>
        <td>
          <center>
Daftar Hadiah Undian Simpedes - Dengan Kode Branch <?php echo $idkanca; ?>
          </center>
        </td>
      </tr>
      <tr>
        <td>
          <center>
                     <?php  
                     if($tanngalMulai!='')
                     {
                      echo $tanngalMulai;
                      echo $tanngalSelesai; 

                     }



                    ?> 
          </center>
        </td>
      </tr>
    </table>
</br>
    <table border="1" width="100%">

    <thead>
          <tr class="info">
              <th width="3%"><center>No</center></th> 
              <th width="15%"><center>Jenis hadiah</center></th>

              <th width="47%" ><center>Merk/Type Hadiah/Tahun/kondisi</center></th>
              <th width="10%" ><center>Harga Satuan</center></th>
              <th width="5%" ><center>Jumlah</center></th>
               <th width="10%" ><center>Potongan</center></th>
              <th width="10%" ><center>Total harga</center></th>
             
            </tr>
            </thead>
            <?php
           // echo $hadiah;
              $no=0;
              $jumlahtot = 0;
              $hargatotal = 0;
              $hargasatuantotal=0;
              $hargasatuantotalakhir=0;
              $hargatotaladiah = 0;
              $totpotongan = 0;
             // $random_dat = this->Ctrl_dtkuponBiasa->random_data($no);

            if (isset($data)) 
              {
                foreach ($data as $row) 
                {
                  $no++;
                  ?>
                    <tr>
                  
                      <td ><center><?php echo $no; ?></center></td>
                       <td ><center><?php echo $row->jenishadiah; ?></center></td>
                      <td><center>
                      <?php 
                      if ($row->varJenisHadiah !="" && $row->varMerkHadiah !="")
                      {?>

                      <?php echo $row->varJenisHadiah; ?>/
                      <?php echo $row->varMerkHadiah; ?>/
                      <?php echo $row->varTypeHadiah; ?>/
                      <?php echo $row->tahunPembuatan; ?>/
                      <?php echo $row->varKondisiPembuatan; ?>
                      <?php } 
                      else 
                        {?>
                        <?php echo "Data Tidak Lengkap"; ?>
                     

                        <?php }?>

                      </center></td>
                      <td  style="text-align:right"><?php echo number_format($row->hargaSatuan); ?></td>
                      <td  style="text-align:right"><center><?php echo $row->jumlah; ?></center></td>
                      <td  style="text-align:right"><?php echo number_format($row->potonganHarga); ?></td>
                      <td  style="text-align:right"><?php echo number_format($hargasatuantotalakhir = ($row->hargaSatuan *$row->jumlah)-$row->potonganHarga,0 ); ?></center></td>
                   
                  
                      </tr>
                  <?php
                  $totpotongan = $row->potonganHarga + $totpotongan;
                  $hargasatuantotal = $row->hargaSatuan +$hargasatuantotal;
                  $jumlahtot = $row->jumlah + $jumlahtot;
                  $hargatotaladiah = $hargasatuantotalakhir +  $hargatotaladiah;


                }
           
               if($no ==0)
                  {
                    ?>
                    <td colspan="7"><center>Data kosong</center></td>
                    <?php 
                  }
                  else
                  {
                        ?>
                      <thead>
                        <th colspan="2" align="right"></th>
                         <td  align="right" style="  font-weight: bold;"><span >Jumlah Total </span>&nbsp;</td>
                         <td  style="text-align:right;  font-weight: bold;"><?php echo number_format($hargasatuantotal,0); ?></td>
                         <td  style="text-align:right;  font-weight: bold;" ><center><?php echo $jumlahtot; ?></center></td>
                         <td  style="text-align:right;  font-weight: bold;" ><?php echo number_format($totpotongan,0); ?></td>
                         <td  style="text-align:right;  font-weight: bold;" ><?php echo number_format($hargatotaladiah, 0);  ?></td>
       
                     </thead>
                      <?php


                  }

             }
             else{

                ?>
                    <td colspan="6"><center>Data kosong</center></td>
                    <?php 
              
              }
            
            ?>


     </table>
 
  
     </div>
</form>
  <hr />

 
</div>